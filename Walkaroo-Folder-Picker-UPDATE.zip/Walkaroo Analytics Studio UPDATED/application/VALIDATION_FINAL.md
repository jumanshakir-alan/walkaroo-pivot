# Validation of the delivered package

Validated on 30 October 2026 using Python 3.12.14, Node.js 24.19.0 and headless Chromium on Linux. Dependencies installed from the unchanged requirements: openpyxl 3.1.5, pyodbc 5.3.0 and et_xmlfile 2.0.0. TLS verification remained enabled.

| Check | Result |
| --- | --- |
| Fresh `setup-final.sh` run and repeated run | Passed; virtual environment created, dependencies installed, `pip check` clean |
| `start-final.sh` on the default port | Passed; first-run setup served and anonymous catalog access rejected |
| Python test suite | **91 tests passed**, including all 65 original tests and 26 portal/folder tests |
| Original JavaScript test scripts | **6 scripts passed** |
| Portal JavaScript syntax and Python compilation | Passed |
| First administrator creation and sign-in in Chromium | Passed using a one-time setup token and isolated synthetic test account |
| Admin theme, field mapping, role and user creation through UI | Passed |
| Dashboard creation with bar, line, area, donut, KPI and table | Passed |
| Formula over aggregate measures | Passed; scoped sales 150 / cost 80 gives margin 46.67% |
| Publishing and opening private links as restricted viewer | Passed; all six visuals received total 150 rather than unrestricted total 7,150 |
| Unauthorized original workspace and arbitrary query APIs | Rejected for viewer; original workspace works for signed-in admin |
| Desktop and 390px mobile browser checks | Passed; no browser JavaScript errors and no horizontal mobile overflow |
| Sales folder selection | Passed in Chromium: path with spaces, listing, real XLSX import, invalid-path rejection and saved selection after reload |
| Original-file preservation | All **56 original files** excluding generated Python bytecode match the source archive byte for byte |

Portal regression coverage includes all three mandatory row restrictions combined, AND composition with caller filters, missing-mapping denial, dataset grants, cached-result separation, immediate role changes, user-session revocation, administrator boundaries, last-active-admin protection, password hashing, one-time setup, safe formula parsing, theme validation, published/draft separation, optimistic page version checks, page ownership/audience, CSRF checks and connection-test isolation. Fabric authentication flags, ODBC password escaping and TLS validation settings are verified with a simulated driver.

Browser data and accounts were synthetic and stored outside the deliverable. The ZIP contains no newly generated account database, bootstrap token, password, session, sales cache, virtual environment or compiled Python cache. Original supplied screenshots/exports are retained unchanged as historical supporting material; they are not evidence of a newly connected warehouse.

## Requires acceptance in your environment

- **Live Fabric authentication and queries were not run:** no real endpoint/account was supplied and ODBC Driver 18 is not installed in this Linux validation host. Username/password is subject to Microsoft Entra tenant/MFA policy. Interactive sign-in requires a compatible desktop host/driver. Database discovery is limited to the endpoint/account's visibility.
- **Windows `.cmd` launchers were provided but not executed on Windows.** Their equivalent Linux setup/start workflow was exercised.
- **HTTPS/DNS hosting and multi-computer deployment were not provisioned.** Private publishing was verified within the application; it does not deploy the host or create a public URL.
- No original source workbook archive was supplied. Import/master/refresh/pivot behavior was exercised by the original regression suite and the browser portal used synthetic local sales. Verify your real workbook layouts and master mappings before business use.

See `README_FINAL.md` for the complete startup, configuration, role restrictions and deployment instructions. `ORIGINAL_FILES_SHA256.json` records the supplied archive's hash and each retained original file's checksum.

Folder update: native Windows picker command construction, cancellation and fallback paths are covered with simulated subprocesses. The native Windows dialog itself was not executed on this Linux host. Browser path selection and import were tested against a real synthetic workbook. Folder APIs require administrator authentication and CSRF verification.
