@echo off
setlocal
title Walkaroo Final - Setup
cd /d "%~dp0application"
call Setup-Final.cmd
exit /b %errorlevel%
