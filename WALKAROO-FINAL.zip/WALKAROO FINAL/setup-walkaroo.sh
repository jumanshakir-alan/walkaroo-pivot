#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")/application"
bash setup-final.sh
