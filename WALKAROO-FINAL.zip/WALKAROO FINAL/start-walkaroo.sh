#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")/application"
exec .venv/bin/python portal.py --host 127.0.0.1 --port 8870
