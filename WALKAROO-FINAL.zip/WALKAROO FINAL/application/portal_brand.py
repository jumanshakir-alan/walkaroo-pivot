"""Official Walkaroo logo configuration and optional TLS-verified local cache."""
from pathlib import Path
import ssl
import urllib.request

LOGO_URL = 'https://www.walkaroo.in/cdn/shop/files/LOGO_RED.jpg?v=1707540006&width=290'
LOGO_PATH = Path(__file__).resolve().parent/'portal_web'/'assets'/'walkaroo-logo.jpg'


def logo_bytes():
    if LOGO_PATH.is_file():
        content = LOGO_PATH.read_bytes()
        if len(content) <= 2 * 1024 * 1024 and content.startswith(b'\xff\xd8\xff'):
            return content
    return None


def cache_logo():
    if logo_bytes():
        return True
    request = urllib.request.Request(LOGO_URL, headers={'User-Agent': 'Walkaroo-Analytics-Studio/1.0'})
    with urllib.request.urlopen(request, timeout=15, context=ssl.create_default_context()) as response:
        content = response.read(2 * 1024 * 1024 + 1)
    if len(content) > 2 * 1024 * 1024 or not content.startswith(b'\xff\xd8\xff'):
        raise ValueError('The logo response was not a supported JPEG.')
    LOGO_PATH.parent.mkdir(parents=True, exist_ok=True)
    LOGO_PATH.write_bytes(content)
    return True


if __name__ == '__main__':
    try:
        cache_logo()
        print('Walkaroo logo cached locally for offline use.')
    except Exception:
        # Branding is optional for installation; app functionality remains available.
        print('Logo cache unavailable. The app will use the supplied online logo URL, with a text fallback when offline.')
