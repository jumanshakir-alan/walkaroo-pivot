import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch, Mock

import app
import portal_folders
from portal_core import Store, Denied


class FolderTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.old = self.root/'old'
        self.new = self.root/'Sales files with spaces'
        self.old.mkdir()
        self.new.mkdir()
        (self.new/'October sales.xlsx').write_bytes(b'listing fixture only')
        (self.new/'~$locked.xlsx').write_bytes(b'Excel lock')
        (self.new/'notes.txt').write_text('not a workbook')
        self.store = Store(self.root/'settings')
        self.actor = {'id':'test-admin', 'admin':True}
        self.patches = [patch.object(app,'FILES',self.old),
            patch.object(app,'DB',self.root/'sales.sqlite'),
            patch.object(app,'JOB',{'running':False}), patch.object(app,'IMPORT_MONITOR',None)]
        for p in self.patches:p.start()

    def tearDown(self):
        for p in reversed(self.patches):p.stop()
        self.tmp.cleanup()

    def test_path_switch_lists_files_and_persists_without_import(self):
        result=portal_folders.save_folder(self.store,self.actor,'"'+str(self.new)+'"')
        self.assertEqual(result['excelFiles'],1)
        self.assertEqual(app.file_list()[0]['name'],'October sales.xlsx')
        with app.local() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM imports').fetchone()[0],0)
        app.FILES=self.old
        portal_folders.restore_folder(self.store)
        self.assertEqual(app.FILES,self.new)

    def test_invalid_folder_keeps_current_selection(self):
        for value in ['', 'relative/folder', str(self.root/'missing'), str(self.new/'notes.txt')]:
            with self.assertRaises(ValueError):
                portal_folders.save_folder(self.store,self.actor,value)
            self.assertEqual(app.FILES,self.old)
        self.assertIsNone(self.store.get_object('settings','sales-folder'))

    def test_switch_blocked_during_import(self):
        with patch.object(app,'JOB',{'running':True}):
            with self.assertRaises(ValueError):
                portal_folders.save_folder(self.store,self.actor,str(self.new))
        self.assertEqual(app.FILES,self.old)

    def test_non_admin_cannot_select_source(self):
        with self.assertRaises(Denied):
            portal_folders.save_folder(self.store,{'id':'viewer','admin':False},str(self.new))

    def test_windows_picker_cancellation_preserves_selection(self):
        result=Mock(returncode=0,stdout='')
        with patch.object(portal_folders.sys,'platform','win32'), patch.object(subprocess,'run',return_value=result) as run:
            info=portal_folders.browse_folder()
        self.assertTrue(info['cancelled'])
        self.assertEqual(app.FILES,self.old)
        args=run.call_args.args[0]
        self.assertEqual(args[:3],['powershell.exe','-NoProfile','-STA'])
        self.assertNotIn(str(self.old),args[-1])
        self.assertFalse(run.call_args.kwargs.get('shell',False))

    def test_native_picker_selects_without_automatically_saving(self):
        result=Mock(returncode=0,stdout=str(self.new))
        with patch.object(subprocess,'run',return_value=result):
            info=portal_folders.browse_folder()
        self.assertEqual(info['path'],str(self.new))
        self.assertEqual(app.FILES,self.old)

    def test_native_picker_failure_explains_paste_fallback(self):
        with patch.object(subprocess,'run',side_effect=OSError('no desktop')):
            with self.assertRaisesRegex(ValueError,'Paste the full folder path'):
                portal_folders.browse_folder()
