# Validation of the delivered package

Validated on 30 October 2026 using Python 3.12.14, Node.js 24.19.0 and headless Chromium on Linux. Dependencies installed from the unchanged requirements: openpyxl 3.1.5, pyodbc 5.3.0 and et_xmlfile 2.0.0. TLS verification remained enabled.

| Check | Result |
| --- | --- |
| Fresh `setup-final.sh` run and repeated run | Passed; virtual environment created, dependencies installed, `pip check` clean |
| `start-final.sh` on the default port | Passed; first-run setup served and anonymous catalog access rejected |
| Python test suite | **91 tests passed**, including all 65 original tests and 26 portal/folder tests |
| Original JavaScript test scripts | **6 scripts passed** |
| Portal JavaScript syntax and Python compilation | Passed |
| First administrator creation and sign-in in Chromium | Passed using a one-time setup token and isolated synthetic test account |
| Admin theme, field mapping, role and user creation through UI | Passed |
| Dashboard creation with bar, line, area, donut, KPI and table | Passed |
| Formula over aggregate measures | Passed; scoped sales 150 / cost 80 gives margin 46.67% |
| Publishing and opening private links as restricted viewer | Passed; all six visuals received total 150 rather than unrestricted total 7,150 |
| Unauthorized original workspace and arbitrary query APIs | Rejected for viewer; original workspace works for signed-in admin |
| Desktop and 390px mobile browser checks | Passed; no browser JavaScript errors and no horizontal mobile overflow |
| Sales folder selection | Passed in Chromium: path with spaces, listing, real XLSX import, invalid-path rejection and saved selection after reload |
| Original-file preservation | All **56 original files** excluding generated Python bytecode match the source archive byte for byte |

Portal regression coverage includes all three mandatory row restrictions combined, AND composition with caller filters, missing-mapping denial, dataset grants, cached-result separation, immediate role changes, user-session revocation, administrator boundaries, last-active-admin protection, password hashing, one-time setup, safe formula parsing, theme validation, published/draft separation, optimistic page version checks, page ownership/audience, CSRF checks and connection-test isolation. Fabric authentication flags, ODBC password escaping and TLS validation settings are verified with a simulated driver.

Browser data and accounts were synthetic and stored outside the deliverable. The ZIP contains no newly generated account database, bootstrap token, password, session, sales cache, virtual environment or compiled Python cache. Original supplied screenshots/exports are retained unchanged as historical supporting material; they are not evidence of a newly connected warehouse.

## Requires acceptance in your environment

- **Live Fabric authentication and queries were not run:** no real endpoint/account was supplied and ODBC Driver 18 is not installed in this Linux validation host. Username/password is subject to Microsoft Entra tenant/MFA policy. Interactive sign-in requires a compatible desktop host/driver. Database discovery is limited to the endpoint/account's visibility.
- **Windows `.cmd` launchers were provided but not executed on Windows.** Their equivalent Linux setup/start workflow was exercised.
- **HTTPS/DNS hosting and multi-computer deployment were not provisioned.** Private publishing was verified within the application; it does not deploy the host or create a public URL.
- No original source workbook archive was supplied. Import/master/refresh/pivot behavior was exercised by the original regression suite and the browser portal used synthetic local sales. Verify your real workbook layouts and master mappings before business use.

See `README_FINAL.md` for the complete startup, configuration, role restrictions and deployment instructions. `ORIGINAL_FILES_SHA256.json` records the supplied archive's hash and each retained original file's checksum.

Folder update: native Windows picker command construction, cancellation and fallback paths are covered with simulated subprocesses. The native Windows dialog itself was not executed on this Linux host. Browser path selection and import were tested against a real synthetic workbook. Folder APIs require administrator authentication and CSRF verification.


## Brand Edition checks

The complete 91-test Python suite and all six original JavaScript test scripts passed with the branding changes. Chromium checks covered the new login/portal layouts, page search, real workspace count cards, six visual types, theme creation, page publication, row-restricted totals, admin-only legacy access, all admin tabs and retained folder controls. A custom page theme was checked against actual SVG chart mark colours. The default dataset's fields load when the studio opens, without requiring a second dataset selection. Portal and Excel-workspace layouts were checked at 390px width with no horizontal document overflow; no browser JavaScript errors were observed.

The supplied logo URL is configured exactly and its HTTP redirect was verified. The test deliberately blocked the external image to verify the offline text fallback; the actual external JPEG could not be fetched in the cloud because of outbound policy. Optional cache checks verified TLS certificate validation remains enabled and non-JPEG responses are rejected. The cache does not make dependency installation fail if the logo host is unavailable. Windows-native picker behavior remains simulated on Linux as previously described.

Original `app.py`, `analytics.py`, `masterdata.py`, the original web files, requirements and original tests remain byte-identical. Branding of the original workspace is injected by the portal wrapper and separate CSS/JS; its original source files are not modified.


Excel-workspace UI update: Chromium verified that the duplicate Fabric card is not visible, the Excel archive occupies the grid width, folder/path/import controls remain visible, and the main Analytics Studio Fabric form remains available. Desktop and 390px mobile checks had no document overflow or JavaScript errors. JavaScript syntax validation passed. This presentation-only update did not require a new business-logic test run.

Sidebar colour update: Chromium checked the sidebar as #f1f2f4 with the existing #fcedef active-navigation background retained. This is a CSS-only change.

Workspace polish was checked in Chromium at desktop and 390px widths: Excel spans the available width, the duplicate Fabric card remains hidden, the main Studio connector remains visible, and folder/import controls remain available with no JavaScript errors or mobile overflow. No business logic was changed.


Compact workbook UI: Chromium with 36 distinct synthetic workbooks verified approximately 36px desktop rows, at least 12 visible rows in the list, folder controls under 120px high, and import actions above the files. Space-key bulk selection and clearing worked. Three selected workbooks imported successfully (24→27 imported files, 48→54 sales rows), completed selections cleared, refreshing retained 54 rows, and removing one import resulted in 26 files / 52 rows while retaining its source workbook. Native guidance disclosure worked by keyboard. Mobile controls retained touch spacing and no document overflow or JavaScript errors occurred. An earlier synthetic-fixture attempt used identical workbook contents and was correctly rejected by the original duplicate-file protection; the successful test used distinct files. No original business-logic file changed.


31 October 2026: Chromium checked that the return link is below the logo and above the workspace menu, remains present on all three legacy pages, and navigates to the portal root with Enter. No duplicate main-area link remains. Run/Save were reachable at 1512×1000 and 1280×800. Moving the existing controls retained the header-picker dialog, pivot totals (GrossValue 1,000; NetTotal 900 in synthetic data), saved-view save/restore, enabled CSV export and folder controls. Desktop and 390px mobile layouts had no horizontal document overflow or JavaScript errors. JavaScript syntax validation passed. This update changes presentation/navigation only; the 56 original supplied files remain byte-identical.
