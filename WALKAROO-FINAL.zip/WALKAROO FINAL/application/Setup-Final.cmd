@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Install Python 3.11 or later from python.org, including the Python launcher.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" py -3 -m venv .venv
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip check
if errorlevel 1 goto failed
.venv\Scripts\python.exe portal_brand.py
echo.
echo Setup complete. Run Start-Final.cmd to open the authenticated portal.
echo For live Fabric access, install Microsoft ODBC Driver 18 for SQL Server.
pause
exit /b 0
:failed
echo Setup failed. Review the message above, correct the prerequisite, and run this again.
pause
exit /b 1
