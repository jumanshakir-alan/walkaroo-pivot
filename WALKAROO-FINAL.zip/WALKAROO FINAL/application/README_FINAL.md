# Walkaroo Analytics Studio — final package

Start here for the new authenticated portal. The original Python modules, web files, tests, requirements, Windows launchers and README are preserved byte for byte from the supplied archive. New features live in `portal.py`, `portal_core.py`, `portal_fabric.py` and `portal_web/`. The portal calls the original pivot engine; it does not rewrite imports, refresh/removal, fiscal periods, master relationships, measure aggregation or existing report logic.

## Start on Windows

1. Extract the entire ZIP into a writable folder. Install Python **3.11 or newer**, including its launcher.
2. Run **Setup-Final.cmd** once. It creates `.venv` and installs the unchanged `requirements.txt`.
3. For Fabric, also install **Microsoft ODBC Driver 18 for SQL Server** from Microsoft's official installer: https://learn.microsoft.com/sql/connect/odbc/download-odbc-driver-for-sql-server
4. Run **Start-Final.cmd** and keep the console open. Open `http://127.0.0.1:8765` in your browser.
5. On first startup, read `data/bootstrap.token` in the extracted folder. Enter that one-time token on the setup screen and create your administrator with a password of at least 12 characters. No account or default password is bundled. The token file is removed after successful setup.
6. Sign in. The administrator can access **Original workspace** for the unchanged Excel import, master management and legacy pivot experience.

Do not run original `Start.cmd` or `app.py` as a second shared service: those original entrypoints intentionally retain their old local-only session model and have no portal user accounts. Always use `Start-Final.cmd` for the protected portal.

## Start on Linux/macOS

With Python 3.11+ and venv support installed:

```sh
bash setup-final.sh
bash start-final.sh
```

Fabric requires Microsoft's platform-specific ODBC Driver 18. Interactive Microsoft sign-in depends on OS/driver desktop support; the original app was designed for Windows. A headless Linux host cannot be assumed to support its interactive sign-in window. The local Excel/SQLite workflow is tested on Linux.

## Fabric: password, sign-in and database visibility

In **Fabric connections**, enter a label, your SQL hostname ending in `.datawarehouse.fabric.microsoft.com`, and the exact warehouse/database name. Choose either:

- **Microsoft sign-in**: uses `ActiveDirectoryInteractive` and the account/tenant's Microsoft Entra sign-in flow on a compatible interactive host.
- **Microsoft Entra username & password**: uses `ActiveDirectoryPassword`, **not** SQL username/password authentication. If your tenant requires MFA or blocks password-based authentication, use the Microsoft sign-in option. This option cannot bypass tenant policy.

**Test connection** signs in, reads table/view metadata and attempts to list accessible databases, then closes the test connection without saving it. **Connect & load tables** retains a live connection and saves only its label/endpoint/database/table metadata. Passwords and login tokens are never stored in portal settings, audit logs or the ZIP. ODBC owns the authenticated connection in process memory. Restarting requires an administrator to reconnect.

The app displays all tables/views returned by the connected database's metadata permissions. Database discovery uses `sys.databases` and `HAS_DBACCESS`; where unsupported or permission-limited, add the other warehouse/database explicitly. Fabric may give separate SQL endpoints to different warehouses. One connection does **not** enumerate all databases across a Fabric tenant. Add separate saved connections for each accessible endpoint/database. To change a saved connection's warehouse identity, create a new connection so existing role grants cannot silently move to a different warehouse.

Original Fabric master links are keyed by schema/table only. To avoid accidentally applying one warehouse's master mapping to another warehouse with the same table names, the **new portal** exposes Fabric's own columns. For Fabric master attributes such as customer UP_Region, use a prepared read-only warehouse view containing those attributes. The original workspace's Fabric master-link behavior is preserved. Local portal datasets continue to support the original linked master attributes.

Live Fabric access was not tested against a real warehouse or tenant. The credential handling, connection-string escaping, TLS settings and metadata integration are covered by simulated-driver tests. Actual access requires your driver, endpoint, database, account permissions, tenant policy and network route (typically SQL TCP 1433 plus Microsoft Entra HTTPS endpoints). No fabricated credentials or database results are included.

## Data and existing workbook logic

No original sales workbooks or populated SQLite sales cache were supplied. In **Original workspace → Data connections → Excel sales archive**, use **Browse folder…** or paste your full sales folder path, then click **Use this folder**. Select the listed Excel files and click **Import selected files**. The default source remains the sibling **001. SQL Data Base** folder. The selected source is saved and restored on restart. Browse opens a native folder window on the application host; on a remote/headless host paste its server-side path instead. Windows Explorer **Copy as path** values with outer quotes are accepted. Changing folders does not change previously imported rows; use the existing Refresh/Remove controls deliberately for previously imported filenames. Folder changes are blocked during an active data operation and are administrator-only. Keep the existing Data-sheet/header conventions and overlap warnings in the original README. Local import, refresh, remove, master upload/link, saved browser views and existing calculations keep their original behavior.

Back up the entire `data/` folder, which contains sales, masters and portal accounts/configuration. Stop the server before copying SQLite databases for a consistent backup, or use SQLite's backup API. Existing original sales caches can be moved into `data/sales.sqlite` while both services are stopped; do not replace `portal.sqlite` with a sales database. Preserve any original `sales.sqlite-wal` state by shutting the original application down cleanly before migration.

## Users, roles and row access

Administrators have full data and management access. For other users:

1. In **Users & roles → Map the security fields**, choose a dataset and map its actual UP_Region, Budget Category and Business Type columns. Local linked master fields can be selected. A restricted dimension without a valid mapping causes the query to be denied.
2. Create a role. Select its allowed datasets. An empty dataset selection grants **no data access**.
3. Enter exact allowed values, one per line, for UP_Region, Budget Category and Business Type. A blank restriction means **all values** for that dimension; only use that deliberately. Entering `TN` does not also match `tn` or padded variants. Values within a dimension use OR; the three dimension restrictions and report filters use AND. Up to 200 values per restriction are supported. Blank/NULL-specific role grants are not exposed in this version.
4. Grant authoring and/or publishing only when required. Create a user, assign its role, and set an initial password. Send initial passwords using your own secure channel; users can change them from **Account & password**. Disable an account to revoke access. Saving user changes revokes its existing sessions. Role edits are read on every subsequent request.

The server adds these restrictions before the original engine executes queries. They apply to previews, published visualizations, aggregate totals, calculated values and CSV exports. A caller cannot override source/table IDs or remove mandatory predicates. Existing cache keys include the effective filters, keeping results separated by access scope. Non-admins cannot call original workspace APIs, inspect source file inventories or upload/change masters through legacy endpoints.

These roles control application data access. They do not create Microsoft Entra/Fabric principals or change warehouse permissions. The connected Fabric account must already have read permissions; use a read-only account. Administrators control which of those datasets are delegated through the portal. Host filesystem access is outside application RBAC: a person who can read the SQLite files can read their contents.

## Themes, graphs and custom logic

Admins can create/edit named themes using primary, accent, background, card surface and text colours. Apply a saved theme per dashboard page. No external chart service, JavaScript CDN or font download is required.

**Dashboard studio** builds pages containing up to 12 visualizations. Choose a local/Fabric dataset, up to two grouping fields, one to three measures, an aggregation and exact-match filters. Supported views: **bar, line, area, donut, KPI and table**. Charts display 1–100 leading groups in the original query order; they do not change the underlying calculation or fiscal logic. Tables and their CSV exports contain all returned groups (the original engine's 10,000-group limit remains). Donut charts require nonnegative values. Hover chart marks for values. Charts use the first measure, or the calculated value when a formula is present; tables display all selected measures.

The optional calculated-logic field accepts **m1, m2, m3**, numbers, parentheses and `+ - * /`. Examples:

```text
m1 - m2
(m1 - m2) / m1 * 100
m1 / m2
```

These are formulas **over aggregated measures**, not arbitrary Python, SQL or DAX and not changes to source records. For a margin formula, select Sales as m1 and Cost as m2 with Sum. Each group's formula uses that group's aggregates; a KPI's formula is recomputed from the overall aggregate totals, rather than summing percentages. Division by zero or missing inputs produces blank; no executable code is accepted. The original aggregation options and their limits remain. A null formula result appears at the zero baseline in line/bar/area graphs; use the table to distinguish blank from zero.

Add, edit, remove and move visualizations in the page. Save a draft to retain work. An administrator can edit any dashboard; a designer can edit their own. The page version check prevents silently overwriting another session's edits.

## Private publishing

**Publish private page** creates a saved definition of the dashboard, separate from its editable draft. Saving later draft changes does not alter the published version until you publish again. Data is queried live for the viewer; results are not stored in the published definition.

Admins can choose audience roles; no audience selection permits any signed-in user to open the page, while dataset and row grants still apply. **Copy private link** produces `/published/<page-id>` on the current host. A recipient must sign in, match the page audience and have data grants. Widgets without a usable grant or live connection show an access/reconnection error instead of data. **Unpublish** removes the currently published definition and disables its link. Publishing does not deploy a website or create a public Internet URL.

To share across computers, deploy the application on a maintained host behind your own **HTTPS reverse proxy** and firewall:

```sh
.venv/bin/python portal.py --host 127.0.0.1 --port 8765 --public-url https://analytics.example.com
```

Have the proxy forward that origin to the local port and preserve the external Host header. Keep the upstream port private, terminate TLS at the proxy and use one application process. The command rejects non-loopback binding unless an HTTPS origin is explicitly configured. `--public-url` validates origins and enables Secure session cookies; it does not install certificates, start TLS or provision DNS. Share the HTTPS private page link with your users. The local default is for development/single-host use.

Sessions use random tokens, HttpOnly/SameSite cookies, CSRF checks and eight-hour expiry. Passwords are PBKDF2-SHA256 hashed; login attempts are throttled. User/role/theme/publishing/connection administration actions are audited without credential values. This is a single-process application using local SQLite and in-memory ODBC connections; horizontal scale, Entra SSO for portal users, scheduled refresh and tenant-wide Fabric workspace discovery are not included.

## Verification

From the extracted app folder after setup:

```sh
.venv/bin/python -m unittest discover -s tests -v
```

On Windows use `.venv\Scripts\python.exe` instead. With Node.js installed:

```sh
node tests/test_customer_type.js
node tests/test_fiscal.js
node tests/test_multi_filters.js
node tests/test_opening_chart.js
node tests/test_up_region.js
node tests/test_visible_headers.js
```

The delivered version's exact validation outcomes are recorded in `VALIDATION_FINAL.md`. Live warehouse acceptance still needs your real Fabric environment. The original Windows `.cmd` behavior requires a Windows host for final OS-specific acceptance.


## Walkaroo Brand Edition

This edition adds the supplied official logo URL to the sign-in screen, portal navigation and the original Excel/pivot workspace:
https://www.walkaroo.in/cdn/shop/files/LOGO_RED.jpg?v=1707540006&width=290

The UI uses red, white and charcoal with clearer navigation, page search and sorting, live workspace counts, improved form focus states and responsive phone layouts. Custom page themes still control published chart colours. Decorative hero graphics are illustrative; workspace overview counts come from actual saved pages, authorized datasets and themes.

The logo is served from a local cache when available. Setup runs `portal_brand.py`, which attempts a TLS-verified download into `portal_web/assets/walkaroo-logo.jpg`. If it cannot download, the image route redirects the browser to the supplied URL. If the browser is offline or the host blocks the request, a text wordmark is shown. You can rerun `.venv/bin/python portal_brand.py` (`.venv\Scripts\python.exe` on Windows) after network access is available. The cloud build host could not fetch the image because its outbound policy blocked www.walkaroo.in, so no downloaded logo image is claimed to be bundled in this ZIP. The source URL and fallback behavior were verified.

`portal.py --open-browser` can open the app's root screen after the local server binds. The outer final Windows launcher uses this option at port 8870, keeping it distinct from the original app's port 8765. Desktop browser opening and the Windows launchers require acceptance on the user's Windows host.

For an existing installation, stop the portal and back up its folder. Copy this package's `application` folder into the existing installation, merging and replacing application files. The distributed ZIP contains no account/sales databases, source-folder settings or Python virtual environment, so those existing local files remain. Restart the existing updated-portal launcher and press Ctrl+F5 in the browser. Never delete the old application/data folder while upgrading.


## Excel-only Data connections workspace

The duplicate Microsoft Fabric connection card is no longer displayed in **Excel & pivot workspace → Data connections**. The Excel archive fills the available workspace width. Use **Back to Analytics Studio → Fabric connections** for Microsoft Fabric setup. The original connector event-handler elements remain hidden in the DOM so that the untouched original JavaScript can initialize normally. No original import, pivot, master or calculation code was changed.

The Excel/pivot workspace sidebar uses light grey (#f1f2f4), retaining the Walkaroo logo and red active-navigation highlight.
