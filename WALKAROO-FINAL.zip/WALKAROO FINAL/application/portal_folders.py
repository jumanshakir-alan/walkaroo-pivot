"""Administrator-selected sales source folder; original import functions stay intact."""
import os
from pathlib import Path
import subprocess
import sys

import app


def checked_folder(value):
    if not isinstance(value, str) or not value.strip() or len(value) > 2048:
        raise ValueError('Choose or paste a sales folder path.')
    # Windows Explorer's Copy as path includes outer double quotes.
    value = value.strip().strip('"')
    path = Path(value).expanduser()
    if not path.is_absolute():
        raise ValueError('Enter a full folder path, for example D:\\Sales\\Excel files.')
    try:
        path = path.resolve(strict=True)
        if not path.is_dir():
            raise ValueError('Choose a folder, not an individual workbook.')
        with os.scandir(path) as entries:
            next(entries, None)
    except OSError:
        raise ValueError('The application cannot read this folder. Check the path and Windows folder permissions.') from None
    return path


def restore_folder(store):
    saved = store.get_object('settings', 'sales-folder')
    if saved:
        # Keep a temporarily disconnected drive selected. Requiring the user to
        # choose it again would hide the reason their source files are missing.
        app.FILES = Path(saved['path'])


def folder_info():
    path = app.FILES
    try:
        readable = path.is_dir()
        count = sum(1 for p in path.glob('*.xlsx') if not p.name.startswith('~$')) if readable else 0
    except OSError:
        readable, count = False, 0
    return {'path': str(path), 'exists': readable, 'excelFiles': count}


def save_folder(store, actor, value):
    store.require_admin(actor)
    with app.LOCK:
        if app.current_job()['running']:
            raise ValueError('Wait for the current import, refresh or removal to finish before changing the folder.')
        path = checked_folder(value)
        store.put_object('settings', 'sales-folder', actor['id'], {'path': str(path)})
        app.FILES = path
        store.audit(actor, 'sales.folder.save')
        return folder_info()


def browse_folder():
    """Open the chooser on the application host, not the remote browser client."""
    if sys.platform == 'win32':
        script = '''
Add-Type -AssemblyName System.Windows.Forms
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = 'Select the folder containing your sales Excel workbooks'
$dialog.ShowNewFolderButton = $false
if (Test-Path -LiteralPath $env:WALKAROO_FOLDER_INITIAL -PathType Container) {
  $dialog.SelectedPath = $env:WALKAROO_FOLDER_INITIAL
}
if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
  [Console]::Write($dialog.SelectedPath)
}
$dialog.Dispose()
'''
        environment = os.environ.copy()
        environment['WALKAROO_FOLDER_INITIAL'] = str(app.FILES)
        command = ['powershell.exe', '-NoProfile', '-STA', '-Command', script]
    else:
        environment = None
        script = '''import sys, tkinter as tk
from tkinter import filedialog
root=tk.Tk()
root.withdraw()
try:
    result=filedialog.askdirectory(title='Select sales Excel folder', initialdir=sys.argv[1], mustexist=True)
    print(result, end='')
finally:
    root.destroy()
'''
        command = [sys.executable, '-c', script, str(app.FILES)]
    try:
        result = subprocess.run(command, capture_output=True, encoding='utf-8',
            errors='replace', env=environment, timeout=180, check=False)
    except (OSError, subprocess.TimeoutExpired):
        raise ValueError('The folder picker is unavailable. Paste the full folder path and click Use this folder.') from None
    if result.returncode:
        raise ValueError('The folder picker could not open on the application host. Paste the full folder path instead.')
    value = result.stdout.strip().lstrip('\ufeff')
    return {'path': str(checked_folder(value)) if value else None, 'cancelled': not bool(value)}
