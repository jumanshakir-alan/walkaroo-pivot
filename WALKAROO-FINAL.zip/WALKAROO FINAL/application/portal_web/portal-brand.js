/* Shared brand presentation. No import, query, master or permission logic. */
(() => {
  'use strict';
  const ns='http://www.w3.org/2000/svg';
  const icons={
    library:['M3 3h7v7H3z','M14 3h7v7h-7z','M3 14h7v7H3z','M14 14h7v7h-7z'],
    studio:['M4 4h16v16H4z','M4 10h16','M10 10v10','M14 14h3','M14 17h3'],
    connections:['M9 7H5a3 3 0 0 0-3 3v4a3 3 0 0 0 3 3h4','M15 7h4a3 3 0 0 1 3 3v4a3 3 0 0 1-3 3h-4','M8 12h8','M13 9l3 3-3 3'],
    themes:['M12 3a9 9 0 1 0 0 18h1a2 2 0 0 0 1-3.7 1.5 1.5 0 0 1 1-2.7h2A4 4 0 0 0 21 10a9 9 0 0 0-9-7Z','M7 9h.01','M11 6h.01','M16 8h.01','M6 14h.01'],
    access:['M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2','M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z','M22 21v-2a4 4 0 0 0-3-3.87','M16 3.13a4 4 0 0 1 0 7.75'],
    legacy:['M4 4h16v16H4z','M4 10h16','M10 4v16','M14 14h3','M14 17h3'],
    search:['M21 21l-5-5','M10.5 18a7.5 7.5 0 1 0 0-15 7.5 7.5 0 0 0 0 15Z'],
    logout:['M9 21H4V3h5','M12 12h9','M17 8l4 4-4 4'],
    account:['M20 21a8 8 0 0 0-16 0','M12 13a5 5 0 1 0 0-10 5 5 0 0 0 0 10Z']
  };
  function icon(name){const svg=document.createElementNS(ns,'svg');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('fill','none');svg.setAttribute('stroke','currentColor');svg.setAttribute('stroke-width','1.7');svg.setAttribute('stroke-linecap','round');svg.setAttribute('stroke-linejoin','round');svg.setAttribute('aria-hidden','true');for(const d of icons[name]||icons.library){const path=document.createElementNS(ns,'path');path.setAttribute('d',d);svg.append(path);}return svg;}
  function logo(){const lock=document.createElement('div');lock.className='brand-lockup';const wrap=document.createElement('div');wrap.className='brand-logo-wrap';const image=document.createElement('img');image.src='/brand-logo.jpg';image.alt='Walkaroo';image.width=174;image.height=58;image.dataset.brandLogo='';const fallback=document.createElement('span');fallback.className='brand-text-fallback';fallback.textContent='walkaroo';fallback.hidden=true;wrap.append(image,fallback);const product=document.createElement('span');product.className='brand-product';product.textContent='ANALYTICS STUDIO';lock.append(wrap,product);return lock;}
  const legacy=!!document.querySelector('#analyse');
  if(legacy){document.body.classList.add('legacy-enhanced');document.querySelector('.sidebar .logo')?.remove();const brand=document.querySelector('.sidebar .brand');if(brand)brand.replaceChildren(logo());const back=document.createElement('a');back.className='studio-return';back.href='/';back.textContent='← Back to Analytics Studio';document.querySelector('main')?.prepend(back);for(const [id,name] of [['analyse','library'],['sources','connections'],['masters','access']]){const item=document.querySelector('.nav[data-page="'+id+'"]');if(item){const text=item.textContent.replace(/^[^a-zA-Z]+/,'').trim();item.replaceChildren(icon(name),document.createTextNode(text));}}}
  else{for(const [name,label] of [['library','Published pages'],['studio','Dashboard studio'],['connections','Fabric connections'],['themes','Themes'],['access','Users & roles']]){const item=document.querySelector('[data-tab="'+name+'"]');if(item)item.replaceChildren(icon(name),document.createTextNode(label));}const link=document.querySelector('.sidebar a[href="/legacy"]');if(link)link.replaceChildren(icon('legacy'),document.createTextNode('Excel & pivot workspace'));for(const [id,name,label] of [['accountButton','account','My account'],['logout','logout','Sign out']]){const item=document.getElementById(id);if(item)item.replaceChildren(icon(name),document.createTextNode(label));}for(const item of document.querySelectorAll('[data-overview-icon]')){const key={pages:'library',datasets:'connections',themes:'themes',access:'access'}[item.dataset.overviewIcon];item.append(icon(key));}document.querySelector('.search-icon')?.append(icon('search'));}
  if(legacy)for(const element of document.querySelectorAll('button,a'))for(const child of element.childNodes){if(child.nodeType===Node.TEXT_NODE)child.textContent=child.textContent.replaceAll('↗','→');}
  for(const image of document.querySelectorAll('[data-brand-logo]')){
    const fallback=image.parentElement.querySelector('.brand-text-fallback');
    const failed=()=>{image.hidden=true;if(fallback)fallback.hidden=false;};
    image.addEventListener('error',failed);
    image.addEventListener('load',()=>{image.hidden=false;if(fallback)fallback.hidden=true;});
    if(image.complete&&!image.naturalWidth)failed();
  }
})();
