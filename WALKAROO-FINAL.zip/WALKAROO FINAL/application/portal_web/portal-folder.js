/* Add folder configuration to the legacy admin workspace without editing its files. */
(() => {
  'use strict';
  const heading = document.querySelector('#sources .connection-grid > section:nth-child(2)');
  if (!heading) return;
  const make = (tag, text, className) => {
    const e = document.createElement(tag);
    if (text !== undefined) e.textContent = text;
    if (className) e.className = className;
    return e;
  };
  const panel = make('div');
  panel.style.cssText = 'padding:14px;border:1px solid #c9dcd3;border-radius:8px;margin:16px 0;background:#f5faf7';
  const label = make('label', 'Sales Excel folder');
  label.htmlFor = 'salesFolderPath';
  const input = make('input');
  input.id = 'salesFolderPath';
  input.type = 'text';
  input.placeholder = 'Example: D:\\Sales\\001. SQL Data Base';
  input.autocomplete = 'off';
  const actions = make('div');
  actions.style.cssText = 'display:flex;flex-wrap:wrap;gap:8px;margin-top:10px';
  const browse = make('button', 'Browse folder…', 'secondary');
  browse.id = 'browseSalesFolder';
  const use = make('button', 'Use this folder', 'primary');
  use.id = 'useSalesFolder';
  const status = make('p', 'Loading selected folder…', 'hint');
  status.id = 'selectedSalesFolderStatus';
  status.setAttribute('role', 'status');
  const help = make('p', 'Browse opens a folder picker on the computer running the app. You can also paste a full folder path. Selecting a folder lists files; import starts only when you select files and click Import selected files. Existing imported data stays unchanged; use Refresh for a previously imported filename.', 'hint');
  actions.append(browse, use);
  panel.append(label, input, actions, status, help);
  heading.querySelector('h2').after(panel);
  let csrf = '';
  async function request(path, data) {
    if (data !== undefined && !csrf) {
      const session = await (await fetch('/portal-api/session')).json();
      csrf = session.csrf || '';
    }
    const response = await fetch('/portal-api/' + path, data === undefined ? {} : {
      method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrf},
      body: JSON.stringify(data)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Folder operation failed.');
    return result;
  }
  function show(info) {
    input.value = info.path;
    status.textContent = info.exists ? info.excelFiles + ' Excel file(s) in selected folder.' :
      'Folder is unavailable. Choose an existing folder or reconnect its drive.';
  }
  async function save() {
    use.disabled = browse.disabled = true;
    status.textContent = 'Checking folder…';
    try {
      show(await request('sales-folder', {path: input.value}));
      await refresh();
      notice('Sales folder selected. Select the Excel files below, then click Import selected files.');
    } catch (error) {
      status.textContent = error.message;
      notice(error.message, true);
    } finally { use.disabled = browse.disabled = false; }
  }
  use.onclick = save;
  browse.onclick = async () => {
    use.disabled = browse.disabled = true;
    status.textContent = 'Choose a folder in the window opened on the application host…';
    try {
      const result = await request('sales-folder/browse', {});
      if (result.cancelled) {status.textContent = 'Folder selection cancelled.'; return;}
      input.value = result.path;
      status.textContent = 'Folder selected. Click Use this folder to load its file list.';
    } catch (error) {status.textContent = error.message;}
    finally { use.disabled = browse.disabled = false; }
  };
  input.addEventListener('keydown', event => {if (event.key === 'Enter') {event.preventDefault(); save();}});
  request('sales-folder').then(show).catch(error => {status.textContent = error.message;});
})();
