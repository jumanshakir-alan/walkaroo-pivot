"""Run the authenticated extension portal without modifying original business logic."""
import argparse
from collections import defaultdict
from http.cookies import SimpleCookie
import json
from pathlib import Path
import re
import secrets
import threading
import time
from urllib.parse import urlparse

import app
from portal_core import Store, Denied, DIMENSIONS, MAX_BODY, formula, scoped_query, text, validate_theme
from portal_fabric import FabricConnections
import portal_folders
import portal_brand

ROOT = Path(__file__).resolve().parent
LOCK = app.LOCK
ATTEMPTS = defaultdict(list)
STORE = None
FABRIC = FabricConnections(app)
LEGACY_FABRIC = dict(app.FABRIC)
SECURE = False
EXPECTED_HOST = '127.0.0.1:8765'


def datasets(user):
    all_sets = [{'id': 'local', 'name': 'Local Excel model', 'source': 'local', 'table': '', 'connected': True}]
    for connection in STORE.objects('connection'):
        for table in connection['tables']:
            all_sets.append({'id': connection['id'] + ':' + table['id'],
                'name': connection['name'] + ' / ' + table['id'], 'source': 'fabric',
                'table': table['id'], 'connection': connection['id'], 'connected': connection['id'] in FABRIC.live})
    if not user['admin']:
        allowed = STORE.role(user).get('datasets', [])
        all_sets = [d for d in all_sets if d['id'] in allowed]
    return all_sets


def dataset_context(user, dataset_id):
    dataset = next((d for d in datasets(user) if d['id'] == dataset_id), None)
    if dataset is None:
        raise Denied('This dataset is not assigned to your role.')
    if dataset['source'] == 'fabric':
        FABRIC.select(dataset['connection'])
    # Original master links are keyed only by schema/table, not by warehouse.
    # Portal Fabric datasets use warehouse columns to avoid reusing a different
    # warehouse's master link. Local datasets retain the existing master logic.
    fields = (app.base_columns('fabric', dataset['table']) if dataset['source'] == 'fabric'
              else app.columns('local', ''))
    return dataset, fields


def execute_query(user, dataset_id, config, expression=''):
    # Never accept caller-supplied source/table; resolve them from the authorized dataset.
    dataset, fields = dataset_context(user, dataset_id)
    allowed_keys = ('rows', 'column', 'measure', 'measures', 'aggregation', 'filters')
    query = {k: config[k] for k in allowed_keys if k in config}
    query.update(source=dataset['source'], table=dataset['table'])
    mapping = STORE.get_object('mapping', dataset_id) or {}
    query = scoped_query(STORE, user, dataset_id, mapping, query, {f['name'] for f in fields})
    names = {f['name'] for f in fields}
    referenced = list(query.get('rows', [])) + ([query['column']] if query.get('column') else [])
    if query.get('aggregation') != 'count':
        referenced += query.get('measures') or [query.get('measure')]
    referenced += [f.get('field') for f in query['filters']]
    if any(name not in names for name in referenced):
        raise ValueError('Choose fields available in this dataset. For Fabric master attributes, use a prepared warehouse view.')
    # Validate formula even for empty datasets.
    formula(expression, {'m1': 1, 'm2': 1, 'm3': 1})
    result = app.run_pivot(query)
    # SQL is an administrator diagnostic, not part of published page responses.
    result.pop('sql', None)
    if expression.strip():
        count = len(result['groups'])
        measures = result.get('measures') or [result.get('measure', '')]
        totals = result.get('totals') or [result['total']]
        result['derived'] = [formula(expression, {f'm{i+1}': row[count+i]
            for i in range(len(measures))}) for row in result['rows']]
        result['derivedTotal'] = formula(expression, {f'm{i+1}': v for i, v in enumerate(totals)})
    return result


def visible_page(user, page, edit=False):
    if user['admin']:
        return True
    if edit:
        return page['owner'] == user['id'] and STORE.role(user).get('design', False)
    audience = (page.get('snapshot') or {}).get('audience', [])
    return bool(page.get('published')) and (not audience or user['role'] in audience)


def validate_page(user, data):
    STORE.capability(user, 'design')
    oid = data.get('id') or secrets.token_hex(16)
    existing = STORE.get_object('page', oid)
    if existing and not visible_page(user, existing, edit=True):
        raise Denied('You cannot edit this page.')
    name = text(data.get('name'), 'page title', 120)
    widgets = data.get('widgets', [])
    if not isinstance(widgets, list) or not 1 <= len(widgets) <= 12:
        raise ValueError('Add between 1 and 12 visualizations.')
    cleaned = []
    for widget in widgets:
        if not isinstance(widget, dict):
            raise ValueError('Invalid visualization.')
        kind = widget.get('kind', 'bar')
        if kind not in ('bar', 'line', 'area', 'donut', 'table', 'kpi'):
            raise ValueError('Choose a supported visualization.')
        config = widget.get('config')
        if not isinstance(config, dict):
            raise ValueError('Choose a report configuration.')
        dataset_id = text(widget.get('dataset'), 'dataset', 400)
        dataset_context(user, dataset_id)
        expression = widget.get('formula', '')
        formula(expression, {'m1': 1, 'm2': 1, 'm3': 1})
        cleaned.append({'title': text(widget.get('title'), 'visual title', 120),
            'kind': kind, 'dataset': dataset_id, 'config': {k: config[k] for k in
                ('rows', 'column', 'measure', 'measures', 'aggregation', 'filters') if k in config},
            'formula': expression, 'limit': max(1, min(100, int(widget.get('limit', 15))))})
    audience = data.get('audience', [])
    if not isinstance(audience, list) or any(not isinstance(r, str) for r in audience):
        raise ValueError('Choose page audience roles.')
    if not user['admin'] and audience != (existing or {}).get('audience', []):
        raise Denied('Only an administrator can change the page audience.')
    published = bool(data.get('published'))
    if published:
        STORE.capability(user, 'publish')
    theme = data.get('theme', '')
    if theme and STORE.get_object('theme', theme) is None:
        raise ValueError('Choose an existing theme.')
    version = (existing or {}).get('version', 0)
    if existing and data.get('version') != version:
        raise ValueError('This page changed in another session. Reload before saving.')
    # Keep a published snapshot separate from the editable draft.
    payload = {'name': name, 'widgets': cleaned, 'theme': theme, 'audience': audience,
               'published': bool((existing or {}).get('published')), 'version': version+1,
               'updated': time.time(), 'snapshot': (existing or {}).get('snapshot')}
    if published:
        payload['published'] = True
        payload['snapshot'] = {k: payload[k] for k in ('name', 'widgets', 'theme', 'audience', 'version')}
    STORE.put_object('page', oid, existing['owner'] if existing else user['id'], payload)
    STORE.audit(user, 'page.publish' if published else 'page.save', oid)
    return STORE.get_object('page', oid)


class Handler(app.Handler):
    def legacy_request(self, method):
        """Isolate original Fabric state and adapt the already-verified public Host."""
        previous = dict(app.FABRIC)
        original_host = self.headers.get('Host')
        app.FABRIC.update(LEGACY_FABRIC)
        self.headers.replace_header('Host', '127.0.0.1:' + str(self.server.server_port))
        try:
            return getattr(super(), method)()
        finally:
            LEGACY_FABRIC.update(app.FABRIC)
            app.FABRIC.update(previous)
            self.headers.replace_header('Host', original_host)

    def security_headers(self):
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'same-origin')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https://www.walkaroo.in; object-src 'none'; base-uri 'self'; frame-ancestors 'none'")

    def respond(self, value, status=200, cookie=None):
        body = json.dumps(value, default=app.json_value, allow_nan=False).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.security_headers()
        if cookie is not None:
            self.send_header('Set-Cookie', cookie)
        self.end_headers()
        self.wfile.write(body)

    def host_ok(self):
        return self.headers.get('Host') == EXPECTED_HOST

    def actor(self, mutate=False):
        cookie = SimpleCookie()
        cookie.load(self.headers.get('Cookie', ''))
        token = cookie.get('walkaroo_session')
        user = STORE.session(token.value if token else '')
        if mutate and not secrets.compare_digest(self.headers.get('X-CSRF-Token', ''), user['csrf']):
            raise Denied('Session verification failed. Reload the page.')
        return user

    def session_cookie(self, value, clear=False):
        return ('walkaroo_session=' + value + '; Path=/; HttpOnly; SameSite=Strict; Max-Age=' +
                ('0' if clear else '28800') + ('; Secure' if SECURE else ''))

    def do_GET(self):
        if not self.host_ok():
            return self.respond({'error': 'Invalid host.'}, 403)
        path = urlparse(self.path).path
        try:
            if path == '/brand-logo.jpg':
                content = portal_brand.logo_bytes()
                self.send_response(200 if content else 302)
                self.security_headers()
                if content:
                    self.send_header('Content-Type', 'image/jpeg')
                else:
                    self.send_header('Location', portal_brand.LOGO_URL)
                self.send_header('Content-Length', str(len(content) if content else 0))
                self.end_headers()
                if content:
                    self.wfile.write(content)
                return
            if path == '/portal-api/session':
                try:
                    user = self.actor()
                except Denied:
                    return self.respond({'user': None, 'needsSetup': not STORE.has_users()})
                return self.respond({'user': {'id': user['id'], 'username': user['username'],
                    'admin': bool(user['admin']), 'role': user['role']}, 'csrf': user['csrf'],
                    'capabilities': {'design': bool(user['admin'] or STORE.role(user).get('design')),
                                     'publish': bool(user['admin'] or STORE.role(user).get('publish'))}})
            if path == '/' or path.startswith('/published/') or path in ('/portal.js', '/portal.css', '/portal-brand.js', '/portal-brand.css', '/portal-red.css'):
                name = 'index.html' if path == '/' or path.startswith('/published/') else path[1:]
                body = (ROOT/'portal_web'/name).read_bytes()
                self.send_response(200)
                self.send_header('Content-Type', {'index.html': 'text/html; charset=utf-8',
                    'portal.js': 'text/javascript; charset=utf-8', 'portal.css': 'text/css; charset=utf-8',
                    'portal-brand.js': 'text/javascript; charset=utf-8', 'portal-brand.css': 'text/css; charset=utf-8', 'portal-red.css': 'text/css; charset=utf-8'}[name])
                self.send_header('Content-Length', str(len(body)))
                self.security_headers()
                self.end_headers()
                return self.wfile.write(body)
            user = self.actor()
            if path == '/portal-api/catalog':
                pages = []
                for p in STORE.objects('page'):
                    if user['admin'] or visible_page(user, p, True) or visible_page(user, p):
                        # Viewer receives only the published version; drafts are never exposed.
                        if not user['admin'] and not visible_page(user, p, True):
                            p = {'id': p['id'], 'owner': p['owner'], 'published': True, **p['snapshot']}
                        pages.append(p)
                return self.respond({'datasets': datasets(user), 'pages': pages, 'themes': STORE.objects('theme')})
            if path == '/portal-api/admin':
                STORE.require_admin(user)
                with STORE.connect() as c:
                    users = [dict(r) for r in c.execute('SELECT id,username,admin,role,active FROM users ORDER BY username')]
                    roles = [{'id': r['id'], **json.loads(r['data'])} for r in c.execute('SELECT * FROM roles')]
                    audit = [dict(r) for r in c.execute('SELECT * FROM audit ORDER BY at DESC LIMIT 100')]
                return self.respond({'users': users, 'roles': roles, 'audit': audit,
                    'connections': [{**v, 'connected': v['id'] in FABRIC.live} for v in STORE.objects('connection')],
                    'mappings': STORE.objects('mapping')})
            # Original routes remain available ONLY to administrators.
            STORE.require_admin(user)
            if path == '/portal-api/sales-folder':
                return self.respond(portal_folders.folder_info())
            if path in ('/legacy', '/portal-folder.js'):
                if path == '/legacy':
                    content = (ROOT/'web'/'index.html').read_text(encoding='utf-8')
                    content = content.replace('__APP_TOKEN__', app.TOKEN)
                    content = content.replace('</head>', '<link rel="stylesheet" href="/portal-brand.css"></head>')
                    content = content.replace('</body>', '<script src="/portal-folder.js"></script><script src="/portal-brand.js"></script></body>')
                    body, content_type = content.encode(), 'text/html; charset=utf-8'
                else:
                    body = (ROOT/'portal_web'/'portal-folder.js').read_bytes()
                    content_type = 'text/javascript; charset=utf-8'
                self.send_response(200)
                self.send_header('Content-Type', content_type)
                self.send_header('Content-Length', str(len(body)))
                self.security_headers()
                self.end_headers()
                return self.wfile.write(body)
            with LOCK:
                return self.legacy_request('do_GET')
        except Denied as e:
            return self.respond({'error': str(e)}, 403)
        except (ValueError, KeyError, TypeError) as e:
            return self.respond({'error': str(e)}, 400)
        except Exception:
            return self.respond({'error': 'The request failed. Check server setup and data availability.'}, 500)

    def do_POST(self):
        if not self.host_ok():
            return self.respond({'error': 'Invalid host.'}, 403)
        origin = self.headers.get('Origin')
        if origin and origin != ('https://' if SECURE else 'http://') + EXPECTED_HOST:
            return self.respond({'error': 'Invalid request origin.'}, 403)
        path = urlparse(self.path).path
        try:
            if not path.startswith('/portal-api/'):
                user = self.actor()
                STORE.require_admin(user)
                # Original routes use their original X-App-Token protection.
                with LOCK:
                    return self.legacy_request('do_POST')
            if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                raise ValueError('Use application/json.')
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= MAX_BODY:
                raise ValueError('Invalid request size.')
            data = json.loads(self.rfile.read(length))
            if not isinstance(data, dict):
                raise ValueError('Expected a JSON object.')
            # A native dialog must not hold the shared data/connection lock.
            if path == '/portal-api/sales-folder/browse':
                user = self.actor(mutate=True)
                STORE.require_admin(user)
                return self.respond(portal_folders.browse_folder())
            with LOCK:
                if path in ('/portal-api/login', '/portal-api/bootstrap'):
                    now, key = time.time(), self.client_address[0]
                    ATTEMPTS[key] = [v for v in ATTEMPTS[key] if now-v < 600]
                    if len(ATTEMPTS[key]) >= 10:
                        return self.respond({'error': 'Too many attempts. Try again in ten minutes.'}, 429)
                    ATTEMPTS[key].append(now)
                    if path.endswith('/bootstrap'):
                        return self.respond(STORE.bootstrap(data))
                    token = STORE.login(data)
                    ATTEMPTS.pop(key, None)
                    return self.respond({'message': 'Signed in.'}, cookie=self.session_cookie(token))
                user = self.actor(mutate=True)
                if path == '/portal-api/logout':
                    with STORE.connect() as c:
                        c.execute('DELETE FROM sessions WHERE user_id=? AND csrf=?', (user['id'], user['csrf']))
                    return self.respond({'message': 'Signed out.'}, cookie=self.session_cookie('', True))
                if path == '/portal-api/password':
                    from portal_core import password_matches, password_hash
                    if not password_matches(data.get('current'), user['password']):
                        raise Denied('Current password is incorrect.')
                    hashed = password_hash(data.get('password'))
                    with STORE.connect() as c:
                        c.execute('UPDATE users SET password=? WHERE id=?', (hashed, user['id']))
                        c.execute('DELETE FROM sessions WHERE user_id=?', (user['id'],))
                    STORE.audit(user, 'password.change')
                    return self.respond({'message': 'Password changed. Sign in again.'}, cookie=self.session_cookie('', True))
                if path == '/portal-api/columns':
                    _, fields = dataset_context(user, data.get('dataset'))
                    return self.respond(fields)
                if path == '/portal-api/query':
                    STORE.capability(user, 'design')
                    return self.respond(execute_query(user, data.get('dataset'), data.get('config', {}), data.get('formula', '')))
                if path == '/portal-api/page':
                    return self.respond(validate_page(user, data))
                if path == '/portal-api/page-data':
                    page = STORE.get_object('page', data.get('id'))
                    if page is None or not visible_page(user, page):
                        raise Denied('Published page is unavailable for your role.')
                    snapshot = page.get('snapshot')
                    if not page.get('published') or not snapshot:
                        raise Denied('This page has not been published.')
                    if not user['admin'] and snapshot.get('audience') and user['role'] not in snapshot['audience']:
                        raise Denied('This page is unavailable for your role.')
                    visuals = []
                    for widget in snapshot['widgets']:
                        try:
                            visuals.append({'result': execute_query(user, widget['dataset'], widget['config'], widget['formula'])})
                        except (Denied, ValueError) as e:
                            visuals.append({'error': str(e)})
                    return self.respond({'page': snapshot, 'visuals': visuals})
                if path == '/portal-api/unpublish':
                    STORE.capability(user, 'publish')
                    page = STORE.get_object('page', data.get('id'))
                    if not page or not visible_page(user, page, True):
                        raise Denied('You cannot unpublish this page.')
                    STORE.put_object('page', page['id'], page['owner'], {k: v for k, v in page.items()
                        if k not in ('id', 'owner')} | {'published': False, 'snapshot': None, 'version': page['version']+1})
                    STORE.audit(user, 'page.unpublish', page['id'])
                    return self.respond({'message': 'Page unpublished.'})
                if path == '/portal-api/theme':
                    STORE.require_admin(user)
                    theme = validate_theme(data)
                    oid = data.get('id') or secrets.token_hex(16)
                    STORE.put_object('theme', oid, user['id'], theme)
                    STORE.audit(user, 'theme.save', oid)
                    return self.respond({'id': oid, **theme})
                STORE.require_admin(user)
                if path == '/portal-api/sales-folder':
                    return self.respond(portal_folders.save_folder(STORE, user, data.get('path')))
                if path == '/portal-api/role':
                    return self.respond(STORE.save_role(user, data))
                if path == '/portal-api/user':
                    return self.respond(STORE.save_user(user, data))
                if path == '/portal-api/mapping':
                    dataset, fields = dataset_context(user, data.get('dataset'))
                    names = {f['name'] for f in fields}
                    mapping = {k: data.get(k, '') for k in DIMENSIONS}
                    if any(v and v not in names for v in mapping.values()):
                        raise ValueError('Choose fields from this dataset.')
                    STORE.put_object('mapping', dataset['id'], user['id'], mapping)
                    STORE.audit(user, 'mapping.save', dataset['id'])
                    return self.respond({'message': 'Security field mappings saved.'})
                if path in ('/portal-api/fabric/test', '/portal-api/fabric/connect'):
                    result = FABRIC.connect(data, STORE, user, test_only=path.endswith('/test'))
                    STORE.audit(user, 'fabric.test' if path.endswith('/test') else 'fabric.connect', result.get('id', ''))
                    return self.respond(result)
                return self.respond({'error': 'Unknown endpoint.'}, 404)
        except Denied as e:
            return self.respond({'error': str(e)}, 403)
        except (ValueError, KeyError, TypeError, IndexError) as e:
            return self.respond({'error': str(e)}, 400)
        except Exception:
            # Do not return ODBC/SQLite exception text with sensitive connection details.
            return self.respond({'error': 'The operation failed. Check data availability and server prerequisites.'}, 500)

    def log_message(self, format, *args):
        # Standard paths/status only; request bodies, credentials and session tokens are never logged.
        pass


def main():
    global STORE, EXPECTED_HOST, SECURE
    parser = argparse.ArgumentParser(description='Walkaroo authenticated analytics portal')
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--open-browser', action='store_true', help='Open the portal in the host desktop browser')
    parser.add_argument('--public-url', help='HTTPS origin used by an external TLS reverse proxy')
    args = parser.parse_args()
    if args.public_url:
        url = urlparse(args.public_url)
        if url.scheme != 'https' or not url.netloc or url.path not in ('', '/') or url.query or url.fragment:
            parser.error('--public-url must be an HTTPS origin, for example https://analytics.example.com')
        EXPECTED_HOST, SECURE = url.netloc, True
    else:
        if args.host not in ('127.0.0.1', 'localhost'):
            parser.error('Network access requires --public-url and an HTTPS reverse proxy. See README_FINAL.md.')
        EXPECTED_HOST = '127.0.0.1:' + str(args.port)
    STORE = Store(ROOT/'data')
    portal_folders.restore_folder(STORE)
    app.local().close()
    if not STORE.has_users():
        print('First run: enter the token from data/bootstrap.token on the setup screen. Never share this file.', flush=True)
    server = app.ThreadingHTTPServer((args.host, args.port), Handler)
    server.daemon_threads = True
    print('Walkaroo portal started. Use the configured origin; see README_FINAL.md.', flush=True)
    if args.open_browser:
        origin = args.public_url or 'http://127.0.0.1:' + str(args.port)
        opener = threading.Timer(0.8, lambda: app.webbrowser.open(origin))
        opener.daemon = True
        opener.start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
