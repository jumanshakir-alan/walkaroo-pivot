@echo off
setlocal
title WALKAROO FINAL - Analytics Studio - Port 8870
cd /d "%~dp0application"
if not exist ".venv\Scripts\python.exe" (
  echo Run SETUP WALKAROO.cmd first.
  pause
  exit /b 1
)
echo ===========================================================
echo WALKAROO FINAL - RED BRAND EDITION
echo The updated portal address is http://127.0.0.1:8870/
echo Your browser will open automatically after startup.
echo On first run, read application\data\bootstrap.token.
echo Keep this console open. Press Ctrl+C to stop.
echo ===========================================================
.venv\Scripts\python.exe portal.py --host 127.0.0.1 --port 8870 --open-browser
if errorlevel 1 (
  echo The portal did not start. Review the error above.
  echo Stop any previous portal console using port 8870 before restarting.
  pause
  exit /b 1
)
