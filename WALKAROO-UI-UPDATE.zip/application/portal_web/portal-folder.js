/* Add folder configuration to the legacy admin workspace without editing its files. */
(() => {
  'use strict';
  const heading = document.querySelector('#sources .connection-grid > section:nth-child(2)');
  if (!heading) return;
  const make = (tag, text, className) => {
    const e = document.createElement(tag);
    if (text !== undefined) e.textContent = text;
    if (className) e.className = className;
    return e;
  };
  const panel = make('div');
  panel.className = 'compact-folder-picker';
  panel.style.cssText = 'padding:14px;border:1px solid #c9dcd3;border-radius:8px;margin:16px 0;background:#f5faf7';
  const label = make('label', 'Sales Excel folder');
  label.htmlFor = 'salesFolderPath';
  const input = make('input');
  input.id = 'salesFolderPath';
  input.type = 'text';
  input.placeholder = 'Example: D:\\Sales\\001. SQL Data Base';
  input.autocomplete = 'off';
  const pathRow = make('div', undefined, 'folder-path-row');
  const actions = make('div');
  actions.style.cssText = 'display:flex;flex-wrap:wrap;gap:8px;margin-top:10px';
  const browse = make('button', 'Browse folder…', 'secondary');
  browse.id = 'browseSalesFolder';
  const use = make('button', 'Use this folder', 'primary');
  use.id = 'useSalesFolder';
  const status = make('p', 'Loading selected folder…', 'hint');
  status.id = 'selectedSalesFolderStatus';
  status.setAttribute('role', 'status');
  const help = make('p', 'Browse opens a folder picker on the computer running the app. You can also paste a full folder path. Selecting a folder lists files; import starts only when you select files and click Import selected files. Existing imported data stays unchanged; use Refresh for a previously imported filename.', 'hint');
  actions.append(browse, use);
  pathRow.append(input, actions);
  panel.append(label, pathRow, status);
  heading.querySelector('h2').after(panel);

  // Move the existing controls, retaining their IDs, listeners and import logic.
  heading.classList.add('archive-workspace-compact');
  const title = heading.querySelector('h2');
  const eyebrow = heading.querySelector(':scope > .eyebrow');
  const archiveHeading = make('div', undefined, 'archive-heading');
  const titleGroup = make('div');
  if (eyebrow) titleGroup.append(eyebrow);
  titleGroup.append(title);
  const steps = make('span', '1  Choose folder   /   2  Select files   /   3  Import', 'archive-steps');
  archiveHeading.append(titleGroup, steps);
  heading.prepend(archiveHeading);

  const guidance = make('details', undefined, 'archive-guidance');
  const guidanceSummary = make('summary', 'Import guidance & file safety');
  const guidanceBody = make('div', undefined, 'archive-guidance-body');
  guidanceBody.append(help);
  const intro = heading.querySelector(':scope > p.muted');
  if (intro) intro.textContent = 'The app reads the Data worksheet when present, otherwise the first sheet. Workbooks stay in your selected folder.';
  for (const item of [...heading.children]) {
    if ((item.tagName === 'P' && item.id !== 'job') || item.classList.contains('warning')) guidanceBody.append(item);
  }
  guidance.append(guidanceSummary, guidanceBody);

  const toolbar = make('div', undefined, 'archive-file-toolbar');
  const search = make('div', undefined, 'archive-search');
  const searchLabel = document.querySelector('label[for="fileSearch"]');
  searchLabel.textContent = 'Find workbooks';
  const searchInput = document.getElementById('fileSearch');
  searchInput.type = 'search';
  searchInput.setAttribute('aria-controls', 'files');
  searchInput.placeholder = 'Search by file name, month or year…';
  search.append(searchLabel, searchInput);
  const folderTools = heading.querySelector('.folder-tools');
  const folderCount = document.getElementById('salesFolderStatus');
  const importButton = document.getElementById('import');
  toolbar.append(search);
  if (folderTools) toolbar.append(folderTools);
  toolbar.append(importButton);

  const summary = make('div', undefined, 'archive-file-summary');
  const selectLabel = make('label', undefined, 'archive-select-ready');
  const selectReady = make('input');
  selectReady.type = 'checkbox';
  selectReady.id = 'selectVisibleReadyFiles';
  selectReady.setAttribute('aria-controls', 'files');
  selectLabel.append(selectReady, document.createTextNode('Select visible ready files'));
  const selectionCount = make('span', '0 selected', 'archive-selection-count');
  selectionCount.id = 'selectedFileCount';
  selectionCount.setAttribute('aria-live', 'polite');
  if (folderCount) summary.append(folderCount);
  summary.append(selectLabel, selectionCount, document.getElementById('job'));
  const safety = make('p', 'Avoid overlapping files: new imports append rows. Use Refresh to replace a previously imported file.', 'archive-safety-note');
  const files = document.getElementById('files');
  files.tabIndex = 0;
  files.setAttribute('role', 'region');
  files.setAttribute('aria-label', 'Sales Excel workbooks. Use the checkboxes to select ready files.');
  heading.append(toolbar, summary, files, safety, guidance);

  function syncSelection() {
    const importedNames = new Set((typeof state !== 'undefined' ? state.files || [] : [])
      .filter(file => file.imported).map(file => file.name));
    for (const row of files.querySelectorAll('.file')) {
      const filename = row.querySelector('.file-choice span')?.textContent || 'workbook';
      const checkbox = row.querySelector('input[type="checkbox"]');
      if (checkbox && importedNames.has(checkbox.value)) checkbox.checked = false;
      row.setAttribute('role', 'group');
      row.setAttribute('aria-label', filename);
      const buttons = row.querySelectorAll('.file-actions button');
      if (buttons[0]) buttons[0].setAttribute('aria-label', 'Refresh ' + filename);
      if (buttons[1]) buttons[1].setAttribute('aria-label', 'Remove ' + filename);
    }
    const ready = [...files.querySelectorAll('.file input[type="checkbox"]:not(:disabled)')];
    const checked = files.querySelectorAll('.file input[type="checkbox"]:checked').length;
    const readyChecked = ready.filter(box => box.checked).length;
    selectionCount.textContent = checked + ' selected';
    selectReady.checked = ready.length > 0 && readyChecked === ready.length;
    selectReady.indeterminate = readyChecked > 0 && readyChecked < ready.length;
    selectReady.disabled = ready.length === 0;
  }
  selectReady.onchange = () => {
    for (const box of files.querySelectorAll('.file input[type="checkbox"]:not(:disabled)')) box.checked = selectReady.checked;
    syncSelection();
  };
  files.addEventListener('change', syncSelection);
  new MutationObserver(syncSelection).observe(files, {childList: true, subtree: true});
  syncSelection();
  let csrf = '';
  async function request(path, data) {
    if (data !== undefined && !csrf) {
      const session = await (await fetch('/portal-api/session')).json();
      csrf = session.csrf || '';
    }
    const response = await fetch('/portal-api/' + path, data === undefined ? {} : {
      method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrf},
      body: JSON.stringify(data)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Folder operation failed.');
    return result;
  }
  function show(info) {
    input.value = info.path;
    input.title = info.path;
    status.textContent = info.exists ? info.excelFiles + ' Excel file(s) in selected folder.' :
      'Folder is unavailable. Choose an existing folder or reconnect its drive.';
  }
  async function save() {
    use.disabled = browse.disabled = true;
    status.textContent = 'Checking folder…';
    try {
      show(await request('sales-folder', {path: input.value}));
      await refresh();
      notice('Sales folder selected. Select the Excel files below, then click Import selected files.');
    } catch (error) {
      status.textContent = error.message;
      notice(error.message, true);
    } finally { use.disabled = browse.disabled = false; }
  }
  use.onclick = save;
  browse.onclick = async () => {
    use.disabled = browse.disabled = true;
    status.textContent = 'Choose a folder in the window opened on the application host…';
    try {
      const result = await request('sales-folder/browse', {});
      if (result.cancelled) {status.textContent = 'Folder selection cancelled.'; return;}
      input.value = result.path;
      status.textContent = 'Folder selected. Click Use this folder to load its file list.';
    } catch (error) {status.textContent = error.message;}
    finally { use.disabled = browse.disabled = false; }
  };
  input.addEventListener('keydown', event => {if (event.key === 'Enter') {event.preventDefault(); save();}});
  request('sales-folder').then(show).catch(error => {status.textContent = error.message;});
})();
