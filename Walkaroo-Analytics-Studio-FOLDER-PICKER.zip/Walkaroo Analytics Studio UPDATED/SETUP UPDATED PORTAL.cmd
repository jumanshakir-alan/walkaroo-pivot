@echo off
setlocal
cd /d "%~dp0application"
call Setup-Final.cmd
exit /b %errorlevel%
