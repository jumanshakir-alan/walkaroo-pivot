@echo off
setlocal
title Walkaroo Analytics Studio UPDATED - Port 8870
cd /d "%~dp0application"
if not exist ".venv\Scripts\python.exe" (
  echo Run SETUP UPDATED PORTAL.cmd from the outer folder first.
  pause
  exit /b 1
)
echo =============================================================
echo WALKAROO ANALYTICS STUDIO - UPDATED PORTAL
 echo Open this NEW address: http://127.0.0.1:8870
 echo You should see a SIGN-IN or ADMINISTRATOR SETUP screen.
 echo On first run, read application\data\bootstrap.token.
 echo Keep this console open. Press Ctrl+C to stop this portal.
echo =============================================================
.venv\Scripts\python.exe portal.py --host 127.0.0.1 --port 8870
if errorlevel 1 (
  echo The updated portal could not start. Read the error above.
  echo If port 8870 is occupied, close its previous portal console first.
  pause
  exit /b 1
)
