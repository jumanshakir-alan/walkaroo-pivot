"""Additive portal storage, authorization and aggregate formula support.

The original application and analytics modules are intentionally unchanged.
"""
import ast
import hashlib
import hmac
import json
import math
import os
from pathlib import Path
import re
import secrets
import sqlite3
import time

DIMENSIONS = ('up_region', 'budget_category', 'business_type')
MAX_BODY = 256 * 1024


class Denied(Exception):
    pass


def text(value, label, maximum=160):
    if not isinstance(value, str) or not value.strip() or len(value) > maximum:
        raise ValueError('Enter a valid ' + label + '.')
    return value.strip()


def password_hash(password):
    if not isinstance(password, str) or not 12 <= len(password) <= 256:
        raise ValueError('Use a password with 12–256 characters.')
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode(), bytes.fromhex(salt), 600000).hex()
    return salt + ':' + digest


def password_matches(password, stored):
    if not isinstance(password, str) or len(password) > 256:
        return False
    salt, expected = stored.split(':')
    actual = hashlib.pbkdf2_hmac('sha256', password.encode(), bytes.fromhex(salt), 600000).hex()
    return hmac.compare_digest(expected, actual)


def formula(expression, values):
    """Small bounded AST interpreter. No eval, calls, SQL or Python execution."""
    if not isinstance(expression, str) or len(expression) > 300:
        raise ValueError('Formula must be at most 300 characters.')
    if not expression.strip():
        return values.get('m1')
    try:
        tree = ast.parse(expression, mode='eval')
    except (SyntaxError, RecursionError):
        raise ValueError('Invalid formula.') from None
    if len(list(ast.walk(tree))) > 80:
        raise ValueError('Formula is too complex.')

    def walk(node):
        if isinstance(node, ast.Expression):
            return walk(node.body)
        if isinstance(node, ast.Constant) and type(node.value) in (int, float):
            result = node.value
        elif isinstance(node, ast.Name) and node.id in ('m1', 'm2', 'm3'):
            result = values.get(node.id)
        elif isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd)):
            v = walk(node.operand)
            result = None if v is None else -v if isinstance(node.op, ast.USub) else v
        elif isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div)):
            left, right = walk(node.left), walk(node.right)
            if left is None or right is None:
                return None
            if isinstance(node.op, ast.Add):
                result = left + right
            elif isinstance(node.op, ast.Sub):
                result = left - right
            elif isinstance(node.op, ast.Mult):
                result = left * right
            else:
                result = None if right == 0 else left / right
        else:
            raise ValueError('Use only m1, m2, m3, numbers, parentheses and + - * /.')
        if result is not None and (not math.isfinite(result) or abs(result) > 1e100):
            raise ValueError('Formula result is outside the supported range.')
        return result
    return walk(tree)


def validate_theme(data):
    result = {'name': text(data.get('name'), 'theme name', 80)}
    for key, fallback in [('primary', '#147d64'), ('background', '#f3f6f8'),
                          ('surface', '#ffffff'), ('text', '#17322d'), ('accent', '#e6a23c')]:
        value = data.get(key, fallback)
        if not isinstance(value, str) or not re.fullmatch(r'#[0-9a-fA-F]{6}', value):
            raise ValueError('Theme colours must be six-digit hexadecimal colours.')
        result[key] = value
    return result


class Store:
    def __init__(self, directory):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.path = self.directory / 'portal.sqlite'
        with self.connect() as c:
            c.executescript('''
                CREATE TABLE IF NOT EXISTS users (
                    id TEXT PRIMARY KEY, username TEXT UNIQUE COLLATE NOCASE,
                    password TEXT NOT NULL, admin INTEGER NOT NULL DEFAULT 0,
                    role TEXT, active INTEGER NOT NULL DEFAULT 1);
                CREATE TABLE IF NOT EXISTS roles (id TEXT PRIMARY KEY, data TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS sessions (
                    token TEXT PRIMARY KEY, user_id TEXT NOT NULL, csrf TEXT NOT NULL, expires REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS objects (
                    kind TEXT, id TEXT, owner TEXT, data TEXT NOT NULL, PRIMARY KEY(kind,id));
                CREATE TABLE IF NOT EXISTS audit (
                    at REAL, user_id TEXT, action TEXT, object_id TEXT);
            ''')
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass
        self.bootstrap_path = self.directory / 'bootstrap.token'
        if not self.has_users() and not self.bootstrap_path.exists():
            fd = os.open(self.bootstrap_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            with os.fdopen(fd, 'w') as f:
                f.write(secrets.token_urlsafe(32))
        # A dummy hash prevents an obvious unknown-user timing shortcut.
        self.dummy = password_hash(secrets.token_urlsafe(24))

    def connect(self):
        class Connection(sqlite3.Connection):
            def __exit__(self, *args):
                try:
                    return super().__exit__(*args)
                finally:
                    self.close()
        c = sqlite3.connect(self.path, timeout=30, factory=Connection)
        c.row_factory = sqlite3.Row
        return c

    def has_users(self):
        with self.connect() as c:
            return bool(c.execute('SELECT 1 FROM users LIMIT 1').fetchone())

    def audit(self, user, action, object_id=''):
        with self.connect() as c:
            c.execute('INSERT INTO audit VALUES (?,?,?,?)', (time.time(), user['id'], action, object_id))

    def bootstrap(self, data):
        password = password_hash(data.get('password'))
        username = text(data.get('username'), 'username', 80)
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            if c.execute('SELECT 1 FROM users LIMIT 1').fetchone():
                raise Denied('Administrator already configured.')
            if not self.bootstrap_path.exists() or not hmac.compare_digest(
                    str(data.get('token', '')), self.bootstrap_path.read_text().strip()):
                raise Denied('The setup token is invalid.')
            uid = secrets.token_hex(16)
            c.execute('INSERT INTO users VALUES (?,?,?,?,?,?)', (uid, username, password, 1, None, 1))
        self.bootstrap_path.unlink(missing_ok=True)
        return {'message': 'Administrator created. Sign in to continue.'}

    def login(self, data):
        username = text(data.get('username'), 'username', 80)
        with self.connect() as c:
            user = c.execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()
            valid = password_matches(data.get('password'), user['password'] if user else self.dummy)
            if not user or not valid or not user['active']:
                raise Denied('Invalid username or password.')
            token, csrf = secrets.token_urlsafe(40), secrets.token_urlsafe(32)
            c.execute('DELETE FROM sessions WHERE expires<?', (time.time(),))
            c.execute('INSERT INTO sessions VALUES (?,?,?,?)',
                      (hashlib.sha256(token.encode()).hexdigest(), user['id'], csrf, time.time()+8*3600))
        self.audit(user, 'login')
        return token

    def session(self, token):
        with self.connect() as c:
            row = c.execute('''SELECT u.*, s.csrf FROM sessions s JOIN users u ON u.id=s.user_id
                WHERE s.token=? AND s.expires>? AND u.active=1''',
                (hashlib.sha256(token.encode()).hexdigest(), time.time())).fetchone()
        if row is None:
            raise Denied('Sign in to continue.')
        return dict(row)

    def role(self, user):
        with self.connect() as c:
            row = c.execute('SELECT data FROM roles WHERE id=?', (user['role'],)).fetchone()
        return json.loads(row[0]) if row else {'datasets': [], 'scope': {}, 'design': False, 'publish': False}

    def capability(self, user, capability):
        if not user['admin'] and not self.role(user).get(capability, False):
            raise Denied('Your role does not allow this action.')

    def require_admin(self, user):
        if not user['admin']:
            raise Denied('Administrator access required.')

    def save_role(self, user, data):
        self.require_admin(user)
        data = dict(data)
        requested_id = data.get('id')
        data['name'] = text(data.get('name'), 'role name', 80)
        if not isinstance(data.get('datasets'), list) or len(data['datasets']) > 200 or any(
                not isinstance(v, str) or len(v) > 400 for v in data['datasets']):
            raise ValueError('Choose allowed datasets.')
        scope = data.get('scope')
        if not isinstance(scope, dict) or set(scope) != set(DIMENSIONS):
            raise ValueError('Set all three data access restrictions.')
        for values in scope.values():
            if values is not None and (not isinstance(values, list) or not 1 <= len(values) <= 200 or
                    any(not isinstance(v, str) or len(v) > 200 for v in values)):
                raise ValueError('Use null for all values, or 1–200 exact allowed values.')
        data = {k: data[k] for k in ('name', 'datasets', 'scope')} | {
            'design': bool(data.get('design')), 'publish': bool(data.get('publish'))}
        rid = text(requested_id, 'role ID') if requested_id else None
        # The ID comes from the request, separate from persisted role attributes.
        rid = rid or secrets.token_hex(16)
        with self.connect() as c:
            c.execute('INSERT INTO roles VALUES (?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data',
                      (rid, json.dumps(data)))
        self.audit(user, 'role.save', rid)
        return {'id': rid, **data}

    def save_user(self, actor, data):
        self.require_admin(actor)
        uid = data.get('id') or secrets.token_hex(16)
        username = text(data.get('username'), 'username', 80)
        admin, active, role = bool(data.get('admin')), bool(data.get('active', True)), data.get('role') or None
        hashed = password_hash(data['password']) if data.get('password') else None
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            existing = c.execute('SELECT * FROM users WHERE id=?', (uid,)).fetchone()
            if not existing and not hashed:
                raise ValueError('A new user needs a password with at least 12 characters.')
            if role and not c.execute('SELECT 1 FROM roles WHERE id=?', (role,)).fetchone():
                raise ValueError('Choose an existing role.')
            if existing and existing['admin'] and existing['active'] and not (admin and active):
                if c.execute('SELECT COUNT(*) FROM users WHERE active=1 AND admin=1').fetchone()[0] <= 1:
                    raise ValueError('Keep at least one active administrator.')
            c.execute('''INSERT INTO users VALUES (?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
                username=excluded.username,password=excluded.password,admin=excluded.admin,
                role=excluded.role,active=excluded.active''',
                (uid, username, hashed or existing['password'], admin, role, active))
            c.execute('DELETE FROM sessions WHERE user_id=?', (uid,))
        self.audit(actor, 'user.save', uid)
        return {'id': uid}

    def get_object(self, kind, oid):
        with self.connect() as c:
            row = c.execute('SELECT * FROM objects WHERE kind=? AND id=?', (kind, oid)).fetchone()
        return {'id': row['id'], 'owner': row['owner'], **json.loads(row['data'])} if row else None

    def objects(self, kind):
        with self.connect() as c:
            rows = c.execute('SELECT * FROM objects WHERE kind=? ORDER BY rowid DESC', (kind,)).fetchall()
        return [{'id': r['id'], 'owner': r['owner'], **json.loads(r['data'])} for r in rows]

    def put_object(self, kind, oid, owner, data):
        with self.connect() as c:
            c.execute('INSERT INTO objects VALUES (?,?,?,?) ON CONFLICT(kind,id) DO UPDATE SET data=excluded.data',
                      (kind, oid, owner, json.dumps(data)))


def scoped_query(store, user, dataset, mapping, query, available):
    """Append mandatory AND predicates. A missing mapping fails closed."""
    query = dict(query)
    filters = query.get('filters', [])
    if not isinstance(filters, list) or len(filters) > 25:
        raise ValueError('Choose up to 25 report filters.')
    query['filters'] = list(filters)
    if user['admin']:
        return query
    role = store.role(user)
    if dataset not in role.get('datasets', []):
        raise Denied('This dataset is not assigned to your role.')
    for dimension in DIMENSIONS:
        values = role.get('scope', {}).get(dimension, [])
        if values is None:
            continue
        if not isinstance(values, list) or not values:
            raise Denied('No data access is configured for ' + dimension + '.')
        field = mapping.get(dimension)
        if not field or field not in available:
            raise Denied('An administrator must map the restricted field: ' + dimension + '.')
        query['filters'].append({'field': field, 'values': values})
    return query
