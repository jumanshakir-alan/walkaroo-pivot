@echo off
cd /d "%~dp0"
set "WALKAROO_PYTHON=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%WALKAROO_PYTHON%" (
  "%WALKAROO_PYTHON%" -m venv .venv
) else (
  py -3 -m venv .venv
)
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed
echo Setup complete. Install Microsoft ODBC Driver 18 for SQL Server for Fabric connections.
pause
exit /b 0
:failed
echo Setup failed. Install Python 3.11 or later with the Python launcher and try again.
pause
