"""Fabric connections kept in memory; credentials are never saved to disk."""
import re
import secrets


class FabricConnections:
    def __init__(self, app):
        self.app = app
        self.live = {}

    def open(self, data):
        import pyodbc
        server = str(data.get('server', '')).strip()
        database = str(data.get('database', '')).strip()
        mode = data.get('mode', 'interactive')
        if not re.fullmatch(r'[a-zA-Z0-9.-]+\.datawarehouse\.fabric\.microsoft\.com', server):
            raise ValueError('Enter the Fabric SQL hostname ending in .datawarehouse.fabric.microsoft.com.')
        if not database or len(database) > 128:
            raise ValueError('Enter a warehouse/database name to establish the connection.')
        if mode not in ('interactive', 'password'):
            raise ValueError('Choose Microsoft sign-in or Entra username/password.')
        if 'ODBC Driver 18 for SQL Server' not in pyodbc.drivers():
            raise ValueError('Install Microsoft ODBC Driver 18 for SQL Server on the application host.')
        escape = lambda value: '{' + str(value).replace('}', '}}') + '}'
        connection_string = ('DRIVER={ODBC Driver 18 for SQL Server};SERVER=' + escape(server) +
            ';DATABASE=' + escape(database) + ';Encrypt=yes;TrustServerCertificate=no;')
        if mode == 'password':
            if not data.get('username') or not data.get('password'):
                raise ValueError('Enter your Microsoft Entra username and password.')
            connection_string += ('Authentication=ActiveDirectoryPassword;UID=' + escape(data['username']) +
                                  ';PWD=' + escape(data['password']) + ';')
        else:
            connection_string += 'Authentication=ActiveDirectoryInteractive;'
            if data.get('username'):
                connection_string += 'UID=' + escape(data['username']) + ';'
        try:
            conn = pyodbc.connect(connection_string, timeout=30, autocommit=True)
        except pyodbc.Error:
            # ODBC diagnostics may include connection details; don't echo them to clients or logs.
            raise ValueError('Fabric sign-in failed. Check the endpoint, database, driver and account permissions. '
                             'Password authentication cannot satisfy MFA; use Microsoft sign-in on a supported desktop host.') from None
        conn.timeout = 120
        try:
            cursor = conn.cursor()
            try:
                rows = cursor.execute('SELECT TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,DATA_TYPE '
                    'FROM INFORMATION_SCHEMA.COLUMNS ORDER BY TABLE_SCHEMA,TABLE_NAME,ORDINAL_POSITION').fetchall()
            finally:
                cursor.close()
            tables, mapping = [], {}
            for schema, table, name, dtype in rows:
                key = schema + '.' + table
                if key not in mapping:
                    tables.append({'id': key, 'schema': schema, 'name': table})
                    mapping[key] = []
                mapping[key].append({'name': name, 'numeric': dtype.lower() in self.app.NUMERIC})
            if not tables:
                raise ValueError('Connected, but no readable tables/views are visible to this account.')
            databases, note = [database], ''
            cursor = conn.cursor()
            try:
                databases = [str(row[0]) for row in cursor.execute(
                    'SELECT name FROM sys.databases WHERE HAS_DBACCESS(name)=1 ORDER BY name').fetchall()]
                if database not in databases:
                    databases.append(database)
            except pyodbc.Error:
                note = 'Database enumeration is unavailable; add other warehouse names/endpoints explicitly.'
            finally:
                cursor.close()
            return {'connection': conn, 'tables': tables, 'columns': mapping,
                    'server': server, 'database': database, 'databases': databases, 'note': note}
        except Exception:
            conn.close()
            raise

    def connect(self, data, store, actor, test_only=False):
        existing = store.get_object('connection', data.get('id')) if data.get('id') else None
        if data.get('id') and existing is None:
            raise ValueError('Unknown saved connection.')
        if existing and (existing['server'] != str(data.get('server', '')).strip() or
                         existing['database'] != str(data.get('database', '')).strip()):
            raise ValueError('A saved connection cannot change warehouse identity. Choose Add a new connection.')
        live = self.open(data)
        result = {'tables': live['tables'], 'databases': live['databases'], 'note': live['note'],
                  'message': 'Connection and table/view metadata verified.'}
        if test_only:
            live['connection'].close()
            return result
        cid = data.get('id') or secrets.token_hex(16)
        if data.get('id') and store.get_object('connection', cid) is None:
            live['connection'].close()
            raise ValueError('Unknown saved connection.')
        old = self.live.get(cid)
        self.live[cid] = live
        store.put_object('connection', cid, actor['id'], {
            'name': str(data.get('name') or live['database'])[:100],
            'server': live['server'], 'database': live['database'], 'tables': live['tables']})
        if old:
            old['connection'].close()
        return {**result, 'id': cid}

    def select(self, cid):
        if cid not in self.live:
            raise ValueError('This Fabric connection needs an administrator to reconnect after server restart.')
        selected = self.live[cid]
        self.app.FABRIC.update({k: selected[k] for k in ('connection', 'tables', 'columns')})
        return selected
