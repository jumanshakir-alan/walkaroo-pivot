#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if [ ! -x .venv/bin/python ]; then
  printf '%s\n' 'Run bash setup-final.sh first.' >&2
  exit 1
fi
printf '%s\n' 'Open http://127.0.0.1:8765 after startup. On first run, enter the token from data/bootstrap.token.'
exec .venv/bin/python portal.py --host 127.0.0.1 --port 8765
