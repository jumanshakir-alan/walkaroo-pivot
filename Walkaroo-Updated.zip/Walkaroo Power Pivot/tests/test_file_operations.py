import json
import shutil
import unittest
import uuid
import datetime
import threading
import time
import urllib.request
from pathlib import Path
from unittest.mock import patch
import openpyxl
import app

HEADERS=['Year','Month','GrossValue','Soldtopartycode','Soldtopartyname','CustomerType']
A=[['FY2024-25','July',10,'C1','One','Domestic'],['FY2024-25','September',20,'C2','Two','Domestic']]
B=[['FY2025-26','April',30,'C3','Three','Export']]

class FileOperationTests(unittest.TestCase):
    def setUp(self):
        self.directory=app.ROOT/('test-file-ops-'+uuid.uuid4().hex)
        self.directory.mkdir()
        self.inputs=self.directory/'inputs';self.inputs.mkdir()
        self.patches=[patch.object(app,'DB',self.directory/'sales.sqlite'),patch.object(app,'FILES',self.inputs),patch.object(app,'JOB',{'running':False,'message':'Ready','rows':0})]
        for item in self.patches:item.start()
        self.write('A.xlsx',A);self.write('B.xlsx',B)
        app.import_one_file('A.xlsx');app.import_one_file('B.xlsx')

    def tearDown(self):
        for item in reversed(self.patches):item.stop()
        if not self.directory.resolve().is_relative_to(app.ROOT.resolve()):raise ValueError('Test directory outside workspace')
        shutil.rmtree(self.directory)

    def write(self,name,rows,headers=HEADERS):
        workbook=openpyxl.Workbook();sheet=workbook.active;sheet.title='Data';sheet.append(headers)
        for row in rows:sheet.append(row)
        workbook.save(self.inputs/name);workbook.close()

    def records(self):
        with app.local() as conn:
            return conn.execute('SELECT Soldtopartycode,Soldtopartyname,CAST(GrossValue AS REAL) FROM sales ORDER BY Soldtopartycode').fetchall()

    def test_daily_cumulative_format_refresh_replaces_only_daily_rows(self):
        headers=list(dict.fromkeys(HEADERS+app.DAILY_REPORT_HEADERS+['NetTotal']))
        with app.local() as conn:
            for header in headers:
                if header not in HEADERS:conn.execute('ALTER TABLE sales ADD COLUMN '+app.quote(header)+' TEXT')
            conn.execute("UPDATE metadata SET value=? WHERE key='columns'",(json.dumps([{'name':h,'numeric':h in ['GrossValue','NetTotal','Pairs']} for h in headers]),))
        daily=list(reversed(app.DAILY_REPORT_HEADERS))
        decorated=['\u00a0GrossValue\u00a0' if h=='GrossValue' else h for h in daily]
        values={'Year':'FY2026-27','Month':'October','BillingDate':datetime.datetime(2026,10,29),'Soldtopartycode':'C1','GrossValue':100,'Materialcode':'M1'}
        self.write('Daily Report.xlsx',[[values.get(h) for h in daily]],decorated)
        app.import_one_file('Daily Report.xlsx')
        self.assertEqual(sum(row[2] for row in self.records()),160)
        values['GrossValue']=150
        self.write('Daily Report.xlsx',[[values.get(h) for h in daily]],decorated)
        app.import_one_file('Daily Report.xlsx',True)
        self.assertEqual(sum(row[2] for row in self.records()),210)
        with app.local() as conn:
            self.assertEqual(conn.execute('SELECT COUNT(*) FROM sales').fetchone()[0],4)
            row=conn.execute("SELECT BillingDate,Materialcode,NetTotal FROM sales WHERE Year='FY2026-27'").fetchone()
            self.assertEqual(row,('2026-10-29T00:00:00','M1',None))
        with self.assertRaisesRegex(ValueError,'headings'):
            app.sales_header_order('Daily Report.xlsx',app.DAILY_REPORT_HEADERS[:-1],headers)
        with self.assertRaisesRegex(ValueError,'headings'):
            app.sales_header_order('Other.xlsx',app.DAILY_REPORT_HEADERS,headers)

    def test_refresh_captures_edits_additions_deletions_and_is_idempotent(self):
        self.write('A.xlsx',[['FY2024-25','July',99,'C1','One edited','Domestic'],['FY2024-25','October',7,'C4','Four','B2B']])
        app.import_one_file('A.xlsx',True)
        expected=[('C1','One edited',99.0),('C3','Three',30.0),('C4','Four',7.0)]
        self.assertEqual(self.records(),expected)
        app.import_one_file('A.xlsx',True)
        self.assertEqual(self.records(),expected)
        with app.local() as conn:
            self.assertEqual(conn.execute('SELECT rows FROM imports WHERE name=?',('A.xlsx',)).fetchone()[0],2)
            self.assertEqual(conn.execute("SELECT value FROM metadata WHERE key='data_revision'").fetchone()[0],'4')

    def test_remove_keeps_source_and_other_file_then_allows_reimport(self):
        self.assertEqual(app.remove_imported_file('A.xlsx'),2)
        self.assertTrue((self.inputs/'A.xlsx').exists())
        self.assertEqual(self.records(),[('C3','Three',30.0)])
        app.import_one_file('A.xlsx')
        self.assertEqual(len(self.records()),3)
        app.remove_imported_file('B.xlsx')
        self.assertEqual([row[0] for row in self.records()],['C1','C2'])

    def test_empty_refresh_and_later_nonempty_refresh(self):
        self.write('A.xlsx',[])
        app.import_one_file('A.xlsx',True)
        self.assertEqual(self.records(),[('C3','Three',30.0)])
        self.write('A.xlsx',A[:1]);app.import_one_file('A.xlsx',True)
        self.assertEqual([row[0] for row in self.records()],['C1','C3'])

    def test_legacy_tracking_migrates_without_changing_sales(self):
        before=self.records()
        with app.local() as conn:
            conn.execute('DELETE FROM import_ranges')
            conn.execute('BEGIN') if not conn.in_transaction else None
            app.ensure_file_ranges(conn)
        self.assertEqual(self.records(),before)
        self.write('A.xlsx',A[:1]);app.import_one_file('A.xlsx',True)
        self.assertEqual([row[0] for row in self.records()],['C1','C3'])

    def test_invalid_legacy_history_cannot_remove_wrong_rows(self):
        with app.local() as conn:
            conn.execute('DELETE FROM import_ranges')
            conn.execute('DELETE FROM sales WHERE Soldtopartycode=?',('C1',))
        before=self.records()
        with self.assertRaisesRegex(ValueError,'cannot safely'):
            app.remove_imported_file('B.xlsx')
        self.assertEqual(self.records(),before)

    def test_bad_headers_keep_old_file_data_and_metadata(self):
        before=self.records()
        with app.local() as conn:old=conn.execute('SELECT * FROM imports WHERE name=?',('A.xlsx',)).fetchone()
        self.write('A.xlsx',A,headers=['Changed heading',*HEADERS[1:]])
        with self.assertRaisesRegex(ValueError,'headings'):
            app.import_one_file('A.xlsx',True)
        self.assertEqual(self.records(),before)
        with app.local() as conn:self.assertEqual(conn.execute('SELECT * FROM imports WHERE name=?',('A.xlsx',)).fetchone(),old)

    def test_read_error_rolls_back_staging_and_keeps_old_data(self):
        before=self.records()
        class Sheet:
            @property
            def values(self):
                yield HEADERS
                for _ in range(2001):yield A[0]
                raise ValueError('Broken workbook read')
        class Book:
            sheetnames=['Data']
            def __getitem__(self,key):return Sheet()
            def close(self):pass
        with patch('openpyxl.load_workbook',return_value=Book()):
            with self.assertRaisesRegex(ValueError,'Broken workbook'):
                app.import_one_file('A.xlsx',True)
        self.assertEqual(self.records(),before)
        with app.local() as conn:self.assertFalse(conn.execute("SELECT name FROM sqlite_master WHERE name LIKE 'sales_stage_%'").fetchall())

    def test_workbook_changed_during_refresh_keeps_previous_data(self):
        before=self.records()
        with patch.object(app,'file_digest',side_effect=['before','after']):
            with self.assertRaisesRegex(ValueError,'changed while being read'):
                app.import_one_file('A.xlsx',True)
        self.assertEqual(self.records(),before)

    def test_reordered_columns_align_by_header_name(self):
        self.write('A.xlsx',[list(reversed(row)) for row in A],headers=list(reversed(HEADERS)))
        before=self.records();app.import_one_file('A.xlsx',True)
        self.assertEqual(self.records(),before)

    def test_missing_original_file_stays_listed_and_can_be_removed(self):
        (self.inputs/'A.xlsx').unlink()
        listed=next(f for f in app.file_list() if f['name']=='A.xlsx')
        self.assertTrue(listed['missing']);self.assertTrue(listed['imported'])
        with self.assertRaisesRegex(ValueError,'missing'):
            app.import_one_file('A.xlsx',True)
        app.remove_imported_file('A.xlsx')
        self.assertEqual(self.records(),[('C3','Three',30.0)])

    def test_unchanged_refresh_preserves_customer_master_mapping(self):
        with app.local() as conn:
            conn.execute('INSERT INTO metadata VALUES (?,?)',('master:customer',json.dumps({'links':{'local':{'salesKey':'Soldtopartycode'}}})))
        app.import_one_file('A.xlsx',True)
        with app.local() as conn:
            self.assertEqual(json.loads(conn.execute("SELECT value FROM metadata WHERE key='master:customer'").fetchone()[0])['links']['local']['salesKey'],'Soldtopartycode')

    def test_http_refresh_and_remove_jobs(self):
        server=app.ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        def action(operation,name):
            request=urllib.request.Request(f'http://127.0.0.1:{server.server_port}/api/file/{operation}',data=json.dumps({'name':name}).encode(),headers={'Content-Type':'application/json','X-App-Token':app.TOKEN},method='POST')
            with urllib.request.urlopen(request) as response:self.assertEqual(response.status,200)
            deadline=time.monotonic()+5
            while time.monotonic()<deadline:
                with app.local() as conn:row=conn.execute("SELECT value FROM metadata WHERE key='last_import_job'").fetchone()
                if not app.JOB['running'] and row and json.loads(row[0])['message']==app.JOB['message']:return
                time.sleep(0.01)
            self.fail('File operation did not complete')
        try:
            self.write('A.xlsx',[['FY2024-25','July',101,'C1','Edited','Domestic']])
            action('refresh','A.xlsx')
            self.assertEqual(self.records(),[('C1','Edited',101.0),('C3','Three',30.0)])
            action('remove','B.xlsx')
            self.assertEqual(self.records(),[('C1','Edited',101.0)])
            self.assertTrue((self.inputs/'B.xlsx').exists())
        finally:
            server.shutdown();server.server_close();thread.join()

    def test_invoice_number_with_bad_excel_date_format_keeps_numeric_value(self):
        path=self.inputs/'Dates.xlsx'
        workbook=openpyxl.Workbook();sheet=workbook.active;sheet.title='Data'
        sheet.append(['BillingDate','invoiceNumber','GrossValue'])
        sheet.append([datetime.datetime(2024,7,1),222016100904,10])
        sheet['B2'].number_format='yyyy-mm-dd'
        workbook.save(path);workbook.close()
        with patch.object(app,'DB',self.directory/'dates.sqlite'):
            app.import_one_file('Dates.xlsx')
            with app.local() as conn:
                date,invoice=conn.execute('SELECT BillingDate,invoiceNumber FROM sales').fetchone()
        self.assertEqual(invoice,'222016100904')
        self.assertEqual(date,'2024-07-01T00:00:00')

    def test_indexes_and_cached_pivots_follow_refresh_and_remove(self):
        app.analytics.prepare_indexes(app.local)
        query={'source':'local','rows':['Year'],'measure':'GrossValue','aggregation':'sum'}
        self.assertEqual(app.run_pivot(query)['total'],60)
        self.assertTrue(app.run_pivot(query)['cached'])
        edited=[list(row) for row in A];edited[0][2]=99
        self.write('A.xlsx',edited);app.import_one_file('A.xlsx',True)
        refreshed=app.run_pivot(query)
        self.assertFalse(refreshed['cached']);self.assertEqual(refreshed['total'],149)
        app.remove_imported_file('B.xlsx')
        removed=app.run_pivot(query)
        self.assertFalse(removed['cached']);self.assertEqual(removed['total'],119)

    def test_folder_rescan_discovers_new_files_without_importing_twice(self):
        before=self.records()
        self.write('Sep 2026 -V1.xlsx',[['FY2026-27','September',7,'C4','Four','Domestic']])
        for _ in range(2):
            found=next(f for f in app.file_list() if f['name']=='Sep 2026 -V1.xlsx')
            self.assertFalse(found.get('imported',False));self.assertFalse(found['missing'])
            self.assertEqual(self.records(),before)
        app.import_one_file('Sep 2026 -V1.xlsx')
        app.import_one_file('Sep 2026 -V1.xlsx')
        self.assertEqual(len(self.records()),len(before)+1)

if __name__=='__main__':unittest.main()
