const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const source=fs.readFileSync('web/app.js','utf8');
const fn=source.slice(source.indexOf('async function loadOpeningYearChart('),source.indexOf('function display('));
(async()=>{
 let request,rendered=0,pending;
 const elements={chartTitle:{},chart:{replaceChildren(){}}};
 const context={fields:[{name:'Year'},{name:'GrossValue',numeric:true}],state:{records:100,dataRevision:1},source:'local',chartGeneration:0,fiscalKind:n=>n==='Year'?'year':'',el:()=>({}),$:id=>elements[id],renderSalesChart:()=>rendered++,api:async(_,c)=>{request=c;return {rows:[]};}};
 vm.createContext(context);vm.runInContext(fn,context);
 await context.loadOpeningYearChart();
 assert.equal(request.rows[0],'Year');assert.equal(request.measure,'GrossValue');assert.equal(request.filters.length,0);assert.equal(rendered,1);
 context.api=()=>new Promise(resolve=>pending=resolve);
 const loading=context.loadOpeningYearChart();context.chartGeneration++;pending({rows:[]});await loading;assert.equal(rendered,1);
 context.state.records=0;request=null;await context.loadOpeningYearChart();assert.equal(request,null);
 console.log('Opening chart checks passed: yearly GrossValue, no filters, empty source and stale request protection.');
})().catch(error=>{console.error(error);process.exitCode=1;});
