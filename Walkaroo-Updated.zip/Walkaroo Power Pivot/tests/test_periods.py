import json
import unittest
import app
import test_app

class PeriodAndFilterTests(unittest.TestCase):
    setUp=test_app.PivotTests.setUp
    tearDown=test_app.PivotTests.tearDown

    def add_periods(self):
        with app.local() as conn:
            conn.execute('ALTER TABLE sales ADD COLUMN [Year] TEXT')
            conn.execute('ALTER TABLE sales ADD COLUMN [Month] TEXT')
            conn.execute("UPDATE sales SET Year='FY2024-25',Month='April'")
            conn.execute("UPDATE sales SET Year='FY2025-26',Month='February' WHERE Region='KL'")
            fields=app.base_columns('local')+[{'name':'Year','numeric':False},{'name':'Month','numeric':False}]
            conn.execute("UPDATE metadata SET value=? WHERE key='columns'",(json.dumps(fields),))

    def test_periods_keep_months_with_financial_year(self):
        self.add_periods()
        result=app.period_options({'source':'local'})
        self.assertEqual(result['yearField'],'Year')
        self.assertEqual(result['monthField'],'Month')
        self.assertEqual(sorted(result['periods']),[['FY2024-25','April'],['FY2025-26','February']])

    def test_financial_year_filter_applies_to_total(self):
        self.add_periods()
        result=app.run_pivot({**self.base,'rows':['Year'],'column':'Month','filters':[{'field':'Year','value':'FY2025-26'}]})
        self.assertEqual(result['rows'],[['FY2025-26','February',15.0]])
        self.assertEqual(result['total'],15)

    def test_multi_value_sales_filter(self):
        result=app.run_pivot({**self.base,'filters':[{'field':'Region','values':['TN','KL']},{'field':'Brand','values':['A']}]})
        self.assertEqual(result['total'],30)

    def test_null_filter_and_regular_value(self):
        with app.local() as conn:
            conn.execute("UPDATE sales SET Region=NULL WHERE Region='KL'")
        result=app.run_pivot({**self.base,'filters':[{'field':'Region','values':['TN',None]}]})
        self.assertEqual(result['total'],55)
        result=app.run_pivot({**self.base,'filters':[{'field':'Region','values':[None]}]})
        self.assertEqual(result['total'],15)

    def test_sales_value_search_uses_parameters(self):
        self.assertEqual(app.filter_values({'source':'local','field':'Region','search':'t'})['values'],['TN'])
        self.assertEqual(app.filter_values({'source':'local','field':'Region','search':"' OR 1=1 --"})['values'],[])

    def test_multi_selection_bounds(self):
        for values in [[],['TN']*201,'TN',[10]]:
            with self.assertRaises(ValueError):
                app.run_pivot({**self.base,'filters':[{'field':'Region','values':values}]})

    def test_select_all_with_exceptions_preserves_null(self):
        with app.local() as conn:
            conn.execute("UPDATE sales SET Region=NULL WHERE Region='KL'")
        result=app.run_pivot({**self.base,'filters':[{'field':'Region','values':['TN'],'exclude':True}]})
        self.assertEqual(result['total'],15)
        result=app.run_pivot({**self.base,'filters':[{'field':'Region','values':[None],'exclude':True}]})
        self.assertEqual(result['total'],40)

    def test_header_values_are_not_truncated(self):
        with app.local() as conn:
            conn.executemany('INSERT INTO sales VALUES (?,?,?,?)',[(f'R{i:04d}','A','1','C1') for i in range(605)])
        first=app.filter_values({'source':'local','field':'Region'})
        second=app.filter_values({'source':'local','field':'Region','offset':first['nextOffset']})
        self.assertTrue(first['more'])
        self.assertFalse(second['more'])
        values={v for v in first['values']+second['values'] if v is not None}
        self.assertEqual(len(values),607)
        self.assertIn('R0604',values)

    def test_month_header_respects_selected_year_header(self):
        self.add_periods()
        result=app.filter_values({'source':'local','field':'Month','yearFilters':[{'field':'Year','values':['FY2025-26']}]})
        self.assertEqual([v for v in result['values'] if v is not None],['February'])

    def test_three_values_in_one_pivot(self):
        with app.local() as conn:
            conn.execute('ALTER TABLE sales ADD COLUMN Quantity REAL')
            conn.execute('ALTER TABLE sales ADD COLUMN Tax REAL')
            conn.execute('UPDATE sales SET Quantity=CASE Value WHEN \'10\' THEN 2 WHEN \'30\' THEN 3 WHEN \'20\' THEN 4 ELSE 1 END, Tax=CAST(Value AS REAL)*0.1')
            fields=app.base_columns('local')+[{'name':'Quantity','numeric':True},{'name':'Tax','numeric':True}]
            conn.execute("UPDATE metadata SET value=? WHERE key='columns'",(json.dumps(fields),))
        result=app.run_pivot({**self.base,'measures':['Value','Quantity','Tax']})
        self.assertEqual(result['rows'],[['TN',40.0,5.0,4.0],['KL',15.0,5.0,1.5]])
        self.assertEqual(result['totals'],[55.0,10.0,5.5])
        self.assertEqual(result['measures'],['Value','Quantity','Tax'])
        result=app.run_pivot({**self.base,'measures':['Value','Quantity'],'filters':[{'field':'Region','value':'TN'}]})
        self.assertEqual(result['totals'],[40,5])

    def test_multiple_value_validation(self):
        for measures in [[],['Value','Value'],['Value','bad'],['Value']*4]:
            with self.assertRaises(ValueError):
                app.run_pivot({**self.base,'measures':measures})

    def test_customer_type_alias_filter_includes_case_and_space_variants(self):
        with app.local() as conn:
            conn.execute("UPDATE sales SET Region=CASE Value WHEN '10' THEN 'Domestic' WHEN '30' THEN 'DOMESTIC' WHEN '20' THEN ' Domestic ' ELSE 'Export' END")
        result=app.run_pivot({**self.base,'rows':[],'filters':[{'field':'Region','values':['Domestic','DOMESTIC',' Domestic ']}]})
        self.assertEqual(result['total'],60)

if __name__=='__main__':unittest.main()
