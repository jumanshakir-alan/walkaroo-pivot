import json
import unittest
import app
import analytics
import masterdata
import test_app

class AnalyticsTests(unittest.TestCase):
    setUp=test_app.PivotTests.setUp
    tearDown=test_app.PivotTests.tearDown

    def add_master(self):
        info={'filename':'test.csv','columns':['Code','Zone'],'rows':3,'sheet':'CSV','masterKey':'Code','stripZeros':False,'links':{'local':{'salesKey':'Customer'}},'updated':'same'}
        with app.local() as conn:
            conn.execute('CREATE TABLE master_customer (Code TEXT,Zone TEXT,__wpp_key TEXT UNIQUE)')
            conn.executemany('INSERT INTO master_customer VALUES (?,?,?)',[('C1','North','C1'),('C2','South','C2'),('C3','South','C3')])
            conn.execute('INSERT INTO metadata VALUES (?,?)',('master:customer',json.dumps(info)))

    def trace(self,data):
        statements=[]
        def connect():
            conn=app.local();conn.set_trace_callback(statements.append);return conn
        result=analytics.run_local_pivot(data,connect,app.DB)
        return result,[sql for sql in statements if sql.lstrip().upper().startswith('SELECT') and ' FROM sales' in sql]

    def test_sales_only_skips_unused_master_and_uses_one_scan(self):
        self.add_master()
        result,sql=self.trace(self.base)
        self.assertEqual(result['total'],55)
        self.assertEqual(len(sql),1)
        self.assertNotIn('JOIN',sql[0])

    def test_three_measures_share_one_group_query(self):
        with app.local() as conn:
            conn.execute('ALTER TABLE sales ADD COLUMN Units REAL')
            conn.execute('ALTER TABLE sales ADD COLUMN Tax REAL')
            conn.execute('UPDATE sales SET Units=2,Tax=1')
            fields=app.base_columns('local')+[{'name':'Units','numeric':True},{'name':'Tax','numeric':True}]
            conn.execute("UPDATE metadata SET value=? WHERE key='columns'",(json.dumps(fields),))
        result,sql=self.trace({**self.base,'measures':['Value','Units','Tax']})
        self.assertEqual(result['totals'],[55,8,4])
        self.assertEqual(len(sql),1)

    def test_average_total_uses_weighted_counts_and_nulls(self):
        with app.local() as conn:
            conn.execute("INSERT INTO sales VALUES ('TN','C',NULL,'C4')")
            conn.execute("INSERT INTO sales VALUES ('TN','A','100','C5')")
        result,sql=self.trace({**self.base,'aggregation':'avg'})
        self.assertEqual(result['total'],31)
        self.assertEqual(len(sql),1)

    def test_distinct_total_does_not_sum_group_counts(self):
        with app.local() as conn:conn.execute("UPDATE sales SET Customer='shared'")
        result,sql=self.trace({**self.base,'aggregation':'distinct','measure':'Customer'})
        self.assertEqual(result['total'],1)
        self.assertEqual(len(sql),2)

    def test_cache_is_revision_aware_and_returns_independent_results(self):
        first=app.run_pivot(self.base);second=app.run_pivot(self.base)
        self.assertFalse(first['cached']);self.assertTrue(second['cached'])
        second['rows'][0][-1]=-999
        self.assertNotEqual(app.run_pivot(self.base)['rows'][0][-1],-999)
        with app.local() as conn:
            conn.execute("UPDATE sales SET Value='99' WHERE Value='10'")
            app.bump_data_revision(conn)
        updated=app.run_pivot(self.base)
        self.assertFalse(updated['cached']);self.assertEqual(updated['total'],144)

    def test_master_changes_invalidate_same_query(self):
        self.add_master()
        query={**self.base,'rows':['Customer · Zone']}
        first=app.run_pivot(query)
        with app.local() as conn:
            conn.execute("UPDATE master_customer SET Zone='East' WHERE Code='C1'")
            masterdata.save_link(conn,{'kind':'customer','source':'local','salesKey':'Customer'},app.base_columns('local'))
        updated=app.run_pivot(query)
        self.assertFalse(updated['cached'])
        self.assertIn(['East',40.0],updated['rows'])

    def test_code_lookup_index_is_used(self):
        self.add_master()
        with app.local() as conn:
            conn.executemany('INSERT INTO sales VALUES (?,?,?,?)',[('TN','A','1','Extra'+str(i)) for i in range(1000)])
        created=analytics.prepare_indexes(app.local)
        self.assertTrue(created)
        with app.local() as conn:
            plan=conn.execute('EXPLAIN QUERY PLAN SELECT * FROM sales WHERE '+masterdata.key_expr('Customer',False)+'=?',('C1',)).fetchall()
        self.assertTrue(any('idx_wpp_' in row[3] for row in plan))

if __name__=='__main__':unittest.main()
