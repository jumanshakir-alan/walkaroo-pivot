import json
import tempfile
import shutil
import uuid
import threading
import unittest
import urllib.request
import urllib.error
from pathlib import Path
from unittest.mock import patch
import app

class PivotTests(unittest.TestCase):
    def setUp(self):
        self.testdir = app.ROOT / ('test-run-' + uuid.uuid4().hex)
        self.testdir.mkdir()
        self.old = app.DB
        app.DB = self.testdir / 'model.sqlite'
        with app.local() as c:
            c.execute('CREATE TABLE sales ([Region] TEXT,[Brand] TEXT,[Value] TEXT,[Customer] TEXT)')
            c.executemany('INSERT INTO sales VALUES (?,?,?,?)', [('TN','A','10','C1'),('TN','B','30','C1'),('KL','A','20','C2'),('KL','B','-5','C3')])
            c.execute('INSERT INTO metadata VALUES (?,?)', ('columns',json.dumps([{'name': n,'numeric': n=='Value'} for n in ['Region','Brand','Value','Customer']])))
        self.base={'source':'local','rows':['Region'],'measure':'Value','aggregation':'sum','filters':[]}

    def tearDown(self):
        app.DB=self.old
        shutil.rmtree(self.testdir)

    def test_latest_billing_date_and_revision_refresh(self):
        self.assertIsNone(app.latest_billing_date({'source':'local'})['date'])
        with app.local() as c:
            c.execute('ALTER TABLE sales ADD COLUMN BillingDate TEXT')
            cols=app.base_columns('local')+[{'name':'BillingDate','numeric':False}]
            c.execute("UPDATE metadata SET value=? WHERE key='columns'",(json.dumps(cols),))
            c.execute("UPDATE sales SET BillingDate=CASE Value WHEN '10' THEN '2026-09-30T00:00:00' WHEN '30' THEN '01/10/2026' ELSE 'invalid' END")
        self.assertEqual(app.latest_billing_date({'source':'local'})['date'],'2026-10-01')
        with app.local() as c:
            c.execute("UPDATE sales SET BillingDate='2026-10-25' WHERE Value='20'")
            c.execute("INSERT OR REPLACE INTO metadata VALUES ('data_revision','1')")
        self.assertEqual(app.latest_billing_date({'source':'local'})['date'],'2026-10-25')

    def test_group_and_total(self):
        r=app.run_pivot(self.base)
        self.assertEqual(r['rows'],[['TN',40.0],['KL',15.0]])
        self.assertEqual(r['total'],55)

    def test_filter_and_column(self):
        r=app.run_pivot({**self.base,'column':'Brand','filters':[{'field':'Region','value':'TN'}]})
        self.assertEqual(r['total'],40)
        self.assertEqual(len(r['rows']),2)

    def test_average_and_distinct(self):
        self.assertEqual(app.run_pivot({**self.base,'aggregation':'avg'})['total'],13.75)
        self.assertEqual(app.run_pivot({**self.base,'aggregation':'distinct','measure':'Customer'})['total'],3)

    def test_count_and_empty(self):
        self.assertEqual(app.run_pivot({**self.base,'aggregation':'count','measure':''})['total'],4)
        self.assertEqual(app.run_pivot({**self.base,'filters':[{'field':'Region','value':'missing'}]})['rows'],[])

    def test_query_validation(self):
        for change in [{'rows':['bad']},{'aggregation':'DROP TABLE'},{'measure':'Brand'},{'column':'Region'}]:
            with self.assertRaises(ValueError):
                app.run_pivot({**self.base,**change})
        r=app.run_pivot({**self.base,'filters':[{'field':'Region','value':"TN' OR 1=1 --"}]})
        self.assertIsNone(r['total'])

    def test_fabric_sql_is_read_only(self):
        class Cursor:
            def execute(self,sql,params):
                self.sql=sql
                self.params=params
                self.outer.sqls.append((sql,params))
                return self
            def fetchall(self):return [('TN',40)]
            def fetchone(self):return (40,)
        class Conn:
            def __init__(self):self.sqls=[]
            def cursor(self):
                c=Cursor();c.outer=self;return c
        conn=Conn()
        fake={'connection':conn,'tables':[{'id':'dbo.Sales','schema':'dbo','name':'Sales'}], 'columns':{'dbo.Sales':app.columns('local')}}
        with patch.object(app,'FABRIC',fake):
            app.run_pivot({**self.base,'source':'fabric','table':'dbo.Sales'})
        self.assertTrue(all(sql.startswith('SELECT ') for sql,_ in conn.sqls))
        self.assertIn('"dbo"."Sales"',conn.sqls[0][0])
        self.assertIn('TRY_CONVERT(float,"Value")',conn.sqls[0][0])

    def test_import_failure_rolls_back(self):
        class Sheet:
            @property
            def values(self):
                yield ('Region','Brand','Value','Customer')
                for _ in range(2000):yield ('TN','A',5,'new')
                raise ValueError('broken source')
        class Book:
            sheetnames=['Data']
            def __getitem__(self,key):return Sheet()
            def close(self):pass
        p=self.testdir/'broken.xlsx';p.write_bytes(b'test')
        with patch.object(app,'FILES',self.testdir),patch('openpyxl.load_workbook',return_value=Book()):
            app.import_files(['broken.xlsx'])
        with app.local() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM sales').fetchone()[0],4)
            self.assertEqual(c.execute('SELECT COUNT(*) FROM imports').fetchone()[0],0)
        self.assertIn('broken source',app.JOB['message'])

    def test_session_protection(self):
        server=app.ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            url=f'http://127.0.0.1:{server.server_port}/api/state'
            with self.assertRaises(urllib.error.HTTPError) as context:urllib.request.urlopen(url)
            self.assertEqual(context.exception.code,403)
            request=urllib.request.Request(url,headers={'X-App-Token':app.TOKEN})
            with urllib.request.urlopen(request) as r:self.assertIn('records',json.load(r))
        finally:
            server.shutdown();server.server_close();thread.join()

if __name__=='__main__':unittest.main()
