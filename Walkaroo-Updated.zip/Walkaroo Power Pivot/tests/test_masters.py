import json
import csv
from pathlib import Path
import unittest
import urllib.request
from unittest.mock import patch
import app
import masterdata
import test_app

class MasterTests(unittest.TestCase):
    setUp=test_app.PivotTests.setUp
    tearDown=test_app.PivotTests.tearDown

    def upload(self,kind,content):
        with app.local() as conn:
            conn.execute('BEGIN IMMEDIATE')
            return masterdata.inspect_upload(conn,kind,kind+'.csv',content.encode())

    def link(self,kind,stage,key,sales,**extra):
        data={'kind':kind,'stage':stage,'masterKey':key,'salesKey':sales,'source':'local',**extra}
        with app.local() as conn:
            conn.execute('BEGIN IMMEDIATE')
            return masterdata.save_link(conn,data,app.base_columns('local'))

    def customer(self):
        pending=self.upload('customer','Code,Zone\nC1,North\nC2,North\nC3,South\n')
        return self.link('customer',pending['stage'],'Code','Customer')

    def test_customer_join_and_coverage(self):
        link=self.customer()
        self.assertEqual(link['coverage'],{'matched':4,'unmatched':0,'records':4})
        r=app.run_pivot({**self.base,'rows':['Customer · Zone']})
        self.assertEqual(r['total'],55)
        self.assertEqual(r['rows'],[['North',60.0],['South',-5.0]])

    def test_two_masters_and_filter(self):
        self.customer()
        pending=self.upload('material','Material,Category\nA,Shoes\nB,Sandals\n')
        self.link('material',pending['stage'],'Material','Brand')
        r=app.run_pivot({**self.base,'rows':['Customer · Zone'],'column':'Material (HANA) · Category','filters':[{'field':'Customer · Zone','value':'North'}]})
        self.assertEqual(r['total'],60)
        self.assertEqual(len(r['rows']),2)

    def test_master_multi_select_filters_and_suggestions(self):
        self.customer()
        result=app.run_pivot({**self.base,'filters':[{'field':'Customer · Zone','values':['North','South']},{'field':'Brand','values':['A']}]})
        self.assertEqual(result['total'],30)
        values=app.filter_values({'source':'local','field':'Customer · Zone','search':'nor'})
        self.assertEqual(values['values'],['North'])

    def test_fabric_multi_master_filter(self):
        fake,cursor=self.fabric([('C1',40),('C2',20),('C3',-5)])
        with patch.object(app,'FABRIC',fake):
            result=app.run_pivot({**self.base,'source':'fabric','table':'dbo.Sales','rows':['Customer · Zone'],'filters':[{'field':'Customer · Zone','values':['North','South']}]})
        self.assertEqual(result['total'],55)

    def test_region_options_depend_on_multiple_customer_types(self):
        with app.local() as conn:
            conn.execute('ALTER TABLE sales ADD COLUMN CustomerType TEXT')
            conn.execute("UPDATE sales SET CustomerType=CASE Customer WHEN 'C1' THEN 'DOMESTIC' WHEN 'C2' THEN 'EXPORT' ELSE 'BDS' END")
            fields=app.base_columns('local')+[{'name':'CustomerType','numeric':False}]
            conn.execute("UPDATE metadata SET value=? WHERE key='columns'",(json.dumps(fields),))
        pending=self.upload('customer','Code,UP_Region\nC1,TN\nC2,KL\nC3,BDS\nC4,UNUSED\n')
        self.link('customer',pending['stage'],'Code','Customer')
        request={'source':'local','field':'Customer \u00b7 UP_Region','filters':[{'field':'CustomerType','values':['DOMESTIC']}]}
        self.assertEqual(app.filter_values(request)['values'],['TN'])
        request['filters'][0]['values']=['DOMESTIC','EXPORT']
        self.assertEqual(app.filter_values(request)['values'],['KL','TN'])
        request['filters'][0]['values']=['UNKNOWN']
        self.assertEqual(app.filter_values(request)['values'],[])

    def test_four_quick_filters_accept_multiple_values_together(self):
        with app.local() as conn:
            conn.execute('ALTER TABLE sales ADD COLUMN Year TEXT')
            conn.execute('ALTER TABLE sales ADD COLUMN Month TEXT')
            conn.execute('ALTER TABLE sales ADD COLUMN CustomerType TEXT')
            assignments=[('FY2025-26','January','DOMESTIC','10'),('FY2025-26','February','EXPORT','30'),('FY2026-27','September','DOMESTIC','20'),('FY2026-27','October','DOMESTIC','-5')]
            conn.executemany('UPDATE sales SET Year=?,Month=?,CustomerType=? WHERE Value=?',assignments)
            fields=app.base_columns('local')+[{'name':name,'numeric':False} for name in ['Year','Month','CustomerType']]
            conn.execute("UPDATE metadata SET value=? WHERE key='columns'",(json.dumps(fields),))
        pending=self.upload('customer','Code,UP_Region\nC1,TN\nC2,KL\nC3,TN\n')
        self.link('customer',pending['stage'],'Code','Customer')
        filters=[{'field':'Year','values':['FY2025-26','FY2026-27']},{'field':'Month','values':['January','September']},{'field':'CustomerType','values':['DOMESTIC','EXPORT']},{'field':'Customer · UP_Region','values':['TN','KL']}]
        result=app.run_pivot({**self.base,'filters':filters})
        self.assertEqual(result['total'],30)

    def test_duplicate_replacement_rolls_back_and_can_retry(self):
        self.customer()
        pending=self.upload('customer','Code,Zone\nC1,East\nC1,West\n')
        for _ in range(2):
            with self.assertRaisesRegex(ValueError,'not unique'):
                self.link('customer',pending['stage'],'Code','Customer')
        r=app.run_pivot({**self.base,'rows':['Customer · Zone']})
        self.assertEqual(r['total'],55)
        self.assertEqual(r['rows'][0],['North',60.0])

    def test_blank_key_rejected(self):
        pending=self.upload('customer','Code,Zone\n,North\n')
        with self.assertRaisesRegex(ValueError,'empty key'):
            self.link('customer',pending['stage'],'Code','Customer')

    def test_unmatched_sales_are_preserved(self):
        pending=self.upload('customer','Code,Zone\nC1,North\n')
        linked=self.link('customer',pending['stage'],'Code','Customer')
        self.assertEqual(linked['coverage']['unmatched'],2)
        r=app.run_pivot({**self.base,'rows':['Customer · Zone']})
        self.assertEqual(r['total'],55)
        self.assertIn([None,15.0],r['rows'])

    def test_key_normalization_is_explicit(self):
        with app.local() as c:c.execute("UPDATE sales SET Customer='123'")
        pending=self.upload('customer','Code,Zone\n00123,North\n')
        linked=self.link('customer',pending['stage'],'Code','Customer',stripZeros=True)
        self.assertEqual(linked['coverage']['matched'],4)

    def test_new_sales_use_existing_master(self):
        self.customer()
        with app.local() as c:c.execute("INSERT INTO sales VALUES ('TN','A','5','C1')")
        r=app.run_pivot({**self.base,'rows':['Customer · Zone']})
        self.assertEqual(r['total'],60)
        self.assertEqual(r['rows'][0],['North',65.0])

    def test_master_fields_only_on_linked_sources(self):
        self.customer()
        fake={'connection':None,'tables':[],'columns':{'dbo.Other':app.base_columns('local')}}
        with patch.object(app,'FABRIC',fake):
            self.assertFalse(any(c.get('master') for c in app.columns('fabric','dbo.Other')))

    def fabric(self,rows):
        self.customer()
        self.link('customer',None,'Code','Customer',source='fabric',table='dbo.Sales')
        class Cursor:
            def __init__(self):self.done=False
            def execute(self,sql,params):
                self.sql=sql
                self.params=params
                return self
            def fetchmany(self,size):
                if self.done:return []
                self.done=True
                return rows
            def close(self):pass
        cursor=Cursor()
        class Connection:
            def cursor(self):return cursor
        return {'connection':Connection(),'tables':[{'id':'dbo.Sales','schema':'dbo','name':'Sales'}],'columns':{'dbo.Sales':app.base_columns('local')}},cursor

    def test_fabric_weighted_average(self):
        fake,cursor=self.fabric([('C1',40,2),('C2',20,1),('C3',-5,1)])
        with patch.object(app,'FABRIC',fake):
            r=app.run_pivot({**self.base,'source':'fabric','table':'dbo.Sales','rows':['Customer · Zone'],'aggregation':'avg'})
        self.assertEqual(r['total'],13.75)
        self.assertEqual(r['rows'],[['North',20.0],['South',-5.0]])
        self.assertIn('GROUP BY "Customer"',cursor.sql)
        self.assertNotIn('North',cursor.sql)

    def test_fabric_master_filter_and_distinct(self):
        fake,cursor=self.fabric([('C1',),('C2',),('C3',)])
        with patch.object(app,'FABRIC',fake):
            r=app.run_pivot({**self.base,'source':'fabric','table':'dbo.Sales','rows':[],'aggregation':'distinct','measure':'Customer · Zone','filters':[{'field':'Customer · Zone','value':'North'}]})
        self.assertEqual(r['total'],1)

    def test_fabric_group_limit_rejects_partial_results(self):
        fake,cursor=self.fabric([('C1',40),('C2',20)])
        with patch.object(app,'FABRIC',fake),patch.object(masterdata,'FABRIC_GROUP_LIMIT',1):
            with self.assertRaisesRegex(ValueError,'intermediate'):
                app.run_pivot({**self.base,'source':'fabric','table':'dbo.Sales','rows':['Customer · Zone']})

    def test_invalid_headers_and_malformed_row(self):
        for content in ['Code,Code\nC1,N\n','Code,Zone\nC1,N,extra\n']:
            with self.assertRaises(ValueError):self.upload('customer',content)

    def test_http_upload(self):
        import threading
        server=app.ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            request=urllib.request.Request(f'http://127.0.0.1:{server.server_port}/api/master/upload',data=b'Code,Zone\nC1,North\n',headers={'X-App-Token':app.TOKEN,'X-Master-Kind':'customer','X-File-Name':'customer.csv','Content-Type':'application/octet-stream'},method='POST')
            with urllib.request.urlopen(request) as r:
                uploaded=json.load(r)
            self.assertEqual(uploaded['rows'],1)
            self.assertEqual(uploaded['columns'],['Code','Zone'])
        finally:
            server.shutdown();server.server_close();thread.join()

    def add_soldto_fields(self):
        with app.local() as conn:
            conn.execute('ALTER TABLE sales ADD COLUMN Soldtopartycode TEXT')
            conn.execute('ALTER TABLE sales ADD COLUMN Soldtopartyname TEXT')
            conn.execute("UPDATE sales SET Soldtopartycode=Customer,Soldtopartyname='Name '||Customer")
            fields=app.base_columns('local')+[{'name':'Soldtopartycode','numeric':False},{'name':'Soldtopartyname','numeric':False}]
            conn.execute("UPDATE metadata SET value=? WHERE key='columns'",(json.dumps(fields),))

    def test_unmatched_customer_csv_is_distinct(self):
        self.add_soldto_fields()
        pending=self.upload('customer','Code,Zone\nC1,North\n')
        self.link('customer',pending['stage'],'Code','Customer')
        with app.local() as conn:
            conn.execute("INSERT INTO sales SELECT * FROM sales WHERE Customer='C2'")
        with patch.object(app,'ROOT',self.testdir):
            exported=app.export_unmatched_customers({'source':'local'})
        with Path(exported['path']).open(encoding='utf-8-sig',newline='') as stream:
            rows=list(csv.reader(stream))
        self.assertEqual(exported['customers'],2)
        self.assertEqual(rows[0],['Soldtopartycode','Soldtopartyname'])
        self.assertEqual(set(map(tuple,rows[1:])),{('C2','Name C2'),('C3','Name C3')})

    def test_unmatched_customer_csv_escapes_formula_text(self):
        self.add_soldto_fields()
        pending=self.upload('customer','Code,Zone\nC1,North\n')
        self.link('customer',pending['stage'],'Code','Customer')
        with app.local() as conn:
            conn.execute('UPDATE sales SET Soldtopartyname=? WHERE Customer=?',('=UNTRUSTED,NAME','C2'))
        with patch.object(app,'ROOT',self.testdir):
            exported=app.export_unmatched_customers({'source':'local'})
        with Path(exported['path']).open(encoding='utf-8-sig',newline='') as stream:
            rows=list(csv.reader(stream))
        self.assertIn(['C2',"'=UNTRUSTED,NAME"],rows)

    def test_unmatched_customer_export_requires_saved_link(self):
        self.add_soldto_fields()
        with self.assertRaisesRegex(ValueError,'relationship'):
            app.export_unmatched_customers({'source':'local'})

    def test_unmatched_customer_empty_export_has_headers(self):
        self.add_soldto_fields()
        self.customer()
        with patch.object(app,'ROOT',self.testdir):
            exported=app.export_unmatched_customers({'source':'local'})
        self.assertEqual(exported['customers'],0)
        with Path(exported['path']).open(encoding='utf-8-sig') as stream:
            self.assertEqual(list(csv.reader(stream)),[['Soldtopartycode','Soldtopartyname']])

if __name__=='__main__':unittest.main()
