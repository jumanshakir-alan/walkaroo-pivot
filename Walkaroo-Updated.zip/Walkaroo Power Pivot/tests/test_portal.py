"""Security/behavior regression tests for the additive portal, using synthetic data."""
import copy
import http.cookiejar
import json
from pathlib import Path
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from unittest.mock import patch, Mock

import app
import portal
from portal_core import Store, Denied, formula, password_matches, scoped_query, validate_theme
from portal_fabric import FabricConnections


class PortalTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.store = Store(self.root)
        self.patches = [patch.object(portal, 'STORE', self.store), patch.object(app, 'DB', self.root/'sales.sqlite')]
        for p in self.patches:
            p.start()
        self.store.bootstrap({'username': 'admin', 'password': 'strong-admin-password',
                              'token': self.store.bootstrap_path.read_text()})
        self.admin = self.store.session(self.store.login({'username': 'admin', 'password': 'strong-admin-password'}))
        self.role = self.store.save_role(self.admin, {'name': 'TN retail', 'datasets': ['local'],
            'scope': {'up_region': ['TN'], 'budget_category': ['Budget A'], 'business_type': ['Retail']},
            'design': True, 'publish': True})
        self.store.save_user(self.admin, {'username': 'member', 'password': 'strong-member-password', 'role': self.role['id']})
        self.member = self.store.session(self.store.login({'username': 'member', 'password': 'strong-member-password'}))
        with app.local() as c:
            c.execute('CREATE TABLE sales (UP_Region TEXT,BudgetCategory TEXT,BusinessType TEXT,Year TEXT,Sales REAL,Cost REAL)')
            c.executemany('INSERT INTO sales VALUES (?,?,?,?,?,?)', [
                ('TN','Budget A','Retail','2026',100,60), ('TN','Budget A','Retail','2025',50,20),
                ('KL','Budget A','Retail','2026',1000,500), ('TN','Budget B','Retail','2026',2000,800),
                ('TN','Budget A','Wholesale','2026',4000,2000)])
            c.execute('INSERT INTO metadata VALUES (?,?)', ('columns',json.dumps([
                {'name':name,'numeric':name in ('Sales','Cost')}
                for name in ('UP_Region','BudgetCategory','BusinessType','Year','Sales','Cost')])))
        self.store.put_object('mapping', 'local', self.admin['id'], {
            'up_region': 'UP_Region', 'budget_category': 'BudgetCategory', 'business_type': 'BusinessType'})
        self.config = {'rows': ['Year'], 'measure': 'Sales', 'measures': ['Sales','Cost'],
                       'aggregation': 'sum', 'filters': []}

    def tearDown(self):
        for p in reversed(self.patches):
            p.stop()
        self.tmp.cleanup()

    def page(self, **changes):
        return {'name': 'Restricted sales', 'widgets': [{'title':'Margin','dataset':'local','kind':'bar',
            'config': self.config, 'formula':'(m1-m2)/m1*100'}], 'audience':[self.role['id']],
            'published':True, **changes}

    def test_password_is_hashed_and_invalid_login_fails(self):
        self.assertNotIn('strong-admin-password', self.admin['password'])
        self.assertTrue(password_matches('strong-admin-password', self.admin['password']))
        with self.assertRaises(Denied):
            self.store.login({'username':'admin','password':'wrong-password'})

    def test_bootstrap_is_single_use_and_requires_token(self):
        with self.assertRaises(Denied):
            self.store.bootstrap({'username':'intruder','password':'long-test-password','token':'bad'})
        self.assertFalse(self.store.bootstrap_path.exists())

    def test_all_three_restrictions_and_derived_total(self):
        result=portal.execute_query(self.member,'local',self.config,'(m1-m2)/m1*100')
        self.assertEqual(result['totals'], [150,80])
        self.assertAlmostEqual(result['derivedTotal'], 70/150*100)
        self.assertEqual(sorted(result['derived']), [40,60])
        self.assertNotIn('sql',result)

    def test_caller_cannot_replace_source_or_scope(self):
        result=portal.execute_query(self.member,'local',{**self.config,'source':'fabric','table':'secret',
            'filters':[{'field':'UP_Region','values':['KL'],'exclude':True}]})
        self.assertEqual(result['total'],150)
        result=portal.execute_query(self.member,'local',{**self.config,
            'filters':[{'field':'UP_Region','values':['KL']}]})
        self.assertIsNone(result['total'])

    def test_missing_mapping_fails_closed(self):
        self.store.put_object('mapping','local',self.admin['id'],{})
        with self.assertRaises(Denied):
            portal.execute_query(self.member,'local',self.config)

    def test_unassigned_dataset_fails_closed(self):
        with self.assertRaises(Denied):
            portal.execute_query(self.member,'unknown',self.config)

    def test_admin_keeps_original_totals(self):
        self.assertEqual(portal.execute_query(self.admin,'local',self.config)['total'],7150)

    def test_role_change_applies_to_existing_session(self):
        self.store.save_role(self.admin,{**self.role,'scope':{'up_region':['KL'],
            'budget_category':None,'business_type':None}})
        self.assertEqual(portal.execute_query(self.member,'local',self.config)['total'],1000)

    def test_cache_does_not_cross_scopes(self):
        portal.execute_query(self.admin,'local',self.config)
        self.assertEqual(portal.execute_query(self.member,'local',self.config)['total'],150)

    def test_formula_rejects_code_calls_and_exponents(self):
        for expression in ['__import__("os")','m1.__class__','m1**100','abs(m1)','[m1]', 'm4', 'True']:
            with self.assertRaises(ValueError,msg=expression):
                formula(expression,{'m1':1})
        self.assertIsNone(formula('m1 / m2',{'m1':5,'m2':0}))
        self.assertEqual(formula('-(m1-m2)*100/m1',{'m1':100,'m2':60}),-40)

    def test_theme_values_are_validated(self):
        with self.assertRaises(ValueError):
            validate_theme({'name':'Bad','primary':'red; background:url(https://example.com)'})

    def test_admin_only_mutations_and_last_admin_guard(self):
        with self.assertRaises(Denied):
            self.store.save_user(self.member,{'username':'unauthorized'})
        with self.assertRaises(ValueError):
            self.store.save_user(self.admin,{'id':self.admin['id'],'username':'admin','active':False,'admin':True})

    def test_disabling_user_revokes_session(self):
        token=self.store.login({'username':'member','password':'strong-member-password'})
        self.store.save_user(self.admin,{'id':self.member['id'],'username':'member', 'active':False,'role':self.role['id']})
        with self.assertRaises(Denied):
            self.store.session(token)

    def test_draft_does_not_overwrite_published_snapshot(self):
        page=portal.validate_page(self.admin,self.page())
        saved=portal.validate_page(self.admin,{**page,'name':'Private draft','published':False})
        self.assertEqual(saved['snapshot']['name'],'Restricted sales')
        self.assertEqual(saved['name'],'Private draft')
        self.assertTrue(saved['published'])
        with self.assertRaises(ValueError):
            portal.validate_page(self.admin,{**page,'name':'Stale edit','published':False})

    def test_other_designer_cannot_edit_page(self):
        page=portal.validate_page(self.admin,self.page())
        with self.assertRaises(Denied):
            portal.validate_page(self.member,{**page,'name':'Hijacked'})

    def test_audience_and_publishing_permissions(self):
        page=portal.validate_page(self.admin,self.page(audience=['another-role']))
        self.assertFalse(portal.visible_page(self.member,page))
        self.store.save_role(self.admin,{**self.role,'publish':False})
        with self.assertRaises(Denied):
            portal.validate_page(self.member,self.page(audience=[]))

    def test_fabric_test_does_not_save_credentials(self):
        manager=FabricConnections(app)
        connection=Mock()
        fake={'connection':connection,'tables':[{'id':'dbo.Sales'}],'columns':{},'server':'example',
              'database':'Sales','databases':['Sales'],'note':''}
        with patch.object(manager,'open',return_value=fake):
            manager.connect({'password':'secret'},self.store,self.admin,True)
        connection.close.assert_called_once()
        self.assertEqual(self.store.objects('connection'),[])

    def test_fabric_escapes_password_and_uses_tls(self):
        driver=Mock();driver.drivers.return_value=['ODBC Driver 18 for SQL Server'];driver.Error=Exception
        connection=Mock();driver.connect.return_value=connection
        cursor=Mock();cursor.execute.return_value=cursor
        cursor.fetchall.side_effect=[[('dbo','Sales','Sales','decimal')],[('Sales',)]]
        connection.cursor.return_value=cursor
        with patch.dict('sys.modules',{'pyodbc':driver}):
            result=FabricConnections(app).open({'server':'test.datawarehouse.fabric.microsoft.com','database':'Sales',
                'mode':'password','username':'user@example.com','password':'a};PWD=bad'})
        connection_string=driver.connect.call_args.args[0]
        self.assertIn('Authentication=ActiveDirectoryPassword',connection_string)
        self.assertIn('PWD={a}};PWD=bad}',connection_string)
        self.assertIn('Encrypt=yes;TrustServerCertificate=no',connection_string)
        self.assertEqual(result['tables'][0]['id'],'dbo.Sales')

    def test_http_auth_csrf_and_legacy_are_protected(self):
        server=app.ThreadingHTTPServer(('127.0.0.1',0),portal.Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        base='http://127.0.0.1:'+str(server.server_port)
        jar=http.cookiejar.CookieJar();opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
        def request(path,data=None,csrf=None):
            headers={'Content-Type':'application/json'}
            if csrf:headers['X-CSRF-Token']=csrf
            req=urllib.request.Request(base+path,data=json.dumps(data).encode() if data is not None else None,headers=headers)
            with opener.open(req) as r:return json.load(r)
        with patch.object(portal,'EXPECTED_HOST','127.0.0.1:'+str(server.server_port)):
            try:
                with self.assertRaises(urllib.error.HTTPError):request('/portal-api/catalog')
                request('/portal-api/login',{'username':'member','password':'strong-member-password'})
                session=request('/portal-api/session')
                with self.assertRaises(urllib.error.HTTPError):request('/api/state')
                with self.assertRaises(urllib.error.HTTPError):request('/legacy')
                with self.assertRaises(urllib.error.HTTPError):request('/portal-api/query',{'dataset':'local','config':self.config})
                result=request('/portal-api/query',{'dataset':'local','config':self.config},session['csrf'])
                self.assertEqual(result['total'],150)
                with self.assertRaises(urllib.error.HTTPError):
                    request('/portal-api/user',{'username':'hacker','admin':True},session['csrf'])
                page=portal.validate_page(self.admin,self.page())
                result=request('/portal-api/page-data',{'id':page['id']},session['csrf'])
                self.assertEqual(result['visuals'][0]['result']['total'],150)
                request('/portal-api/logout',{},session['csrf'])
                self.assertIsNone(request('/portal-api/session')['user'])
            finally:
                server.shutdown();server.server_close();thread.join()


if __name__ == '__main__':
    unittest.main()
