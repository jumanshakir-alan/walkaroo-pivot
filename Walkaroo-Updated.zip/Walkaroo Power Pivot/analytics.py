"""Single-pass local pivots with revision-aware bounded result caching."""
import copy
import json
import time
import hashlib
from collections import OrderedDict
import masterdata

CACHE=OrderedDict()
MAX_CACHE=32

def prepare_indexes(connect,progress=lambda message:None):
    """Build persistent indexes for the standard local sales report and lookups."""
    with connect() as conn:
        row=conn.execute("SELECT value FROM metadata WHERE key='columns'").fetchone()
        if not row:return []
        base=json.loads(row[0]);names={f['name'].lower():f['name'] for f in base}
        definitions=[]
        cover=[names[n] for n in ('year','month','customertype','grossvalue','nettotal','pairs','billedqty','soldtopartycode') if n in names]
        if len(cover)>1:definitions.append(('sales reporting',','.join(masterdata.q(name) for name in cover)))
        if 'customertype' in names:definitions.append(('Customer type filter',masterdata.q(names['customertype'])))
        for kind,info in masterdata.models(conn).items():
            link=info.get('links',{}).get('local')
            if link and link['salesKey'] in {f['name'] for f in base}:
                definitions.append((kind+' code lookup',masterdata.key_expr(masterdata.q(link['salesKey']),info['stripZeros'])))
        created=[]
        conn.execute('PRAGMA analysis_limit=1000')
        for title,definition in definitions:
            name='idx_wpp_'+hashlib.sha256(definition.encode()).hexdigest()[:12]
            progress('Optimizing '+title+'…')
            conn.execute('CREATE INDEX IF NOT EXISTS '+masterdata.q(name)+' ON sales ('+definition+')')
            conn.execute('ANALYZE '+masterdata.q(name))
            conn.commit()
            created.append(name)
        return created

def run_local_pivot(data,connect,db_path):
    started=time.perf_counter()
    measures=data.get('measures')
    if measures is None or measures==[] and data.get('aggregation')=='count':measures=[data.get('measure','')]
    if not isinstance(measures,list) or not 1<=len(measures)<=3 or any(not isinstance(m,str) for m in measures) or len(set(measures))!=len(measures):
        raise ValueError('Choose one to three different value headers.')
    groups=list(data.get('rows',[]))
    column=data.get('column','')
    if len(groups)>3 or len(groups)!=len(set(groups)) or column in groups:
        raise ValueError('Choose up to three different row fields and a separate column field.')
    if column:groups.append(column)
    agg=data.get('aggregation','sum')
    if agg not in ('sum','avg','min','max','count','distinct'):raise ValueError('Invalid aggregation.')
    filters=data.get('filters',[])
    if not isinstance(filters,list) or len(filters)>30:raise ValueError('Choose up to 30 report filters.')
    with connect() as conn:
        conn.execute('BEGIN')
        meta={key:value for key,value in conn.execute("SELECT key,value FROM metadata WHERE key IN ('columns','data_revision','master_revision')")}
        base=json.loads(meta.get('columns','[]'))
        active=masterdata.models(conn)
        fields={field['name']:field for field in masterdata.enrich('sales',base,active,'local')[1]}
        if any(name not in fields for name in groups):raise ValueError('Choose valid grouping fields.')
        for measure in measures:
            if agg!='count' and measure not in fields:raise ValueError('Choose a measure.')
            if agg not in ('count','distinct') and not fields[measure]['numeric']:raise ValueError('Choose a numeric measure for this aggregation.')
        for item in filters:
            if item.get('field') not in fields:raise ValueError('Invalid filter.')
            masterdata.filter_selection(item)
        if sum(len(masterdata.filter_selection(item)) for item in filters)>1800:
            raise ValueError('Too many selected values. Choose at most 1,800 values across all filters.')
        core={'groups':groups,'measures':measures,'aggregation':agg,'filters':filters}
        key=(str(db_path.resolve()),meta.get('data_revision','0'),meta.get('master_revision','0'),json.dumps(active,sort_keys=True),json.dumps(core,sort_keys=True))
        if key in CACHE:
            result=copy.deepcopy(CACHE[key]);CACHE.move_to_end(key)
            result.update(cached=True,elapsed_ms=round((time.perf_counter()-started)*1000,2))
            return result
        referenced=groups+[item['field'] for item in filters]+(measures if agg!='count' else [])
        needed={fields[name]['master'] for name in referenced if fields[name].get('master')}
        target=masterdata.enrich('sales',base,active,'local',only=needed)[0] if needed else 'sales'
        expressions=[]
        for measure in measures:
            value='CAST('+masterdata.q(measure)+' AS REAL)'
            expressions.append('COUNT(*)' if agg=='count' else 'COUNT(DISTINCT '+masterdata.q(measure)+')' if agg=='distinct' else agg.upper()+'('+value+')')
        extras=[]
        if agg=='avg':
            for measure in measures:
                value='CAST('+masterdata.q(measure)+' AS REAL)'
                extras.extend(['SUM('+value+')','COUNT('+value+')'])
        conditions=[masterdata.filter_condition(item) for item in filters]
        where=' WHERE '+' AND '.join(clause for clause,_ in conditions) if conditions else ''
        params=[value for _,values in conditions for value in values]
        select=[masterdata.q(name) for name in groups]+[expr+' AS '+masterdata.q('__v'+str(i)) for i,expr in enumerate(expressions)]+extras
        sql='SELECT '+','.join(select)+' FROM '+target+where
        if groups:sql+=' GROUP BY '+','.join(masterdata.q(name) for name in groups)
        sql+=' ORDER BY [__v0] DESC LIMIT 10001'
        raw=conn.execute(sql,params).fetchall()
        if len(raw)>10000:raise ValueError('More than 10,000 groups. Add filters or remove a grouping field; no partial totals are displayed.')
        rows=[list(row[:len(groups)+len(measures)]) for row in raw]
        totals=[]
        if agg=='distinct' and groups:
            total_sql='SELECT '+','.join(expressions)+' FROM '+target+where
            totals=list(conn.execute(total_sql,params).fetchone())
            sql+='\n\n-- Distinct totals across all matching rows:\n'+total_sql
        else:
            for i in range(len(measures)):
                values=[row[len(groups)+i] for row in raw if row[len(groups)+i] is not None]
                if agg=='count':total=sum(values)
                elif agg=='sum':total=sum(values) if values else None
                elif agg=='min':total=min(values) if values else None
                elif agg=='max':total=max(values) if values else None
                elif agg=='distinct':total=values[0] if values else 0
                else:
                    index=len(groups)+len(measures)+2*i
                    total_count=sum(row[index+1] for row in raw)
                    total_sum=sum(row[index] for row in raw if row[index] is not None)
                    total=total_sum/total_count if total_count else None
                totals.append(total)
        result={'groups':groups,'rows':rows,'total':totals[0],'aggregation':agg,'measure':measures[0],'sql':sql,'dataRevision':int(meta.get('data_revision','0'))}
        if len(measures)>1:result.update(measures=measures,totals=totals)
        CACHE[key]=copy.deepcopy(result);CACHE.move_to_end(key)
        while len(CACHE)>MAX_CACHE:CACHE.popitem(last=False)
        result.update(cached=False,elapsed_ms=round((time.perf_counter()-started)*1000,2))
        return result
