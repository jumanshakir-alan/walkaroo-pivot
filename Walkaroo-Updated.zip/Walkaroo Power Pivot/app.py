"""Walkaroo Power Pivot: local analytics and read-only Fabric warehouse queries."""
import argparse
import datetime as dt
import hashlib
import json
import math
import secrets
import sqlite3
import threading
import webbrowser
import csv
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, unquote
import masterdata
import analytics

ROOT = Path(__file__).resolve().parent
FILES = ROOT.parent / '001. SQL Data Base'
DB = ROOT / 'data' / 'sales.sqlite'
TOKEN = secrets.token_urlsafe(32)
LOCK = threading.RLock()
JOB = {'running': False, 'message': 'Ready', 'rows': 0}
FABRIC = {'connection': None, 'tables': [], 'columns': {}}
IMPORT_MONITOR = None
NUMERIC = {'int', 'bigint', 'smallint', 'tinyint', 'decimal', 'numeric', 'float', 'real', 'money', 'smallmoney'}

def current_job():
    return IMPORT_MONITOR if IMPORT_MONITOR is not None else JOB

def monitor_existing_import(port):
    """Allow an in-progress older app to finish before this app changes the model."""
    import re
    import urllib.request
    global IMPORT_MONITOR
    base = f'http://127.0.0.1:{port}'
    page = urllib.request.urlopen(base+'/',timeout=5).read().decode('utf-8-sig')
    token = re.search(r'name="app-token" content="([^"]+)"',page).group(1)
    request = urllib.request.Request(base+'/api/state',headers={'X-App-Token':token})
    def poll():
        global IMPORT_MONITOR
        while True:
            try:
                with urllib.request.urlopen(request,timeout=5) as response:
                    job = json.load(response)['job']
                if not job['running']:
                    JOB.update(job)
                    IMPORT_MONITOR = None
                    return
                IMPORT_MONITOR = job
            except Exception:
                IMPORT_MONITOR = {'running':True,'message':'The previous import session is unavailable. Restart the app after the previous import finishes.','rows':0}
            threading.Event().wait(2)
    with urllib.request.urlopen(request,timeout=5) as response:
        initial = json.load(response)['job']
    if initial['running']:
        IMPORT_MONITOR = initial
        threading.Thread(target=poll,daemon=True).start()
    else:
        JOB.update(initial)

class ManagedConnection(sqlite3.Connection):
    def __exit__(self, *args):
        try:
            return super().__exit__(*args)
        finally:
            self.close()

def local():
    DB.parent.mkdir(exist_ok=True)
    conn = sqlite3.connect(DB, timeout=60, factory=ManagedConnection)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('CREATE TABLE IF NOT EXISTS imports (name TEXT PRIMARY KEY, digest TEXT, rows INTEGER, imported TEXT)')
    conn.execute('CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT)')
    conn.execute('CREATE TABLE IF NOT EXISTS import_ranges (name TEXT PRIMARY KEY, first_rowid INTEGER, last_rowid INTEGER)')
    return conn

def quote(name):
    return masterdata.q(name)

def json_value(value):
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, (dt.date, dt.datetime)):
        return value.isoformat()
    return str(value)

def file_list():
    with local() as conn:
        imported = {r[0]: {'rows': r[1], 'imported': r[2]} for r in conn.execute('SELECT name, rows, imported FROM imports')}
    paths={p.name:p for p in FILES.glob('*.xlsx') if not p.name.startswith('~$')}
    return [{'name':name,'mb':round(paths[name].stat().st_size/1048576,1) if name in paths else None,
        'missing':name not in paths,**imported.get(name,{})} for name in sorted(set(paths)|set(imported))]

def base_columns(source, table=''):
    if source == 'fabric':
        if table not in FABRIC['columns']:
            raise ValueError('Select a connected warehouse table.')
        return FABRIC['columns'][table]
    with local() as conn:
        row = conn.execute("SELECT value FROM metadata WHERE key='columns'").fetchone()
    return json.loads(row[0]) if row else []

def columns(source, table=''):
    base = base_columns(source, table)
    with local() as conn:
        active = masterdata.models(conn)
    return masterdata.enrich('sales',base,active,source,table)[1]

LATEST_BILLING_CACHE = {}

def latest_billing_date(data):
    source,table=data.get('source','local'),data.get('table','')
    base=base_columns(source,table)
    field=next((c['name'] for c in base if ''.join(ch for ch in c['name'].lower() if ch.isalnum())=='billingdate'),None)
    if not field:return {'date':None,'field':None}
    if source=='fabric':
        selected=next(t for t in FABRIC['tables'] if t['id']==table)
        target=quote(selected['schema'])+'.'+quote(selected['name'])
        expr='COALESCE(TRY_CONVERT(date,'+quote(field)+',126),TRY_CONVERT(date,'+quote(field)+',103))'
        cursor=FABRIC['connection'].cursor()
        try:
            cursor.execute('SELECT MAX('+expr+') FROM '+target)
            value=json_value(cursor.fetchone()[0])
        finally:cursor.close()
    else:
        with local() as conn:
            revision=conn.execute("SELECT value FROM metadata WHERE key='data_revision'").fetchone()
            key=(str(DB),revision[0] if revision else '0',field)
            if key in LATEST_BILLING_CACHE:return LATEST_BILLING_CACHE[key]
            expr=quote(field)
            # Imported Excel dates are ISO; also accept day/month/year text.
            value=conn.execute('SELECT MAX(COALESCE(date('+expr+'),date(substr('+expr+',7,4)||\'-\'||substr('+expr+',4,2)||\'-\'||substr('+expr+',1,2)))) FROM sales').fetchone()[0]
        if len(LATEST_BILLING_CACHE)>16:LATEST_BILLING_CACHE.clear()
        LATEST_BILLING_CACHE[key]={'date':value,'field':field}
    return {'date':value,'field':field}

def period_options(data):
    source, table = data.get('source','local'), data.get('table','')
    base = base_columns(source,table)
    normalized = {''.join(ch for ch in c['name'].lower() if ch.isalnum()):c['name'] for c in base}
    year = next((normalized[n] for n in ('financialyear','fiscalyear','fy','year') if n in normalized),None)
    month = next((normalized[n] for n in ('month','monthname','billingmonth') if n in normalized),None)
    if not year or not month:
        return {'yearField':None,'monthField':None,'periods':[]}
    fabric = source=='fabric'
    if fabric:
        selected = next(t for t in FABRIC['tables'] if t['id']==table)
        target = quote(selected['schema'])+'.'+quote(selected['name'])
        conn = FABRIC['connection']
    else:
        conn = local()
        target = 'sales'
    try:
        cursor = conn.cursor()
        sql = 'SELECT DISTINCT '+('TOP (1001) ' if fabric else '')+quote(year)+','+quote(month)+' FROM '+target
        if not fabric:sql+=' LIMIT 1001'
        cursor.execute(sql)
        rows=cursor.fetchall()
        if len(rows)>1000:
            raise ValueError('Too many year/month combinations. Check the source period fields.')
        return {'yearField':year,'monthField':month,'periods':[[json_value(v) for v in row] for row in rows]}
    finally:
        if not fabric:conn.close()

def filter_values(data):
    source,table = data.get('source','local'),data.get('table','')
    field = data.get('field','')
    meta = next((f for f in columns(source,table) if f['name']==field),None)
    if not meta:
        raise ValueError('Choose a field from this sales source or a linked master.')
    dependency_filters=data.get('filters',[])
    if dependency_filters:
        result=run_pivot({'source':source,'table':table,'rows':[field],
            'column':'','measure':'','aggregation':'count','filters':dependency_filters})
        search=data.get('search','')
        offset=data.get('offset',0)
        if not isinstance(search,str) or len(search)>200:
            raise ValueError('Search text is too long.')
        if not isinstance(offset,int) or offset<0 or offset>10000000:
            raise ValueError('Invalid value-list page.')
        values=[None if row[0] is None else str(row[0]) for row in result['rows']]
        values=sorted(set(values),key=lambda value:(value is not None,value or ''))
        if search:values=[value for value in values if search.lower() in (value or '').lower()]
        return {'values':values[offset:offset+500],'more':len(values)>offset+500,'nextOffset':offset+500}
    search = data.get('search','')
    if not isinstance(search,str) or len(search)>200:
        raise ValueError('Search text is too long.')
    offset=data.get('offset',0)
    if not isinstance(offset,int) or offset<0 or offset>10000000:
        raise ValueError('Invalid value-list page.')
    page_size=500
    kind = meta.get('master')
    fabric = source=='fabric' and not kind
    if kind:
        original=field[len(masterdata.KINDS[kind]+' · '):]
        target=quote('master_'+kind)
    elif fabric:
        original=field
        selected=next(t for t in FABRIC['tables'] if t['id']==table)
        target=quote(selected['schema'])+'.'+quote(selected['name'])
    else:
        original,target=field,'sales'
    conn=FABRIC['connection'] if fabric else local()
    cursor=conn.cursor()
    try:
        expr=quote(original)
        search_expr=('CHARINDEX(LOWER(?),LOWER(CAST('+expr+' AS varchar(4000))))>0' if fabric else 'INSTR(LOWER('+expr+'),LOWER(?))>0')
        clauses=[search_expr if search else '1=1']
        params=[search] if search else []
        if not kind and ''.join(ch for ch in field.lower() if ch.isalnum()) in ('month','monthname','billingmonth'):
            for year_filter in data.get('yearFilters',[]):
                name=year_filter.get('field','')
                if name not in {c['name'] for c in base_columns(source,table)} or ''.join(ch for ch in name.lower() if ch.isalnum()) not in ('year','fy','fiscalyear','financialyear'):
                    raise ValueError('Invalid financial-year filter.')
                clause,values=masterdata.filter_condition(year_filter)
                clauses.append(clause)
                params.extend(values)
        sql='SELECT DISTINCT '+expr+' FROM '+target+' WHERE '+' AND '.join(clauses)+' ORDER BY '+expr
        if fabric:
            sql+=' OFFSET ? ROWS FETCH NEXT ? ROWS ONLY'
            params.extend([offset,page_size+1])
        else:
            sql+=' LIMIT ? OFFSET ?'
            params.extend([page_size+1,offset])
        cursor.execute(sql,params)
        rows=cursor.fetchall()
        values=[None if r[0] is None else str(r[0]) for r in rows[:page_size]]
        if kind and not search and offset==0 and None not in values:
            values.insert(0,None)
        return {'values':values,
            'more':len(rows)>page_size,'nextOffset':offset+page_size}
    finally:
        cursor.close()
        if not fabric:conn.close()

def export_unmatched_customers(data):
    """Export distinct sold-to code/name pairs using the active customer relationship."""
    source,table=data.get('source','local'),data.get('table','')
    if source not in ('local','fabric'):
        raise ValueError('Choose a valid sales source.')
    base=base_columns(source,table)
    names={''.join(ch for ch in f['name'].lower() if ch.isalnum()):f['name'] for f in base}
    code,name=names.get('soldtopartycode'),names.get('soldtopartyname')
    if not code or not name:
        raise ValueError('The sales source must contain Soldtopartycode and Soldtopartyname.')
    conn=local()
    cursor=None
    output=None
    success=False
    try:
        conn.execute('BEGIN')
        info=masterdata.models(conn).get('customer')
        link=info.get('links',{}).get(masterdata.context(source,table)) if info else None
        if not link or link['salesKey'] not in {f['name'] for f in base}:
            raise ValueError('Save a Customer Master relationship for this sales source before exporting unmatched customers.')
        if source=='local':
            expr=masterdata.key_expr('s.'+quote(link['salesKey']),info['stripZeros'])
            sql='SELECT DISTINCT s.'+quote(code)+',s.'+quote(name)+' FROM sales s LEFT JOIN master_customer m ON '+expr+'=m.[__wpp_key] WHERE m.[__wpp_key] IS NULL'
            cursor=conn.execute(sql)
            master_keys=None
        else:
            selected=next(t for t in FABRIC['tables'] if t['id']==table)
            master_keys={r[0] for r in conn.execute('SELECT [__wpp_key] FROM master_customer')}
            cursor=FABRIC['connection'].cursor()
            cursor.execute('SELECT DISTINCT '+quote(code)+','+quote(name)+',TRIM(CAST('+quote(link['salesKey'])+' AS varchar(4000))) FROM '+quote(selected['schema'])+'.'+quote(selected['name']))
        directory=ROOT/'exports'
        directory.mkdir(exist_ok=True)
        output=directory/('Unmatched_Customers_'+dt.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6]+'.csv')
        count=0
        seen=set()
        def safe(value):
            value='' if value is None else str(value)
            return "'"+value if value.startswith(('=','+','-','@','\t','\r')) else value
        with output.open('w',encoding='utf-8-sig',newline='') as stream:
            writer=csv.writer(stream)
            writer.writerow(['Soldtopartycode','Soldtopartyname'])
            while True:
                rows=cursor.fetchmany(10000)
                if not rows:break
                for row in rows:
                    if master_keys is not None:
                        if masterdata.normalize(row[2],info['stripZeros']) in master_keys:
                            continue
                        pair=(None if row[0] is None else str(row[0]),None if row[1] is None else str(row[1]))
                        if pair in seen:continue
                        seen.add(pair)
                    writer.writerow([safe(row[0]),safe(row[1])])
                    count+=1
        success=True
        return {'path':str(output),'filename':output.name,'customers':count,'source':source,'table':table,'salesKey':link['salesKey']}
    finally:
        if cursor is not None:cursor.close()
        conn.close()
        if not success and output is not None:
            output.unlink(missing_ok=True)

def file_digest(path):
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):digest.update(chunk)
    return digest.hexdigest()

def ensure_file_ranges(conn):
    """Recover provenance for the original append-only cache without rewriting sales."""
    imported=list(conn.execute('SELECT name,rows FROM imports ORDER BY rowid'))
    ranges={row[0] for row in conn.execute('SELECT name FROM import_ranges')}
    missing=[name for name,_ in imported if name not in ranges]
    if not missing:return
    if ranges:
        raise ValueError('Some imported files have no source-row tracking. The existing data was kept; source tracking must be repaired before refreshing.')
    JOB.update(message='Preparing per-file tracking for existing sales data…')
    expected=sum(rows for _,rows in imported)
    exists=conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='sales'").fetchone()
    actual=conn.execute('SELECT COUNT(*) FROM sales').fetchone()[0] if exists else 0
    first=conn.execute('SELECT rowid FROM sales ORDER BY rowid LIMIT 1').fetchone() if actual else None
    last=conn.execute('SELECT rowid FROM sales ORDER BY rowid DESC LIMIT 1').fetchone() if actual else None
    if actual!=expected or (actual and last[0]-first[0]+1!=actual):
        raise ValueError('Sales rows do not match the original file import history. No data was changed; source tracking cannot safely be inferred.')
    start=first[0] if first else 1
    for name,count in imported:
        conn.execute('INSERT INTO import_ranges VALUES (?,?,?)',(name,start if count else None,start+count-1 if count else None))
        start+=count

def bump_data_revision(conn):
    row=conn.execute("SELECT value FROM metadata WHERE key='data_revision'").fetchone()
    revision=int(row[0])+1 if row else 1
    conn.execute('INSERT OR REPLACE INTO metadata VALUES (?,?)',('data_revision',str(revision)))

def remove_import_rows(conn,name,expected):
    row=conn.execute('SELECT first_rowid,last_rowid FROM import_ranges WHERE name=?',(name,)).fetchone()
    if row is None:raise ValueError('No source tracking is available for '+name)
    deleted=conn.execute('DELETE FROM sales WHERE rowid BETWEEN ? AND ?',row).rowcount if row[0] is not None else 0
    if deleted!=expected:
        raise ValueError('Source-row counts changed unexpectedly. The previous data was kept for '+name)

DAILY_REPORT_HEADERS = "CustomerType BillingDate BillingDoc BillingType ShippingPlant Soldtopartycode Materialcode Materialdescription GridValue Soldtopartyname GrossValue Division Region StockCategory Case Pairs BaseUOM BudgetedCategory ProductType ProcurementType Segment BrandGroup Brand SubCategory Gender ProductClass ZMRP Shiptopartycode Shiptopartyname PRDCategory Year Month".split()

def sales_header_order(name, source_headers, headers):
    normalize=lambda value: str(value).replace('\u200b','').replace('\ufeff','').strip().casefold()
    source={normalize(header):index for index,header in enumerate(source_headers)}
    if len(source)!=len(source_headers) or '' in source:
        raise ValueError('Headers must be non-empty and unique: '+name)
    expected={normalize(header) for header in headers}
    daily=Path(name).stem.strip().casefold()=='daily report'
    if daily:
        required={normalize(header) for header in DAILY_REPORT_HEADERS}
        if set(source)!=required or not required.issubset(expected):
            raise ValueError('Daily Report headings must match the supplied 32-column format and existing sales model. Previous data was kept.')
    elif set(source)!=expected:
        raise ValueError('Column headings do not match the sales model. Previous data was kept: '+name)
    return [source.get(normalize(header)) for header in headers]

def import_one_file(name, refresh_existing=False):
    import openpyxl
    allowed={p.name:p for p in FILES.glob('*.xlsx') if not p.name.startswith('~$')}
    if name not in allowed:raise ValueError('Source file is missing: '+name)
    path=allowed[name]
    JOB.update(message='Checking '+name,rows=0,file=name)
    digest=file_digest(path)
    conn=local()
    book=None
    try:
        previous=conn.execute('SELECT digest,rows FROM imports WHERE name=?',(name,)).fetchone()
        if refresh_existing and not previous:raise ValueError('Import the file before refreshing it: '+name)
        if previous and not refresh_existing:
            if previous[0]!=digest:raise ValueError(name+' changed after import. Use Refresh beside this file to replace its data.')
            return
        if conn.execute('SELECT 1 FROM imports WHERE digest=? AND name<>?',(digest,name)).fetchone():
            raise ValueError(name+' duplicates an already imported file. Existing data was kept.')
        book=openpyxl.load_workbook(path,read_only=True,data_only=True)
        # Some archives format invoice/customer numbers as dates. Keep their raw
        # numeric values; only actual date columns should become date objects.
        if hasattr(book,'_date_formats'):book._date_formats.clear()
        sheet=book['Data'] if 'Data' in book.sheetnames else book.active
        rows=iter(sheet.values)
        source_headers=[str(v).strip() if v is not None else '' for v in next(rows,[])]
        if not source_headers or not all(source_headers) or len({h.casefold() for h in source_headers})!=len(source_headers):
            raise ValueError('Headers must be non-empty and unique: '+name)
        existing=base_columns('local')
        headers=[f['name'] for f in existing] if existing else source_headers
        order=sales_header_order(name,source_headers,headers)
        date_columns=[i for i,h in enumerate(headers) if ''.join(ch for ch in h.casefold() if ch.isalnum()).endswith('date')]
        conn.execute('BEGIN IMMEDIATE')
        ensure_file_ranges(conn)
        conn.execute('CREATE TABLE IF NOT EXISTS sales ('+','.join(quote(h)+' TEXT' for h in headers)+')')
        stage='sales_stage_'+uuid.uuid4().hex
        conn.execute('CREATE TABLE '+quote(stage)+' ('+','.join(quote(h)+' TEXT' for h in headers)+')')
        insert='INSERT INTO '+quote(stage)+' VALUES ('+','.join('?' for _ in headers)+')'
        count,batch,observed,numeric=0,[],set(),set(range(len(headers)))
        for raw in rows:
            if all(v is None for v in raw):continue
            padded=list(raw)+[None]*max(0,len(source_headers)-len(raw))
            values=[padded[i] if i is not None else None for i in order]
            for i in date_columns:
                if isinstance(values[i],(int,float)) and not isinstance(values[i],bool):
                    try:values[i]=openpyxl.utils.datetime.from_excel(values[i],epoch=book.epoch)
                    except (OverflowError,ValueError):pass
            if count<1000:
                for i,value in enumerate(values):
                    if value is not None:
                        observed.add(i)
                        if not isinstance(value,(int,float)) or isinstance(value,bool):numeric.discard(i)
            batch.append([json_value(v) for v in values])
            count+=1
            if len(batch)>=2000:
                conn.executemany(insert,batch)
                batch.clear()
                JOB.update(message=('Refreshing ' if refresh_existing else 'Importing ')+name,rows=count)
        if batch:conn.executemany(insert,batch)
        book.close();book=None
        if file_digest(path)!=digest:raise ValueError('The Excel file changed while being read. Save it and refresh again. Previous data was kept.')
        if previous:remove_import_rows(conn,name,previous[1])
        last=conn.execute('SELECT COALESCE(MAX(rowid),0) FROM sales').fetchone()[0]
        cols=','.join(quote(h) for h in headers)
        conn.execute('INSERT INTO sales ('+cols+') SELECT '+cols+' FROM '+quote(stage))
        conn.execute('DROP TABLE '+quote(stage))
        if not existing:
            meta=[{'name':h,'numeric':i in observed and i in numeric} for i,h in enumerate(headers)]
            conn.execute('INSERT INTO metadata VALUES (?,?)',('columns',json.dumps(meta)))
        conn.execute('INSERT INTO imports VALUES (?,?,?,?) ON CONFLICT(name) DO UPDATE SET digest=excluded.digest,rows=excluded.rows,imported=excluded.imported',
            (name,digest,count,dt.datetime.now().isoformat(timespec='seconds')))
        conn.execute('INSERT OR REPLACE INTO import_ranges VALUES (?,?,?)',(name,last+1 if count else None,last+count if count else None))
        bump_data_revision(conn)
        conn.commit()
        JOB.update(rows=count,message=('Refreshed ' if refresh_existing else 'Imported ')+name)
    finally:
        conn.close()
        if book:book.close()

def remove_imported_file(name):
    with local() as conn:
        conn.execute('BEGIN IMMEDIATE')
        previous=conn.execute('SELECT rows FROM imports WHERE name=?',(name,)).fetchone()
        if previous is None:raise ValueError('This file is not imported: '+name)
        ensure_file_ranges(conn)
        remove_import_rows(conn,name,previous[0])
        conn.execute('DELETE FROM import_ranges WHERE name=?',(name,))
        conn.execute('DELETE FROM imports WHERE name=?',(name,))
        bump_data_revision(conn)
    return previous[0]

def finish_file_job():
    JOB['running']=False
    with local() as conn:
        conn.execute('INSERT OR REPLACE INTO metadata VALUES (?,?)',('last_import_job',json.dumps(JOB)))

def import_files(names, refresh_existing=False):
    try:
        for name in names:import_one_file(name,refresh_existing)
        JOB.update(message=('Refresh complete. Saved Excel changes are now in the local model.' if refresh_existing else 'Import complete. Your local model is ready.'))
    except Exception as exc:
        JOB.update(message=('Refresh stopped: ' if refresh_existing else 'Import stopped: ')+str(exc))
    finally:finish_file_job()

def remove_file_job(name):
    try:
        count=remove_imported_file(name)
        JOB.update(rows=count,message='Removed imported data for '+name+'. Original Excel file was kept.')
    except Exception as exc:JOB.update(message='Remove stopped: '+str(exc))
    finally:finish_file_job()

def optimize_local_model():
    try:
        analytics.prepare_indexes(local,lambda message:JOB.update(message=message))
        JOB.update(message='Optimization complete. Fast local report indexes are ready.')
    except Exception as exc:JOB.update(message='Optimization stopped: '+str(exc))
    finally:finish_file_job()

def connect_fabric(data):
    import re
    try:
        import pyodbc
    except ImportError:
        raise ValueError('Install pyodbc using Setup.cmd, and Microsoft ODBC Driver 18 for SQL Server.')
    server, database = data.get('server', '').strip(), data.get('database', '').strip()
    if not re.fullmatch(r'[a-zA-Z0-9.-]+\.datawarehouse\.fabric\.microsoft\.com', server):
        raise ValueError('Enter the Fabric SQL server hostname ending in .datawarehouse.fabric.microsoft.com (without tcp: or port).')
    if not database or len(database) > 128:
        raise ValueError('Enter the warehouse database name.')
    escape = lambda s: '{' + s.replace('}', '}}') + '}'
    conn = pyodbc.connect('DRIVER={ODBC Driver 18 for SQL Server};SERVER=' + server +
        ';DATABASE=' + escape(database) + ';Authentication=ActiveDirectoryInteractive;Encrypt=yes;TrustServerCertificate=no;', timeout=60, autocommit=True)
    conn.timeout = 120
    try:
        rows = conn.cursor().execute("SELECT TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS ORDER BY TABLE_SCHEMA,TABLE_NAME,ORDINAL_POSITION").fetchall()
        tables, mapping = [], {}
        for schema, table, name, dtype in rows:
            key = schema + '.' + table
            if key not in mapping:
                tables.append({'id': key, 'schema': schema, 'name': table})
                mapping[key] = []
            mapping[key].append({'name': name, 'numeric': dtype.lower() in NUMERIC})
        if not tables:
            raise ValueError('Connected, but no tables are visible. Check warehouse read permissions.')
    except Exception:
        conn.close()
        raise
    if FABRIC['connection']:
        FABRIC['connection'].close()
    FABRIC.update(connection=conn, tables=tables, columns=mapping)
    return {'tables': tables}

def run_pivot(data):
    if data.get('source','local')=='local':
        return analytics.run_local_pivot(data,local,DB)
    measures=data.get('measures')
    if measures is None:
        return run_single_pivot(data)
    if measures==[] and data.get('aggregation')=='count':
        return run_single_pivot(data)
    if not isinstance(measures,list) or not 1<=len(measures)<=3 or any(not isinstance(m,str) or not m for m in measures) or len(set(measures))!=len(measures):
        raise ValueError('Choose one to three different value headers.')
    if len(measures)==1:
        return run_single_pivot({**data,'measure':measures[0]})
    snapshot=None
    try:
        if data.get('source','local')=='local':
            snapshot=local()
            snapshot.execute('BEGIN')
        results=[run_single_pivot({**data,'measure':measure},snapshot) for measure in measures]
        groups=results[0]['groups']
        combined={}
        for i,result in enumerate(results):
            for row in result['rows']:
                key=tuple(row[:-1])
                combined.setdefault(key,list(key)+[None]*len(measures))[len(groups)+i]=row[-1]
        rows=sorted(combined.values(),key=lambda row:float(row[len(groups)]) if row[len(groups)] is not None else float('-inf'),reverse=True)
        return {**results[0],'rows':rows,'measures':measures,'totals':[result['total'] for result in results],
            'sql':'\n\n'.join('-- '+measure+'\n'+result['sql'] for measure,result in zip(measures,results))}
    finally:
        if snapshot is not None:snapshot.close()

def run_single_pivot(data, snapshot=None):
    source = data.get('source', 'local')
    if source not in ('local','fabric'):
        raise ValueError('Choose a valid data source.')
    table = data.get('table', '')
    fields = {c['name']: c for c in columns(source, table)}
    dims = data.get('rows', [])
    col = data.get('column', '')
    measure, agg = data.get('measure', ''), data.get('aggregation', 'sum')
    if len(dims) > 3 or len(dims) != len(set(dims)) or col in dims:
        raise ValueError('Choose up to three different row fields and a separate column field.')
    if any(d not in fields for d in dims + ([col] if col else [])):
        raise ValueError('Choose valid grouping fields.')
    if agg not in ('sum', 'avg', 'min', 'max', 'count', 'distinct'):
        raise ValueError('Invalid aggregation.')
    if agg != 'count' and measure not in fields:
        raise ValueError('Choose a measure.')
    if agg not in ('count', 'distinct') and not fields[measure]['numeric']:
        raise ValueError('Choose a numeric measure for this aggregation.')
    filters=data.get('filters',[])
    if not isinstance(filters,list) or len(filters)>30:
        raise ValueError('Choose up to 30 report filters.')
    for item in filters:
        if item.get('field') not in fields:
            raise ValueError('Invalid filter.')
        masterdata.filter_selection(item)
    if sum(len(masterdata.filter_selection(item)) for item in filters)>1800:
        raise ValueError('Too many selected values. Choose at most 1,800 values across all filters.')
    is_fabric = source == 'fabric'
    with local() as master_conn:
        active = masterdata.models(master_conn)
    referenced = dims + ([col] if col else []) + [item['field'] for item in data.get('filters',[])] + ([measure] if agg!='count' else [])
    if is_fabric and any(fields[name].get('master') for name in referenced):
        return masterdata.fabric_pivot(data,FABRIC,base_columns(source,table),active,DB)
    if is_fabric:
        selected = next(t for t in FABRIC['tables'] if t['id'] == table)
        target = quote(selected['schema']) + '.' + quote(selected['name'])
        conn = FABRIC['connection']
    else:
        conn = snapshot if snapshot is not None else local()
        target = masterdata.enrich('sales',base_columns('local'),active,'local')[0]
    groups = dims + ([col] if col else [])
    expr = 'COUNT_BIG(*)' if is_fabric else 'COUNT(*)'
    if agg == 'distinct':
        expr = 'COUNT(DISTINCT ' + quote(measure) + ')'
    elif agg != 'count':
        cast = 'TRY_CONVERT(float,' + quote(measure) + ')' if is_fabric else 'CAST(' + quote(measure) + ' AS REAL)'
        expr = agg.upper() + '(' + cast + ')'
    clauses, params = [], []
    for item in data.get('filters', []):
        clause, values = masterdata.filter_condition(item)
        clauses.append(clause)
        params.extend(values)
    where = ' WHERE ' + ' AND '.join(clauses) if clauses else ''
    select = ','.join([quote(d) for d in groups] + [expr + ' AS [__value]'])
    sql = 'SELECT ' + ('TOP (10001) ' if is_fabric else '') + select + ' FROM ' + target + where
    if groups:
        sql += ' GROUP BY ' + ','.join(quote(d) for d in groups)
    sql += ' ORDER BY [__value] DESC' + ('' if is_fabric else ' LIMIT 10001')
    try:
        if not is_fabric and snapshot is None:
            conn.execute('BEGIN')
        cursor = conn.cursor()
        cursor.execute(sql, params)
        result = [[json_value(v) for v in row] for row in cursor.fetchall()]
        if len(result) > 10000:
            raise ValueError('More than 10,000 groups. Add filters or remove a grouping field; no partial totals are displayed.')
        cursor.execute('SELECT ' + expr + ' FROM ' + target + where, params)
        total = json_value(cursor.fetchone()[0])
        return {'groups': groups, 'rows': result, 'total': total, 'aggregation': agg, 'measure': measure, 'sql': sql}
    finally:
        if not is_fabric and snapshot is None:
            conn.close()

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def send_json(self, value, code=200):
        body = json.dumps(value, allow_nan=False).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.headers.get('Host') not in (f'127.0.0.1:{self.server.server_port}', f'localhost:{self.server.server_port}'):
            return self.send_json({'error': 'Invalid host'}, 403)
        path = urlparse(self.path).path
        if path.startswith('/api/'):
            if self.headers.get('X-App-Token') != TOKEN:
                return self.send_json({'error': 'Invalid session'}, 403)
            if path == '/api/state':
                with local() as conn:
                    summary = conn.execute('SELECT COUNT(*),COALESCE(SUM(rows),0) FROM imports').fetchone()
                    masters = masterdata.status(conn)
                    revision=conn.execute("SELECT value FROM metadata WHERE key='data_revision'").fetchone()
                return self.send_json({'files': file_list(), 'columns': columns('local'), 'baseColumns':base_columns('local'), 'masters':masters, 'dataRevision':int(revision[0]) if revision else 0, 'job': current_job().copy(), 'importedFiles': summary[0], 'records': summary[1], 'fabricTables': FABRIC['tables']})
            return self.send_json({'error': 'Unknown endpoint'}, 404)
        allowed = {'/': 'index.html', '/app.js': 'app.js', '/masters.js':'masters.js', '/report-filters.js':'report-filters.js', '/style.css': 'style.css', '/compact.css':'compact.css'}
        if path not in allowed:
            return self.send_json({'error': 'Not found'}, 404)
        body = (ROOT / 'web' / allowed[path]).read_text(encoding='utf-8').replace('__APP_TOKEN__', TOKEN).encode()
        self.send_response(200)
        self.send_header('Content-Type', {'/': 'text/html', '/app.js': 'text/javascript', '/masters.js':'text/javascript', '/report-filters.js':'text/javascript', '/style.css': 'text/css', '/compact.css':'text/css'}[path] + '; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if self.headers.get('X-App-Token') != TOKEN:
            return self.send_json({'error': 'Invalid session'}, 403)
        try:
            length = int(self.headers.get('Content-Length', 0))
            path = urlparse(self.path).path
            if path == '/api/master/upload':
                if not 0 < length <= 50 * 1024 * 1024:
                    raise ValueError('Choose a master file up to 50 MB.')
                body = self.rfile.read(length)
                if len(body)!=length:
                    raise ValueError('Upload incomplete. Please try again.')
                with LOCK:
                    with local() as conn:
                        conn.execute('BEGIN IMMEDIATE')
                        result = masterdata.inspect_upload(conn,self.headers.get('X-Master-Kind'),unquote(self.headers.get('X-File-Name','')),body,unquote(self.headers.get('X-Sheet-Name','')))
                return self.send_json(result)
            if length > 100000:
                raise ValueError('Request too large.')
            data = json.loads(self.rfile.read(length))
            path = urlparse(self.path).path
            with LOCK:
                if path == '/api/import':
                    if current_job()['running']:
                        raise ValueError('An import is already running.')
                    names = data.get('files', [])
                    allowed = {f['name'] for f in file_list()}
                    if not names or len(names) != len(set(names)) or any(n not in allowed for n in names):
                        raise ValueError('Choose valid files from the data folder.')
                    JOB.update(running=True, operation='import',file='', message='Starting import', rows=0)
                    threading.Thread(target=import_files, args=(names,), daemon=True).start()
                    return self.send_json(JOB.copy())
                if path in ('/api/file/refresh','/api/file/remove'):
                    if current_job()['running']:
                        raise ValueError('Wait for the current file operation to finish.')
                    name=data.get('name')
                    if not isinstance(name,str):raise ValueError('Choose an imported file.')
                    files={f['name']:f for f in file_list()}
                    if name not in files or not files[name].get('imported'):
                        raise ValueError('This file is not imported.')
                    operation='refresh' if path.endswith('refresh') else 'remove'
                    if operation=='refresh' and files[name]['missing']:
                        raise ValueError('The original Excel file is missing. Restore it to the sales folder before refreshing.')
                    JOB.update(running=True,operation=operation,file=name,rows=0,message=('Refreshing ' if operation=='refresh' else 'Removing imported data: ')+name)
                    worker=threading.Thread(target=import_files,args=([name],True),daemon=True) if operation=='refresh' else threading.Thread(target=remove_file_job,args=(name,),daemon=True)
                    worker.start()
                    return self.send_json(JOB.copy())
                if path == '/api/connect':
                    return self.send_json(connect_fabric(data))
                if path == '/api/master/link':
                    base = base_columns(data.get('source','local'),data.get('table',''))
                    with local() as conn:
                        conn.execute('BEGIN IMMEDIATE')
                        result = masterdata.save_link(conn,data,base)
                    return self.send_json(result)
                if path == '/api/master/unmatched-customers':
                    exported=export_unmatched_customers(data)
                    file=Path(exported['path'])
                    self.send_response(200)
                    self.send_header('Content-Type','text/csv; charset=utf-8')
                    self.send_header('Content-Disposition','attachment; filename="'+exported['filename']+'"')
                    self.send_header('Content-Length',str(file.stat().st_size))
                    self.send_header('X-Customer-Count',str(exported['customers']))
                    self.send_header('Cache-Control','no-store')
                    self.end_headers()
                    with file.open('rb') as stream:
                        for chunk in iter(lambda:stream.read(65536),b''):
                            self.wfile.write(chunk)
                    return
                if path == '/api/base-columns':
                    return self.send_json(base_columns(data.get('source','local'),data.get('table','')))
                if path == '/api/columns':
                    return self.send_json(columns(data.get('source'), data.get('table')))
                if path == '/api/periods':
                    return self.send_json(period_options(data))
                if path == '/api/latest-billing-date':
                    return self.send_json(latest_billing_date(data))
                if path == '/api/filter-values':
                    return self.send_json(filter_values(data))
                if path == '/api/pivot':
                    return self.send_json(run_pivot(data))
                return self.send_json({'error': 'Unknown endpoint'}, 404)
        except Exception as exc:
            self.send_json({'error': str(exc)}, 400)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--no-browser', action='store_true')
    parser.add_argument('--import-monitor-port',type=int)
    parser.add_argument('--optimize',action='store_true')
    args = parser.parse_args()
    local().close()
    with local() as conn:
        previous_job = conn.execute("SELECT value FROM metadata WHERE key='last_import_job'").fetchone()
    if previous_job:
        JOB.update(json.loads(previous_job[0]))
        JOB['running'] = False
    if args.import_monitor_port:
        if args.import_monitor_port==args.port:
            parser.error('The import monitor must point to a different port.')
        monitor_existing_import(args.import_monitor_port)
    server = ThreadingHTTPServer(('127.0.0.1', args.port), Handler)
    if args.optimize:
        JOB.update(running=True,operation='optimize',file='',rows=0,message='Preparing fast local report indexes…')
        threading.Thread(target=optimize_local_model,daemon=True).start()
    print(f'Walkaroo Power Pivot is running at http://127.0.0.1:{args.port}', flush=True)
    if not args.no_browser:
        webbrowser.open(f'http://127.0.0.1:{args.port}')
    server.serve_forever()

