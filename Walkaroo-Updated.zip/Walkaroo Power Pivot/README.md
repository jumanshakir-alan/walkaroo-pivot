# Walkaroo Power Pivot

## Customer Master and Material Master (HANA)

Open **Master data** in the navigation. There are two upload slots, each holding one active master and at most one pending replacement. Upload `.xlsx` or UTF-8 `.csv` files (maximum 50 MB and 500,000 data records). Excel uses the `Data` sheet or first sheet by default; optionally enter a different worksheet name before uploading. The first row must contain unique column headings. Review the five-row preview, choose the unique master code, select a sales data source and its matching code, then click **Activate master & link sales**.

Suggested customer sales key: `Soldtopartycode` (or choose Payer / Ship-to codes when that is the intended customer relationship). Suggested material sales key: `Materialcode`. The app suggests fields, but you confirm the mapping. Blank and duplicate master keys are rejected. Keys are compared as trimmed text, preserving leading zeros by default. Choose **Ignore leading zeros** only if numeric codes such as `00123` and `123` represent the same entity. Excel numeric keys are imported as integer text where possible; leading zeros already lost in numeric Excel cells cannot be recovered.

**All local sales files** means the complete imported sales model, across all months and years. The relationship also applies to later sales imports. You do not map individual sales files. Local validation reports matched and unmatched sales record counts at the time the relationship is saved. Sales imports can continue; saving a master waits for SQLite's current write transaction and can require a retry if it remains busy for 60 seconds. Existing master data stays active if validation fails. Master replacement and activation are transactional.

Connect Fabric in **Data connections** first, then return to **Master data**. Choose each Fabric sales table/view in **Connect this master to** and save its corresponding sales code mapping. Customer and Material mappings are independent, and each can be reused across multiple Fabric tables. A new Fabric table requires an explicit mapping; no relationship is assumed from similar column names alone. Only one Fabric warehouse connection is active at a time, so reconnecting to a different warehouse with the same schema/table names requires reviewing the saved code mappings.

Linked attributes appear in pivot fields as `Customer · Zone` or `Material (HANA) · Category`. Master attributes are dimensions for grouping, filtering and distinct counts; summed values remain sales measures. Left joins preserve unmatched sales under `(Blank)`. Unique master codes prevent duplicated sales totals. Replacing a master changes the attribute classification for all historical sales; this version does not maintain historical versions of master attributes. Master data is stored locally in the same SQLite cache, so include the entire data folder in backups.

For Fabric pivots that use master attributes, the app aggregates sales in the warehouse first, then joins the resulting groups to local masters. Master files are never uploaded to Fabric and the warehouse is not modified. Average uses sums and counts rather than averaging group averages; distinct counts are calculated over the corresponding values. A maximum of 100,000 intermediate warehouse groups is supported. If exceeded, add sales filters; the app rejects partial results. Sales-only Fabric pivots retain the direct warehouse query path. Live Fabric authentication and joins still need verification with your real endpoint and account; automated tests use a simulated Fabric cursor.

During an update with an existing sales import still running, the updated application may run at port 8766 while monitoring the import at port 8765. Both read the same sales cache. The updated app prevents a second sales import until the original finishes. Normal Start.cmd launches the updated application at port 8765 after the old process is closed.

A local Windows web application for exploring Walkaroo sales through a read-only Microsoft Fabric Warehouse connection or a local Excel archive.

## Open the application

Double-click **Start.cmd**, then keep its console open while using the application. It opens http://127.0.0.1:8765 in your browser. Closing the console stops the server. The application only listens on this computer.

The bundled Codex Python can run Excel mode immediately on this machine. For a standalone installation, install Python 3.11 or later with its Python launcher, then run **Setup.cmd** once. Start.cmd prefers the installed `.venv` when it exists.

## Connect to Microsoft Fabric

1. Install [Microsoft ODBC Driver 18 for SQL Server](https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server) and run Setup.cmd to install pyodbc.
2. In Fabric, open the warehouse settings and copy its SQL connection details. See [Microsoft's connection guide](https://learn.microsoft.com/en-us/fabric/data-warehouse/how-to-connect).
3. Open **Data connections**. Enter the server hostname, such as `your-endpoint.datawarehouse.fabric.microsoft.com`, and the exact warehouse database name. Exclude `tcp:` and the port from the hostname.
4. Click **Connect with Microsoft** and complete the Microsoft Entra sign-in window. Your account needs read access to the warehouse tables or views.
5. Select a table or view, row fields, an optional column field, measure, aggregation and exact-match filters. Click **Run pivot**.

The application generates SELECT statements only. It does not run user-entered SQL or modify warehouse data. Identifiers come from warehouse metadata; filter values use query parameters. Authentication uses Entra interactive sign-in, TLS and certificate validation. No passwords are requested or saved. The connection remains in server memory until restart. Queries time out after 120 seconds. Tenant policy and user permissions still apply. Fabric mode requires network access to Microsoft services.

## Excel mode

Files are listed from the sibling `001. SQL Data Base` folder. Select files deliberately and click **Import selected files**. Import uses the `Data` sheet when available, otherwise the first worksheet; the first row must contain unique column names. Files must share the same ordered header layout. Imports stream rows into `data/sales.sqlite`, with one transaction per file and progress reporting. Completed files persist across restarts. A failed current file is rolled back; earlier completed files remain available.

**V1/V2/V3, annual and missed-period files may overlap.** Confirm which files are separate parts before selecting them together. A file name cannot be imported twice, and identical file content under another name is blocked. Different files with overlapping business records are not deduplicated automatically. Use Refresh beside an imported file to capture its current saved contents. Use Remove to clear only its imported rows while keeping the original workbook.

Original workbooks are read only. Formula cells use their stored Excel results. Numeric measures are inferred from the first 1,000 non-empty rows of the first imported file; numeric identifiers may also appear as measures. Review the field's meaning before summing it. This version requires clean numeric source columns; mixed text/numeric columns need source cleaning. Excel billing dates are retained as provided; use the Year and Month fields for date grouping.

## Analysis and limits

- Up to three row dimensions, one column dimension, and one measure per pivot.
- Sum, average, minimum, maximum, count of records, and distinct count.
- Report filters offer searchable, multiple-value selection in a separate panel. Values within one filter use OR; separate filters use AND. Choose `(Blank / unmatched)` for SQL NULL; an explicitly typed empty string is not the same as NULL. Blank groups display as `(Blank)`.
- The headline total is calculated over all matching records, separately from displayed groups. Averages and distinct counts are therefore not added across groups. Per-row/column subtotals are not provided.
- Up to 10,000 grouped cells per query. Larger results are rejected with a request to add filters, rather than displaying incomplete totals. The chart shows the ten largest absolute grouped values; negative values use a different colour.
- Saved pivot configurations stay in this browser's local storage. CSV export includes the complete displayed pivot matrix, with spreadsheet formula-injection escaping for text cells.
- A single local user and one source table/view at a time. This is an initial application, not a complete DAX/Power Pivot engine: arbitrary table relationships, DAX formulas, automatic fiscal time intelligence, scheduled refresh, shared access and role-based application accounts are not implemented. Customer and Material Master relationships are supported as described below. Use a prepared Fabric view for other joins and business measures.

Large Excel archives require enough local disk space and time for import. Live Fabric mode aggregates in the warehouse and avoids downloading five years of detail. Local sums use SQLite floating-point arithmetic; this is an analytical tool rather than an accounting ledger.

## Verification

Run `python -m unittest discover -s tests -v` from this directory. Automated checks cover pivot grouping, filters, averages, distinct counts, validation, source SQL generation, HTTP session protection and local import rollback. The Fabric sign-in and real warehouse query require your endpoint, driver and account and must be verified in your environment.



## Financial periods and report filters

The Financial year selector filters the selected source using its financial-year field (`FinancialYear`, `FiscalYear`, `FY`, or the existing sales `Year` column). The Month selector offers only month values present in that selected year. All financial years is available for comparisons. Month pivot rows and columns, including CSV exports, follow April through March; financial-year rows are chronological. Month names, short month names and numeric month codes are recognised. Year/month grouping uses the source fields; it does not derive a different year from BillingDate or rewrite existing sales records.

Under **Build your report**, choose **Open filter selection panel**, **Customer Master filter**, or **HANA Material filter**. The separate panel lists full field titles grouped by source and lets you search names. Choose a field to add its filter, search its available values and check one or more selections. Search retains already selected values. Choose **Use typed value** for an exact value not currently listed, or **Clear** to remove that field's selections. Up to 200 matching values are listed at a time; search to find other values. At most 200 values per filter and 1,800 across all filters are supported. Values within the same filter use OR, and different field filters and financial-period filters combine using AND. Empty filter cards are not applied.

Choose **Apply filters**, then **Run pivot**. Totals, chart and CSV export use the same filtered query. Cancel or Escape restores the previous filter selections. Saved views retain the selected values and financial-period choices. Master filter options appear after uploading and linking that master to the current sales source. Selecting a master in this panel does not change its code relationship or the source data.

Verify fiscal presentation with `node tests/test_fiscal.js`, in addition to the Python test suite.

## Header-wise value selection

Open **Select filter headers** under Build your report. Choose a column in **Select header**. Only that header's values are displayed underneath; switching headers replaces the visible list while retaining previous choices in header tabs. Newly opened headers include all values by default. **Select all** includes every value for that header, including values on pages not yet displayed. Uncheck values to exclude them, or choose **Clear selection** and check specific values. Applying a header with no values selected is blocked so an empty selection cannot silently become an unrestricted report.

Large distinct-value lists load in pages of 500 with **Load more values**. Every page is accessible, rather than cutting off the list at the former 200 suggestions. Search applies to the entire header, and selections persist when changing searches or pages. Explicit selections/exceptions still allow up to 200 values per filter; use Select all to include a large header without sending thousands of SQL parameters. Month header values follow selected financial-year header restrictions, as well as the main financial-year selector. Cancel restores prior selections. Saved reports store effective inclusions and exclusions; unrestricted All headers need no query predicate.

## Choose which headers appear in the report builder

Rows, Columns and Values now show only your chosen report headers. Use **Choose visible headers** to open Filter by header. Selecting a header there adds it to the visible set; use **Show this header in Rows, Columns and Values** to hide or show it. Visible-header chips can also remove a header. Choose **Apply headers & filters** to update the builder. Cancel discards draft visibility changes. Field-value filters remain independent, so a hidden header can still filter data.

The initial visible set is Region and NetTotal when present, otherwise one dimension and one numeric field. Removing a header currently used in a row, column or measure clears that selection. Choices are saved in this browser separately for local sales and each Fabric table, and included in saved reports. Older saved reports automatically expose the headers they use. Verify these behaviours with `node tests/test_visible_headers.js`.

## Separate Rows, Columns and Values header selections

Each builder field now has an independent header list and its own **Choose row headers**, **Choose column headers**, or **Choose value headers** button. Changes made in one picker affect only that role. The defaults are Rows = Year, Columns = None, Values = GrossValue. If the source lacks Year or GrossValue, that field is left unselected rather than substituting another measure. These role-specific lists supersede the earlier shared visible-header set, persist separately per data source, and are included in saved views. Older saved views expose their actual row, column and value fields in the corresponding roles. The general Filter by header panel can also assign a header explicitly to each role using its separate checkboxes.

## Three Values fields

Values now has three dropdowns, defaulting to GrossValue / None / None. Use Choose value headers to make the desired measures available, then select up to three different measures and Run pivot. The common Summarise by aggregation applies to each selected measure, and all row, column, period and master filters apply to each. Pivot tables and CSV exports show each measure separately; month columns retain financial-year ordering. The headline and chart show the first selected measure, with the other measure totals shown below the headline. Local multi-measure queries share a read snapshot so an ongoing sales import cannot change the dataset between measures. Existing one-measure saved views remain supported.

## Unmatched customer details export

In Master data → Customer Master, use **Export unmatched customers CSV**. The file contains exactly Soldtopartycode and Soldtopartyname, with repeated code/name pairs removed. Matching follows the active, saved Customer Master relationship and its leading-zero setting; unsaved mapping edits and pivot filters do not change this full-source export. Unmatched blank codes remain blank rather than being omitted. UTF-8 CSV output includes Excel-compatible encoding and formula-injection escaping for text. If a code has different names in the source, each distinct code/name pair is retained. This count is distinct pairs, not the number of unmatched sales records shown by the coverage check. Local exports read a consistent snapshot; an empty result still contains column headers. Fabric exports use the saved table mapping without modifying the warehouse. Copies are retained in the application's exports folder.

## Customer type quick filter

Customer type is available beside Financial year and Month, with All customer types as its default. It uses the sales CustomerType field when present; otherwise it uses a linked Customer Master Customer type attribute. The dropdown tooltip identifies the actual field. Values come from the full selected source, and a blank/unmatched choice is available when applicable. Choose a customer type and Run pivot to apply it together with financial-year, month and report-panel filters to every selected measure, totals, chart and CSV export. Saved reports retain this quick selection. It does not restrict the separate full-source unmatched-customer export. Verify quick-filter composition with `node tests/test_customer_type.js`.

Customer type quick-filter options are now deduplicated without regard to capitalization, surrounding or repeated spaces, nonbreaking spaces and invisible zero-width formatting. Display labels use consistent uppercase. Each option retains its original source variants and filters them together using OR, so Domestic and DOMESTIC appear once but both contribute to the report. Raw sales and master data are not changed. Older saved single-value customer-type selections are resolved to the corresponding grouped option when restored.


## Refresh or remove a sales Excel file

In Data connections → Excel sales archive, each imported file has Refresh and Remove buttons. Save workbook changes first, then choose Refresh. The app stages the current Data sheet (or first sheet), validates its headings and checks that the file did not change while being read, then atomically replaces only that file's old rows. Edited cells, added rows, deleted rows and even an empty data sheet are captured. Repeated refresh does not append duplicate copies. Reordered columns are matched by heading; added, removed or renamed headings are rejected because all sales files must share the same model. Excel formula results must be recalculated and saved in Excel before refreshing; the app reads cached formula results and does not evaluate formulas itself. On a read or validation error, the previous imported rows and metadata are kept.

Remove deletes only that file's imported data and its import registration. The source Excel workbook remains in the folder and can be imported again. If a source file has moved or is missing, its cached entry remains visible: Remove still works, while Refresh requires restoring the original workbook. Other file imports and Customer/Material Master relationships remain intact. Refresh and Remove run in the background with progress, one file operation at a time.

The original append-only cache is upgraded by reconstructing per-file row ranges from its import insertion order and row counts, only after validating that its sales row history is consistent. This adds tracking records without rewriting existing sales. If history is inconsistent, refresh/remove fails safely instead of guessing ownership. Subsequent imports and refreshes update tracking transactionally.

Each successful data change increments a model revision, even when the file's row count stays the same. The page clears stale pivot/chart/export results and reloads year/month/customer-type choices after the file operation finishes. Existing report header and filter selections are preserved. A selected period or customer type that no longer exists is marked as not in data and continues to filter to no matches, instead of silently becoming All. Run pivot again to calculate against the updated data. Previously shown master coverage counts are cleared until validated again. Verify with `python -m unittest discover -s tests -p test_file_operations.py -v`.

## Pivot performance

Local pivots now aggregate up to three Values fields in one grouped query. Customer/Material Master lookups are added only when the report references those master attributes. Sum, count, minimum and maximum totals are derived from the grouped result; averages use weighted sums/counts. Distinct counts retain a separate total query to avoid double-counting values across groups.

Persistent covering indexes support standard Year/Month/CustomerType reports and common measures, with additional CustomerType and normalized master-code indexes. SQLite maintains these indexes when files are imported, refreshed or removed. To build/update indexes for a changed model, start `app.py --optimize`; progress appears in the data-operation status. Existing indexes persist across normal restarts.

A bounded cache retains repeated local query results. Cache keys include sales data revision, master revision, active relationship definitions and query selections. Refresh, remove, import and master relationship updates invalidate the corresponding cached results. Reports display calculation time and identify cached responses. Fabric continues to query the connected warehouse.

On the current 13.3-million-row archive, the FY2025-26 Domestic monthly GrossValue comparison test improved from 37.844 seconds to 0.799 seconds, with matching groups and totals. The same three-measure report (GrossValue, Pairs, NetTotal) completed in 0.816 seconds; a cached repeat completed in 0.0027 seconds. Times vary with fields, filters and computer load. Regression tests verify one-scan multi-measure aggregation, average/distinct correctness, master lookup pruning, cache invalidation and index maintenance across file refresh/removal.

## Refresh the sales folder

The Excel sales archive has a Refresh folder button above Find files. It rescans the configured source folder, shows newly added Excel workbooks, and reports how many files are ready to import. Opening Data connections also rescans the folder. A folder rescan does not append imported files again or overwrite their data: select new files and use Import selected files, or use the per-file Refresh button for saved edits to an existing workbook.

Reconciliation completed on 29 October 2026: four Sep 2026 workbooks were discovered and imported. September FY2026-27 contributed GrossValue 711,638,672.20 to Customer UP_Region TN, bringing that region's fiscal-year total from 3,314,237,517.10 to 4,025,876,189.30. This matches the supplied expected 4,025,876,189.2996845 at two decimals. The September FY2026-27 data contains 377,045 sales rows, all matched to the saved Customer Master relationship. The discrepancy was missing imported September data, rather than a failed customer join. Existing file refresh/removal and report-result cache invalidation continue to apply.

## UP_Region quick filter

Financial year, Month, Customer type and UP_Region each support multiple selections in a searchable checkbox panel. Use Select all or Clear selection, choose the required values, then Apply and Run pivot. Months include the available months across all selected financial years, in April–March order. Values within one filter use OR; the four filters combine using AND. Saved views retain multiple selections and still accept older single selections.

UP_Region is now beside the Financial year, Month and Customer type quick filters. It defaults to All regions and uses the linked Customer Master UP_Region field, preserving the mapping used by regional pivot rows. It never substitutes the sales Region field. A prepared source's explicit UP_Region field is used only when no linked Customer Master UP_Region is available. Region options are unique despite capitalization or whitespace variants, and selections combine with all other report filters for each measure, totals, chart and export. The region is retained in saved reports and after file changes. Without a suitable linked region field, the control is disabled with guidance to link the Customer Master. Verify with `node tests/test_up_region.js`.

UP_Region options depend on the applied Customer type selection. Multiple customer types show their combined regions. Changing types preserves valid region selections and clears unavailable selections; if none remain, it returns to All regions.

All workspaces share `web/compact.css`, loaded after the base styles. New workspace pages should use the existing panel, label, primary/secondary, hint and connection-grid classes to inherit compact typography, 28px controls, 12px panel padding and 10px gaps. Adjust shared workspace density tokens there rather than adding larger per-page controls.

## Daily cumulative report
Use `Daily Report.xlsx` in the source folder for the supplied 32-column current-month cumulative format. Import once; overwrite/save the same Excel file daily and click its Refresh button. Refresh atomically replaces only that file’s previous rows, invalidates pivot caches, and updates periods and latest billing date. Header order and surrounding whitespace do not matter. Existing model fields absent from this format stay NULL; financial year/month and financial measures are not invented. Customer and material codes use the existing master links. Do not also import the same month from another archive, since cross-file business duplicates are not removed.
