@echo off
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  .venv\Scripts\python.exe app.py
  goto finished
)
set "WALKAROO_PYTHON=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%WALKAROO_PYTHON%" (
  "%WALKAROO_PYTHON%" app.py
) else (
  py -3 app.py
)
:finished
pause
