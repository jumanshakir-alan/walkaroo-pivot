const masterTitles={customer:'Customer Master',material:'Material Master (HANA)'};
const masterFeedback={};
function masterLabel(parent,text,control){const label=el('label',text);label.htmlFor=control.id;parent.append(label,control);}
function chooseCode(names,kind){const normalize=s=>s.toLowerCase().replace(/[^a-z0-9]/g,'');const candidates=kind==='customer'?['Soldtopartycode','CustomerCode','CustomerNumber','CustomerNo','KUNNR','Customer']:['Materialcode','MATNR','MaterialNumber','MaterialNo','Material','Article'];for(const candidate of candidates){const found=names.find(n=>normalize(n)===normalize(candidate));if(found)return found;}return names[0]||'';}
function renderMasters(){
  $('masterCards').replaceChildren();
  for(const kind of Object.keys(masterTitles)){
    const active=state.masters?.active?.[kind],pending=state.masters?.pending?.[kind],info=pending||active;
    const card=el('section',undefined,'panel master-card');
    card.append(el('div',kind==='customer'?'CUSTOMER DIMENSION':'PRODUCT DIMENSION','eyebrow'),el('h2',masterTitles[kind]));
    card.append(el('p',active?`Active: ${active.filename} · ${fmt(active.rows)} records · ${active.sheet}`:'No active master. Upload an Excel or CSV file to get started.','master-status'));
    if(active){const links=el('div',undefined,'master-links');Object.entries(active.links||{}).forEach(([target,link])=>links.append(el('div',`${target==='local'?'All local sales files':target.replace('fabric:','Fabric / ')}: ${link.salesKey} → ${active.masterKey}`)));card.append(links);}
    const file=el('input');file.type='file';file.accept='.xlsx,.csv';file.id=kind+'Upload';
    masterLabel(card,active?'Upload replacement file':'Choose master file (.xlsx or .csv)',file);
    const sheet=el('input');sheet.id=kind+'Sheet';sheet.placeholder='Optional worksheet name';
    masterLabel(card,'Worksheet (blank uses Data / first sheet)',sheet);
    const upload=el('button','Upload & preview','secondary full');
    upload.onclick=async()=>{const selected=file.files[0];if(!selected){notice('Choose a master file first.',true);return;}if(selected.size>50*1024*1024){notice('Choose a file up to 50 MB.',true);return;}upload.disabled=true;upload.textContent='Reading master…';try{const response=await fetch('/api/master/upload',{method:'POST',headers:{'X-App-Token':token,'X-Master-Kind':kind,'X-File-Name':encodeURIComponent(selected.name),'X-Sheet-Name':encodeURIComponent(sheet.value.trim())},body:selected});const data=await response.json();if(!response.ok)throw Error(data.error||'Upload failed');await refresh();renderMasters();notice('Upload preview ready. Choose the unique master code and matching sales code, then activate the relationship.');}catch(e){notice(e.message,true);}finally{upload.disabled=false;upload.textContent='Upload & preview';}};
    card.append(upload,el('p','Maximum 50 MB / 500,000 master records. The first row must contain column headings.','hint'));
    if(state.job?.running)card.append(el('p','Sales import is running. Saving a master may wait for the current sales file to finish; the relationship also applies to subsequent imports.','hint'));
    if(info){
      card.append(el('div',undefined,'separator'));
      if(pending){card.append(el('p',`Pending: ${pending.filename} · ${fmt(pending.rows)} rows · ${pending.sheet}`,'master-pending'));const wrap=el('div',undefined,'master-preview'),table=el('table'),head=el('tr');pending.columns.forEach(name=>head.append(el('th',name)));const thead=el('thead');thead.append(head);table.append(thead);const body=el('tbody');pending.preview.forEach(row=>{const tr=el('tr');row.forEach(v=>tr.append(el('td',text(v))));body.append(tr);});table.append(body);wrap.append(table);card.append(wrap);}
      const masterKey=el('select');masterKey.id=kind+'MasterKey';options(masterKey,info.columns.map(name=>({name})));masterKey.value=pending?chooseCode(info.columns,kind):active.masterKey;masterKey.disabled=!pending;
      masterLabel(card,'Unique code in the master',masterKey);
      const zeroLabel=el('label',undefined,'zero-option'),zeros=el('input');zeros.type='checkbox';zeros.id=kind+'Zeros';zeros.checked=pending?!!active?.stripZeros:!!active.stripZeros;zeros.disabled=!pending;zeroLabel.append(zeros,el('span','Ignore leading zeros in numeric codes'));card.append(zeroLabel);
      const target=el('select');target.id=kind+'Target';target.add(new Option('All local sales files','local'));(state.fabricTables||[]).forEach(t=>target.add(new Option('Fabric / '+t.id,'fabric:'+t.id)));masterLabel(card,'Connect this master to',target);
      const salesKey=el('select');salesKey.id=kind+'SalesKey';masterLabel(card,'Matching code in sales',salesKey);
      const linkButton=el('button',pending?'Activate master & link sales':'Save relationship','primary');
      const populate=async()=>{linkButton.disabled=true;try{const isFabric=target.value.startsWith('fabric:');const base=isFabric?await api('base-columns',{source:'fabric',table:target.value.slice(7)}):state.baseColumns||[];options(salesKey,base);const saved=active?.links?.[target.value]?.salesKey;const normalize=s=>s.toLowerCase().replace(/[^a-z0-9]/g,'');salesKey.value=saved||base.find(c=>normalize(c.name)===normalize(masterKey.value))?.name||chooseCode(base.map(c=>c.name),kind);linkButton.disabled=!base.length;}catch(e){notice(e.message,true);}};
      target.onchange=populate;masterKey.onchange=populate;
      linkButton.onclick=async()=>{linkButton.disabled=true;linkButton.textContent='Validating relationship…';try{const isFabric=target.value.startsWith('fabric:');const response=await api('master/link',{kind,stage:pending?.stage,masterKey:masterKey.value,stripZeros:zeros.checked,source:isFabric?'fabric':'local',table:isFabric?target.value.slice(7):'',salesKey:salesKey.value});masterFeedback[kind]=response.coverage?`${fmt(response.coverage.matched)} matched sales records · ${fmt(response.coverage.unmatched)} unmatched. Unmatched records stay in the pivot under (Blank).`:'Relationship saved for this Fabric table. Run a pivot to query current warehouse data with master attributes.';await refresh();if(source==='fabric'&&$('table').value){fields=await api('columns',{source,table:$('table').value});}else if(source==='local'){fields=state.columns;}fillFields();renderMasters();notice('Master relationship saved. Master attributes are now available in pivot rows, columns and filters.');}catch(e){notice(e.message,true);linkButton.disabled=false;linkButton.textContent=pending?'Activate master & link sales':'Save relationship';}};
      card.append(linkButton,el('p','Master codes must be unique and non-empty. Text codes match after trimming surrounding spaces. New uploads replace the current master only after validation succeeds.','hint'));
      if(!state.baseColumns?.length&&!state.fabricTables?.length)card.append(el('p','Import sales data or connect Fabric before activating a relationship. Your pending upload is saved.','hint'));
      populate();
    }
    if(masterFeedback[kind])card.append(el('p',masterFeedback[kind],'master-feedback'));
    if(kind==='customer'&&active){
      const exportBox=el('div',undefined,'unmatched-export');exportBox.append(el('div',undefined,'separator'),el('h3','Unmatched customer details'));
      const exportSource=el('select');exportSource.id='unmatchedCustomerSource';
      for(const target of Object.keys(active.links||{})){if(target==='local')exportSource.add(new Option('All local sales files','local'));else if((state.fabricTables||[]).some(t=>'fabric:'+t.id===target))exportSource.add(new Option('Fabric / '+target.slice(7),target));}
      masterLabel(exportBox,'Sales source for unmatched customers',exportSource);
      const exportButton=el('button','↓ Export unmatched customers CSV','secondary full');exportButton.disabled=!exportSource.options.length;
      exportButton.onclick=async()=>{exportButton.disabled=true;exportButton.textContent='Preparing unmatched customer details…';try{const fabric=exportSource.value.startsWith('fabric:');const response=await fetch('/api/master/unmatched-customers',{method:'POST',headers:{'Content-Type':'application/json','X-App-Token':token},body:JSON.stringify({source:fabric?'fabric':'local',table:fabric?exportSource.value.slice(7):''})});if(!response.ok){const error=await response.json();throw Error(error.error||'Export failed');}const blob=await response.blob(),url=URL.createObjectURL(blob),download=el('a');download.href=url;download.download=response.headers.get('Content-Disposition')?.match(/filename="([^"]+)"/)?.[1]||'Unmatched_Customers.csv';download.click();setTimeout(()=>URL.revokeObjectURL(url),1000);notice('Exported '+fmt(response.headers.get('X-Customer-Count'))+' unique unmatched customer code/name pairs.');}catch(error){notice(error.message,true);}finally{exportButton.disabled=false;exportButton.textContent='↓ Export unmatched customers CSV';}};
      exportBox.append(exportButton,el('p','Columns: Soldtopartycode and Soldtopartyname. Uses the saved Customer Master relationship across all sales in this source; report filters do not limit this export. Repeated code/name pairs appear once.','hint'));card.append(exportBox);
    }
    $('masterCards').append(card);
  }
}
refresh().then(renderMasters).catch(e=>notice(e.message,true));
