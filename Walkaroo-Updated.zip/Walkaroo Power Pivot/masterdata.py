"""Local master uploads, validated many-to-one relationships and Fabric enrichment."""
import csv
import datetime
import io
import json
import re
import sqlite3
import uuid
import zipfile

KINDS = {'customer': 'Customer', 'material': 'Material (HANA)'}
MAX_ROWS = 500000
FABRIC_GROUP_LIMIT = 100000

def q(name):
    # ANSI quoting works with SQLite and Fabric, including embedded delimiters.
    return '"' + name.replace('"', '""') + '"'

def filter_selection(item):
    values = item.get('values') if 'values' in item else [item.get('value')]
    if not isinstance(values,list) or not 1<=len(values)<=200 or any(v is not None and not isinstance(v,str) for v in values):
        raise ValueError('Choose between 1 and 200 values for each filter.')
    return values

def filter_condition(item):
    values = filter_selection(item)
    nonblank = [v for v in values if v is not None]
    parts = []
    if nonblank:
        parts.append(q(item['field'])+' IN ('+','.join('?' for _ in nonblank)+')')
    if None in values:
        parts.append(q(item['field'])+' IS NULL')
    condition='('+' OR '.join(parts)+')'
    if item.get('exclude'):
        if None not in values:
            condition='('+q(item['field'])+' IS NULL OR NOT '+condition+')'
        else:
            condition='('+q(item['field'])+' IS NOT NULL AND NOT '+condition+')'
    return condition,nonblank

def models(conn):
    return {kind: json.loads(row[0]) for kind in KINDS
            if (row := conn.execute('SELECT value FROM metadata WHERE key=?', ('master:'+kind,)).fetchone())}

def context(source, table=''):
    return 'local' if source == 'local' else 'fabric:'+table

def normalize(value, strip_zeros=False):
    value = '' if value is None else str(value).strip()
    if strip_zeros and re.fullmatch(r'0*[0-9]+', value):
        return value.lstrip('0') or '0'
    return value

def key_expr(expr, strip_zeros):
    clean = 'TRIM(CAST(' + expr + ' AS TEXT))'
    if strip_zeros:
        return "CASE WHEN " + clean + "<>'' AND " + clean + " NOT GLOB '*[^0-9]*' THEN COALESCE(NULLIF(LTRIM(" + clean + ",'0'),''),'0') ELSE " + clean + ' END'
    return clean

def inspect_upload(conn, kind, filename, content, sheet_name=''):
    if kind not in KINDS:
        raise ValueError('Choose Customer Master or Material Master.')
    name = filename.replace('\\', '/').split('/')[-1]
    suffix = name.lower().rsplit('.', 1)[-1]
    book = None
    try:
        sheets = []
        if suffix == 'xlsx':
            import openpyxl
            with zipfile.ZipFile(io.BytesIO(content)) as archive:
                if sum(i.file_size for i in archive.infolist()) > 512 * 1024 * 1024:
                    raise ValueError('Workbook is too large when expanded. Use CSV or split unnecessary sheets out.')
            book = openpyxl.load_workbook(io.BytesIO(content), read_only=True, data_only=True)
            sheets = book.sheetnames
            selected = sheet_name or ('Data' if 'Data' in sheets else sheets[0])
            if selected not in sheets:
                raise ValueError('Worksheet not found. Available sheets: '+', '.join(sheets))
            rows = iter(book[selected].values)
        elif suffix == 'csv':
            text = content.decode('utf-8-sig')
            try:
                dialect = csv.Sniffer().sniff(text[:8192], delimiters=',;\t')
            except csv.Error:
                dialect = csv.excel
            rows = iter(csv.reader(io.StringIO(text), dialect))
            selected = 'CSV'
        else:
            raise ValueError('Upload an .xlsx or UTF-8 .csv file.')
        headers = [str(h).strip() if h is not None else '' for h in next(rows, [])]
        if not headers or len(headers) > 250 or not all(headers) or len({h.casefold() for h in headers}) != len(headers):
            raise ValueError('The first row must have 1–250 non-empty, unique column headings.')
        if any(h.casefold().startswith('__wpp_') for h in headers):
            raise ValueError('Column headings starting with __wpp_ are reserved.')
        stage = 'stage_' + uuid.uuid4().hex
        conn.execute('CREATE TABLE '+q(stage)+' ('+','.join(q(h)+' TEXT' for h in headers)+')')
        insert = 'INSERT INTO '+q(stage)+' VALUES ('+','.join('?' for _ in headers)+')'
        preview, batch, count = [], [], 0
        for row in rows:
            if all(v is None or v == '' for v in row):
                continue
            if len(row) > len(headers) and any(v is not None and v != '' for v in row[len(headers):]):
                raise ValueError('A data row contains more values than column headings.')
            values = list(row[:len(headers)]) + [None]*max(0,len(headers)-len(row))
            values = [str(int(v)) if isinstance(v,float) and v.is_integer() else None if v is None else str(v) for v in values]
            if len(preview)<5:
                preview.append(values)
            batch.append(values)
            count += 1
            if count>MAX_ROWS:
                raise ValueError('Master exceeds the 500,000-row upload limit.')
            if len(batch)>=2000:
                conn.executemany(insert,batch)
                batch.clear()
        if batch:
            conn.executemany(insert,batch)
        if not count:
            raise ValueError('The selected sheet has no data rows.')
        # Keep a single pending replacement per master; the active master remains untouched.
        old = conn.execute('SELECT value FROM metadata WHERE key=?',('pending:'+kind,)).fetchone()
        if old:
            conn.execute('DROP TABLE IF EXISTS '+q(json.loads(old[0])['stage']))
        info = {'stage':stage,'kind':kind,'filename':name,'columns':headers,'rows':count,'sheet':selected,'sheets':sheets,'preview':preview}
        conn.execute('INSERT OR REPLACE INTO metadata VALUES (?,?)',('pending:'+kind,json.dumps(info)))
        return info
    finally:
        if book:
            book.close()

def status(conn):
    active = models(conn)
    pending = {kind: json.loads(row[0]) for kind in KINDS
        if (row := conn.execute('SELECT value FROM metadata WHERE key=?',('pending:'+kind,)).fetchone())}
    return {'active':active,'pending':pending}

def enrich(base_target, base_columns, active, source, table='', master_schema='', only=None):
    names = {c['name'] for c in base_columns}
    fields = list(base_columns)
    select, joins = ['s.*'], []
    for kind, info in active.items():
        if only is not None and kind not in only:
            continue
        link = info.get('links',{}).get(context(source,table))
        if not link or link['salesKey'] not in names:
            continue
        alias = 'm_'+kind
        joins.append(' LEFT JOIN '+master_schema+q('master_'+kind)+' AS '+alias+' ON '+
            key_expr('s.'+q(link['salesKey']),info['stripZeros'])+' = '+alias+'.'+q('__wpp_key'))
        for name in info['columns']:
            label = KINDS[kind]+' · '+name
            if label in names:
                raise ValueError('A sales column conflicts with a master field: '+label)
            fields.append({'name':label,'numeric':False,'master':kind})
            select.append(alias+'.'+q(name)+' AS '+q(label))
    return '(SELECT '+','.join(select)+' FROM '+base_target+' AS s'+''.join(joins)+')', fields

def save_link(conn, data, base_columns):
    kind = data.get('kind')
    if kind not in KINDS:
        raise ValueError('Invalid master type.')
    source, table = data.get('source','local'), data.get('table','')
    if source not in ('local','fabric'):
        raise ValueError('Invalid source.')
    sales_key = data.get('salesKey')
    if sales_key not in {c['name'] for c in base_columns}:
        raise ValueError('Choose a valid sales key from the selected data source.')
    active = models(conn).get(kind)
    stage = data.get('stage')
    if stage:
        row = conn.execute('SELECT value FROM metadata WHERE key=?',('pending:'+kind,)).fetchone()
        pending = json.loads(row[0]) if row else {}
        if stage != pending.get('stage'):
            raise ValueError('This upload is no longer pending. Reload the master settings.')
        key = data.get('masterKey')
        if key not in pending['columns']:
            raise ValueError('Choose the unique master code field.')
        strip = bool(data.get('stripZeros',False))
        conn.execute('ALTER TABLE '+q(stage)+' ADD COLUMN '+q('__wpp_key')+' TEXT')
        conn.execute('UPDATE '+q(stage)+' SET '+q('__wpp_key')+' = '+key_expr(q(key),strip))
        blanks = conn.execute('SELECT COUNT(*) FROM '+q(stage)+" WHERE [__wpp_key] IS NULL OR [__wpp_key]=''").fetchone()[0]
        duplicate = conn.execute('SELECT [__wpp_key],COUNT(*) FROM '+q(stage)+' GROUP BY [__wpp_key] HAVING COUNT(*)>1 LIMIT 1').fetchone()
        if blanks:
            raise ValueError(f'{blanks} master rows have an empty key. Correct the master before activating it.')
        if duplicate:
            raise ValueError(f'Master key is not unique: {duplicate[0]} occurs {duplicate[1]} times. Choose a unique key or correct the file; sales totals must not multiply.')
        conn.execute('DROP TABLE IF EXISTS '+q('master_'+kind))
        conn.execute('ALTER TABLE '+q(stage)+' RENAME TO '+q('master_'+kind))
        conn.execute('CREATE UNIQUE INDEX '+q('idx_master_'+kind)+' ON '+q('master_'+kind)+' ([__wpp_key])')
        active = {k:pending[k] for k in ('filename','columns','rows','sheet')}
        old = models(conn).get(kind,{})
        active.update(masterKey=key,stripZeros=strip,links=old.get('links',{}),updated=datetime.datetime.now().isoformat(timespec='seconds'))
        conn.execute('DELETE FROM metadata WHERE key=?',('pending:'+kind,))
    if not active:
        raise ValueError('Upload a master file first.')
    active.setdefault('links',{})[context(source,table)] = {'salesKey':sales_key}
    conn.execute('INSERT OR REPLACE INTO metadata VALUES (?,?)',('master:'+kind,json.dumps(active)))
    previous_revision=conn.execute("SELECT value FROM metadata WHERE key='master_revision'").fetchone()
    conn.execute('INSERT OR REPLACE INTO metadata VALUES (?,?)',('master_revision',str(int(previous_revision[0])+1 if previous_revision else 1)))
    coverage = None
    if source == 'local':
        expr = key_expr('s.'+q(sales_key),active['stripZeros'])
        matched,total = conn.execute('SELECT COUNT(m.[__wpp_key]),COUNT(*) FROM sales s LEFT JOIN '+q('master_'+kind)+' m ON '+expr+'=m.[__wpp_key]').fetchone()
        coverage = {'matched':matched,'unmatched':total-matched,'records':total}
    return {'master':active,'coverage':coverage}

def fabric_pivot(data, fabric, base_columns, active, db_path):
    """Aggregate in Fabric, then join local masters without uploading them to Fabric."""
    source_names = {c['name'] for c in base_columns}
    table = data['table']
    group_fields = data.get('rows',[])+([data['column']] if data.get('column') else [])
    measure,agg = data.get('measure',''),data.get('aggregation','sum')
    referenced = group_fields+[f['field'] for f in data.get('filters',[])]+([measure] if agg!='count' else [])
    needed_kinds = {kind for kind in KINDS if any(name.startswith(KINDS[kind]+' · ') for name in referenced)}
    keys = [active[kind]['links'][context('fabric',table)]['salesKey'] for kind in needed_kinds]
    needed = list(dict.fromkeys([f for f in group_fields if f in source_names]+keys))
    if agg=='distinct' and measure in source_names and measure not in needed:
        needed.append(measure)
    value = 'TRY_CONVERT(float,'+q(measure)+')' if agg not in ('count','distinct') else None
    states = []
    if agg=='avg':
        states = [('SUM('+value+')','__wpp_sum'),('COUNT_BIG('+value+')','__wpp_count')]
    elif agg=='count':
        states = [('COUNT_BIG(*)','__wpp_count')]
    elif agg!='distinct':
        states = [(agg.upper()+'('+value+')','__wpp_value')]
    clauses, params = [], []
    post_filters=[]
    for item in data.get('filters',[]):
        if item['field'] in source_names:
            clause,values=filter_condition(item)
            clauses.append(clause)
            params.extend(values)
        else:
            post_filters.append(item)
    selected = next(t for t in fabric['tables'] if t['id']==table)
    select = [q(n) for n in needed]+[expr+' AS '+q(alias) for expr,alias in states]
    sql = 'SELECT TOP (100001) '+','.join(select)+' FROM '+q(selected['schema'])+'.'+q(selected['name'])
    if clauses: sql += ' WHERE '+' AND '.join(clauses)
    if needed: sql += ' GROUP BY '+','.join(q(n) for n in needed)
    cursor = fabric['connection'].cursor()
    memory = sqlite3.connect(':memory:')
    try:
        cursor.execute(sql,params)
        headings = needed+[alias for _,alias in states]
        memory.execute('CREATE TABLE fabric_sales ('+','.join(q(n)+(' REAL' if n.startswith('__wpp_') else ' TEXT') for n in headings)+')')
        insert = 'INSERT INTO fabric_sales VALUES ('+','.join('?' for _ in headings)+')'
        count=0
        while True:
            batch=cursor.fetchmany(2000)
            if not batch:break
            count+=len(batch)
            if count>FABRIC_GROUP_LIMIT:
                raise ValueError('Master lookup exceeds 100,000 intermediate warehouse groups. Narrow the sales filters before running this pivot. No partial totals are shown.')
            memory.executemany(insert,[[None if v is None else float(v) if i>=len(needed) else str(v) for i,v in enumerate(row)] for row in batch])
        memory.execute('ATTACH DATABASE ? AS masterdb',(str(db_path),))
        target,_ = enrich('fabric_sales',[{'name':n} for n in headings],active,'fabric',table,'masterdb.',needed_kinds)
        conditions=[filter_condition(f) for f in post_filters]
        where = ' WHERE '+' AND '.join(clause for clause,_ in conditions) if conditions else ''
        post_params=[value for _,values in conditions for value in values]
        if agg=='avg': expr='SUM([__wpp_sum])/NULLIF(SUM([__wpp_count]),0)'
        elif agg=='count': expr='COALESCE(SUM([__wpp_count]),0)'
        elif agg=='distinct':expr='COUNT(DISTINCT '+q(measure)+')'
        else:expr=agg.upper()+'([__wpp_value])'
        final='SELECT '+','.join([q(f) for f in group_fields]+[expr+' AS [__value]'])+' FROM '+target+where
        if group_fields:final+=' GROUP BY '+','.join(q(f) for f in group_fields)
        final+=' ORDER BY [__value] DESC LIMIT 10001'
        rows=[list(r) for r in memory.execute(final,post_params)]
        if len(rows)>10000:raise ValueError('More than 10,000 result groups. Add filters.')
        total=memory.execute('SELECT '+expr+' FROM '+target+where,post_params).fetchone()[0]
        return {'groups':group_fields,'rows':rows,'total':total,'aggregation':agg,'measure':measure,
            'sql':sql+'\n\n-- Local master lookup and final aggregation:\n'+final,
            'note':'Fabric aggregates joined to local master files. Unmatched codes appear as (Blank).'}
    finally:
        cursor.close()
        memory.close()
