@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run Setup-Final.cmd first.
  pause
  exit /b 1
)
echo Open http://127.0.0.1:8765 after the server starts.
echo On first run, read data\bootstrap.token and enter that token on the setup screen.
echo Keep this console open. Press Ctrl+C here to stop the server.
echo Do not run the original Start.cmd alongside this shared portal.
.venv\Scripts\python.exe portal.py --host 127.0.0.1 --port 8765
if errorlevel 1 (
  echo Server stopped with an error. Check the output above.
  pause
  exit /b 1
)
