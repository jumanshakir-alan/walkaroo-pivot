#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if [ ! -x .venv/bin/python ]; then python3 -m venv .venv; fi
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m pip check
printf '%s\n' 'Setup complete. Run bash start-final.sh. Fabric also needs Microsoft ODBC Driver 18.'
